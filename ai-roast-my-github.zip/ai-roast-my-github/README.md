# 🔥 AI Roast My GitHub (Next.js App Router Edition)

A production-oriented developer profile analyzer and evidence-grounded AI roast generator built with **Next.js App Router**, **TypeScript**, **Tailwind CSS**, and **Vitest**.

## 1. Free-First AI Configuration (`AI_PROVIDER=gemini`)

The application is configured **free-first by default** using **Google Gemini** (`AI_PROVIDER=gemini`) with default model **`gemini-3.5-flash-lite`**, while preserving optional support for **OpenAI** and **Anthropic** and keeping `AI_MODEL` configurable. All API keys (`GEMINI_API_KEY`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GITHUB_TOKEN`, `UPSTASH_REDIS_REST_TOKEN`) are read **strictly server-side** in `src/app/api/roast/route.ts` and `src/lib/ai-roast.ts` and are never exposed to client bundles.

### Protection Against Unexpected Paid API Usage

- `resolveAiProviderConfig()` in `src/lib/ai-roast.ts` **never selects a paid provider (`openai` or `anthropic`) implicitly**:
  - When `AI_PROVIDER=gemini` or when `AI_PROVIDER` is omitted, the server only uses `GEMINI_API_KEY`. If `GEMINI_API_KEY` is missing—even if `OPENAI_API_KEY` or `ANTHROPIC_API_KEY` is present in the environment—the server returns HTTP `503 MISSING_AI_API_KEY` rather than silently falling back to a paid provider.
  - **OpenAI** is only used when `AI_PROVIDER=openai` is explicitly set alongside `OPENAI_API_KEY`.
  - **Anthropic** is only used when `AI_PROVIDER=anthropic` is explicitly set alongside `ANTHROPIC_API_KEY`.

### How to Obtain a Gemini API Key & Configure the App

1. Open **[Google AI Studio](https://aistudio.google.com/apikey)** and sign in with your Google account.
2. Click **"Create API key"**, select or create a project, and copy the generated key.
3. Copy `.env.example` to `.env.local` in the project root and configure:
   ```bash
   AI_PROVIDER=gemini
   GEMINI_API_KEY=your_gemini_api_key_here
   # Optional: override the default model ("gemini-3.5-flash-lite")
   # AI_MODEL=gemini-3.5-flash-lite
   ```
4. *(Recommended, $0)* Create a read-only personal access token on GitHub (no scopes required for public data) and set `GITHUB_TOKEN=` in `.env.local` to raise your GitHub REST API quota from 60 requests/hour to 5,000 requests/hour.

### Gemini Free-Tier Quotas, Limitations & Data-Use Terms

- **Not Unlimited Free Use**: `gemini-3.5-flash-lite` is listed in Google's official [Gemini Developer API Pricing](https://ai.google.dev/gemini-api/docs/pricing) documentation with Free Tier input and output tokens via Google AI Studio, but usage is **not unlimited**. Google enforces per-project rate limits across **Requests Per Minute (RPM)**, **Tokens Per Minute (TPM)**, and **Requests Per Day (RPD)** ([Gemini API Rate Limits](https://ai.google.dev/gemini-api/docs/rate-limits)). Exceeding those quotas returns HTTP `429` from the upstream Gemini API, and paid-only models (such as `gemini-4-argon` or paid-tier configurations) incur charges.
- **Unpaid Services Data-Use Terms**: Under the [Gemini API Additional Terms of Service](https://ai.google.dev/gemini-api/terms) for **Unpaid Services** (the Free Tier), Google may use submitted prompts, context, and generated outputs (and human reviewers may read them) to provide, improve, and develop Google products and machine-learning models. Paid Services (projects linked to an active Cloud Billing account) do not use your prompts or outputs to train Google models. Do not submit private, sensitive, or confidential data when using an unpaid API key.

### Verified Supported AI Providers & Model IDs (October 2026)

| Provider (`AI_PROVIDER`) | Default `AI_MODEL` | Additional Configurable Models | Billing & Cost Notes |
| :--- | :--- | :--- | :--- |
| **`gemini`** *(Default)* | `gemini-3.5-flash-lite` | Paid/higher-tier options via `AI_MODEL` (e.g. `gemini-3.8-flash`, `gemini-4-argon`) | **Free-tier input & output tokens available for `gemini-3.5-flash-lite`** in Google AI Studio (subject to RPM/TPM/RPD quotas and Unpaid Services data-use terms; see [Gemini Developer API Pricing](https://ai.google.dev/gemini-api/docs/pricing)). Paid models and Paid Tier usage incur charges. |
| **`openai`** *(Explicit Paid Option)* | `gpt-5.4-mini` | `gpt-5.4-mini-2026-03-17`, `gpt-5.4`, `gpt-6-luna` | **Paid only (incurs per-token charges).** Only used when `AI_PROVIDER=openai` is explicitly configured. Uses `reasoning_effort: "none"` with `temperature: 0.5` and `response_format: { type: "json_object" }` on `v1/chat/completions` ([GPT-5.4 Mini Docs](https://developers.openai.com/api/docs/models/gpt-5.4-mini)). Replaces deprecated `gpt-5-mini`, `gpt-4.1-mini`, and `gpt-4o-mini` ([Chat Completions Reference](https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create)). |
| **`anthropic`** *(Explicit Paid Option)* | `claude-haiku-5-5` | `claude-sonnet-5-5` | **Paid only (incurs per-token charges).** Only used when `AI_PROVIDER=anthropic` is explicitly configured. Replaces deprecated `claude-sonnet-4-20250514` and `claude-sonnet-4-5` ([Anthropic Models Overview](https://platform.claude.com/docs/en/models/overview)). |

## 2. Key Architecture & Security Features

1. **Multi-Page GitHub REST API Client with Header + Body Timeouts (`src/lib/github.ts`)**
   - Sanitizes and validates GitHub handles (`@username` or full `github.com/username` URLs).
   - Enforces explicit `AbortController` timeouts (`GITHUB_REQUEST_TIMEOUT_MS`, default `5000ms`) covering both response headers and response-body streaming/JSON parsing (`fetchWithTimeout()`), returning HTTP `504 UPSTREAM_TIMEOUT` on stalled upstream calls.
   - Paginates through public repositories (`per_page=100`, up to `GITHUB_MAX_PAGES=5` / 500 repositories by default) while checking remaining rate-limit headers (`x-ratelimit-remaining`) and execution-time budgets.
   - Explicitly tracks and displays `pagination.isComplete`, `pagination.coveragePercentage`, and `pagination.coverageNotice` whenever a large profile exceeds the pagination cap.

2. **Atomic Rate Limiting, Abuse Protection & Proxy Trust (`src/lib/rate-limit.ts`)**
   - **Redis Optional for $0-Cost Setup**: When `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN` are omitted, `/api/roast` uses an in-memory sliding-window limiter with zero external infrastructure cost.
   - Enforces sliding-window rate limits (`ROAST_RATE_LIMIT_MAX=10` per `ROAST_RATE_LIMIT_WINDOW_MS=60000`) and a global accepted-request budget (`ROAST_GLOBAL_MAX_PER_MINUTE=60`).
   - Checks the per-key limit **before** checking or incrementing the global budget so an already-blocked key cannot exhaust the global budget for other users by flooding rejected requests.
   - **Distributed Rate Limiting (Upstash Redis Lua `EVAL`)**:
     - When `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN` are configured, executes a single atomic Redis Lua `EVAL` script (`REDIS_SLIDING_WINDOW_LUA`) with collision-free `crypto.randomUUID()` member IDs (`${nowMs}:${uuid}`).
     - Fails closed (`503 RATE_LIMIT_BACKEND_UNAVAILABLE`) if configured Redis becomes unreachable (unless `ROAST_RATE_LIMIT_FAIL_OPEN=true` is explicitly set).
   - **Proxy Trust & Shared-Key Fallback (`TRUST_PROXY`)**:
     - Setting `TRUST_PROXY=false` disables **all** forwarded headers (`x-vercel-forwarded-for`, `cf-connecting-ip`, `x-real-ip`, `x-forwarded-for`) so clients cannot spoof their IP when the server is directly exposed without a trusted reverse proxy.
     - If the hosting runtime supplies a validated peer IP (`request.ip`), `extractClientIp()` uses it. Otherwise, `extractClientIp()` returns `"127.0.0.1"`. **Important**: When `TRUST_PROXY=false` and the runtime does not expose a peer IP on `Request`, returning `"127.0.0.1"` means **all callers share the same `"127.0.0.1"` rate-limit bucket** (`ROAST_RATE_LIMIT_MAX` requests/min combined across all callers) rather than receiving individual per-IP isolation. Public deployments without a trustworthy reverse proxy or runtime peer IP must enforce per-IP rate limiting at the network/edge layer (e.g., Cloudflare WAF, AWS WAF, Nginx).
     - `x-vercel-forwarded-for` is only trustworthy when deployed on Vercel; `cf-connecting-ip` is only trustworthy behind Cloudflare with origin firewall rules blocking direct origin connections; `x-real-ip` and `x-forwarded-for` are only trustworthy behind a reverse proxy you control (AWS ALB, Nginx, Envoy) that strips client-supplied headers.

3. **Deterministic Evidence Integrity & Post-Generation Validation (`src/lib/ai-roast.ts`)**
   - Factual fields (`observedSignal`, `observedFact`, `metricBadge`, `observedBasis`) are generated **100% deterministically** from GitHub data and locked against AI modification.
   - `validateAiClaimsAgainstEvidence()` maintains separate sets for repository names (`repoNameSet`), repository topics (`topicSet`), programming languages (`languageSet`), and general vocabulary (`generalVocabSet`), and separates `followers` and `following` into distinct numeric buckets—rejecting fabricated numbers, cross-metric number misuse (including hyphenated forms like `7-star` or `8-repo`), and quoted or unquoted fabricated repository names.

## 3. Setup & Commands

```bash
npm ci            # Or `npm install` on a networked machine to populate node_modules
cp .env.example .env.local
npm test          # Runs `vitest run`
npm run typecheck # Runs `tsc --noEmit`
npm run lint      # Runs `next lint --no-cache` (non-interactive via .eslintrc.json)
npm run build     # Runs `next build`
npm run dev       # Starts local Next.js dev server
```
