import { describe, it, expect } from "vitest";
import {
  classifyPersonality,
  computeTrustworthyScores,
  normalizeGitHubMetrics,
} from "@/lib/scoring";
import { buildDeterministicGroundedRoast } from "@/lib/ai-roast";
import { GitHubRepo, GitHubUser } from "@/types/roast";

const BASE_USER: GitHubUser = {
  login: "testbuilder",
  id: 1001,
  avatar_url: "https://avatars.githubusercontent.com/u/1001",
  html_url: "https://github.com/testbuilder",
  name: "Test Builder",
  company: "Acme Corp",
  blog: "https://example.com",
  location: "Hyderabad, India",
  bio: "Systems & TypeScript Engineer",
  public_repos: 2,
  public_gists: 1,
  followers: 15,
  following: 10,
  created_at: "2021-01-01T00:00:00Z",
  updated_at: "2026-10-10T00:00:00Z",
  type: "User",
};

const REF_DATE = new Date("2026-10-15T00:00:00Z");

describe("Data Normalization & Trustworthy Heuristic Scoring", () => {
  it("handles 0 public repositories gracefully without NaN or division by zero", () => {
    const emptyUser: GitHubUser = { ...BASE_USER, public_repos: 0 };
    const metrics = normalizeGitHubMetrics(emptyUser, [], undefined, REF_DATE);
    const scores = computeTrustworthyScores(emptyUser, metrics);
    const personality = classifyPersonality(emptyUser, metrics, scores);

    expect(metrics.analyzedRepoCount).toBe(0);
    expect(metrics.pagination.isComplete).toBe(true);
    expect(scores.overall).toBe(0.5);
    expect(personality.id).toBe("stealth-ghost");
  });

  it("handles partial and malformed repository fields safely", () => {
    const partialRepos: GitHubRepo[] = [
      {
        name: "",
        html_url: "",
        description: null,
        fork: false,
        created_at: "invalid-date",
        updated_at: "",
        pushed_at: null,
        homepage: "   ",
        size: -10,
        stargazers_count: NaN as unknown as number,
        forks_count: 0,
        language: null,
        license: null,
      },
    ];

    const metrics = normalizeGitHubMetrics(
      BASE_USER,
      partialRepos,
      undefined,
      REF_DATE
    );
    expect(metrics.analyzedRepoCount).toBe(1);
    expect(metrics.allRepos[0].name).toBe("repo-1");
    expect(metrics.allRepos[0].stars).toBe(0);
    expect(metrics.allRepos[0].sizeKb).toBe(0);
    expect(metrics.allRepos[0].hasHomepage).toBe(false);
  });

  it("does NOT equate star count with code quality (0-star substantive repos score high)", () => {
    const unstarredSubstantiveRepos: GitHubRepo[] = [
      {
        name: "distributed-kv-engine",
        html_url: "https://github.com/testbuilder/distributed-kv-engine",
        description: "RAFT-backed key-value storage engine with WAL",
        fork: false,
        created_at: "2026-01-01T00:00:00Z",
        updated_at: "2026-09-15T00:00:00Z",
        pushed_at: "2026-09-15T00:00:00Z",
        homepage: "https://docs.example.com",
        size: 1850,
        stargazers_count: 0,
        forks_count: 0,
        language: "Rust",
        license: { name: "MIT" },
        topics: ["raft", "storage", "rust"],
      },
      {
        name: "compiler-ir-passes",
        html_url: "https://github.com/testbuilder/compiler-ir-passes",
        description: "SSA optimization passes and register allocator",
        fork: false,
        created_at: "2025-06-01T00:00:00Z",
        updated_at: "2026-08-20T00:00:00Z",
        pushed_at: "2026-08-20T00:00:00Z",
        homepage: null,
        size: 940,
        stargazers_count: 0,
        forks_count: 0,
        language: "Rust",
        license: { name: "Apache-2.0" },
        topics: ["compiler", "ssa"],
      },
    ];

    const metrics = normalizeGitHubMetrics(
      BASE_USER,
      unstarredSubstantiveRepos,
      undefined,
      REF_DATE
    );
    const scores = computeTrustworthyScores(BASE_USER, metrics);

    expect(metrics.totalStars).toBe(0);
    expect(scores.quality).toBeGreaterThanOrEqual(8.0);
    expect(scores.ambition).toBeGreaterThanOrEqual(7.0);
  });

  it("does NOT penalize older completed/stable repositories as abandoned", () => {
    const stableRepos: GitHubRepo[] = [
      {
        name: "completed-cli-tool",
        html_url: "https://github.com/testbuilder/completed-cli-tool",
        description: "Stable CLI tool developed over 4 months in 2024",
        fork: false,
        created_at: "2024-01-01T00:00:00Z",
        updated_at: "2024-05-15T00:00:00Z",
        pushed_at: "2024-05-15T00:00:00Z",
        homepage: null,
        size: 420,
        stargazers_count: 12,
        forks_count: 2,
        language: "Go",
        license: { name: "MIT" },
        topics: ["cli"],
      },
    ];

    const metrics = normalizeGitHubMetrics(
      BASE_USER,
      stableRepos,
      undefined,
      REF_DATE
    );
    const scores = computeTrustworthyScores(BASE_USER, metrics);

    expect(metrics.initialCommitOnlyCount).toBe(0);
    expect(metrics.stableCompletedCount).toBe(1);
    expect(scores.consistency).toBeGreaterThanOrEqual(7.0);
  });

  it("treats single-language dominance as Focused Specialization rather than a red flag", () => {
    const singleLangRepos: GitHubRepo[] = [1, 2, 3, 4].map((i) => ({
      name: `ts-service-${i}`,
      html_url: `https://github.com/testbuilder/ts-service-${i}`,
      description: `TypeScript microservice module ${i}`,
      fork: false,
      created_at: "2026-01-01T00:00:00Z",
      updated_at: "2026-09-01T00:00:00Z",
      pushed_at: "2026-09-01T00:00:00Z",
      homepage: "https://example.com",
      size: 350,
      stargazers_count: 5,
      forks_count: 1,
      language: "TypeScript",
      license: { name: "MIT" },
      topics: ["typescript", "backend"],
    }));

    const metrics = normalizeGitHubMetrics(
      { ...BASE_USER, public_repos: 4 },
      singleLangRepos,
      undefined,
      REF_DATE
    );
    const scores = computeTrustworthyScores(BASE_USER, metrics);
    const personality = classifyPersonality(BASE_USER, metrics, scores);
    const roast = buildDeterministicGroundedRoast(
      BASE_USER,
      metrics,
      scores,
      personality
    );

    expect(metrics.languageSpecialization).toBe("Focused Specialist");
    const hasSingleLangPenaltyFlag = roast.redFlags.some((f) =>
      f.title.toLowerCase().includes("dependence on typescript")
    );
    expect(hasSingleLangPenaltyFlag).toBe(false);
  });

  it("classifies Serial Project Starter only when small Day-1 initial-commit drops dominate", () => {
    const dayOneDrops: GitHubRepo[] = [1, 2, 3, 4, 5].map((i) => ({
      name: `midnight-idea-${i}`,
      html_url: `https://github.com/testbuilder/midnight-idea-${i}`,
      description: `Started at 2am ${i}`,
      fork: false,
      created_at: "2026-03-01T02:00:00Z",
      updated_at: "2026-03-01T03:00:00Z",
      pushed_at: "2026-03-01T03:00:00Z",
      homepage: null,
      size: 8, // < 35 KB and <= 24h lifespan
      stargazers_count: 0,
      forks_count: 0,
      language: "JavaScript",
      license: null,
      topics: [],
    }));

    const metrics = normalizeGitHubMetrics(
      { ...BASE_USER, public_repos: 5 },
      dayOneDrops,
      undefined,
      REF_DATE
    );
    const scores = computeTrustworthyScores(BASE_USER, metrics);
    const personality = classifyPersonality(BASE_USER, metrics, scores);

    expect(metrics.initialCommitOnlyCount).toBe(5);
    expect(personality.id).toBe("serial-project-starter");
  });
});
