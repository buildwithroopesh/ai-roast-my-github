import { describe, it, expect } from "vitest";
import {
  clearGitHubCache,
  fetchGitHubProfileAndRepos,
  GitHubApiError,
  sanitizeAndValidateUsername,
} from "@/lib/github";

describe("GitHub Username Validation, Timeouts & Multi-Page Pagination Client", () => {
  it("sanitizes and validates GitHub usernames and URLs accurately", () => {
    expect(sanitizeAndValidateUsername("torvalds")).toEqual({
      valid: true,
      username: "torvalds",
    });
    expect(
      sanitizeAndValidateUsername("https://github.com/gaearon/overreacted.io")
    ).toEqual({
      valid: true,
      username: "gaearon",
    });
    expect(sanitizeAndValidateUsername("@sindresorhus")).toEqual({
      valid: true,
      username: "sindresorhus",
    });
    expect(sanitizeAndValidateUsername("-invalid-start").valid).toBe(false);
    expect(sanitizeAndValidateUsername("invalid--double-hyphen").valid).toBe(
      false
    );
    expect(sanitizeAndValidateUsername("   ").valid).toBe(false);
  });

  it("paginates across multiple pages and reports partial coverage when maxPages is reached", async () => {
    clearGitHubCache();

    const mockFetch = async (input: RequestInfo | URL): Promise<Response> => {
      const url = String(input);
      if (url.endsWith("/users/largeprofile")) {
        return new Response(
          JSON.stringify({
            login: "largeprofile",
            id: 500,
            avatar_url: "",
            html_url: "https://github.com/largeprofile",
            name: "Large Profile",
            public_repos: 250,
            public_gists: 0,
            followers: 50,
            following: 10,
            created_at: "2020-01-01T00:00:00Z",
            updated_at: "2026-10-01T00:00:00Z",
          }),
          {
            status: 200,
            headers: {
              "x-ratelimit-limit": "60",
              "x-ratelimit-remaining": "55",
            },
          }
        );
      }

      if (url.includes("/repos?") && url.includes("page=1")) {
        const page1 = Array.from({ length: 100 }, (_, i) => ({
          name: `repo-p1-${i}`,
          html_url: `https://github.com/largeprofile/repo-p1-${i}`,
          description: "Page 1 repo",
          fork: false,
          created_at: "2025-01-01T00:00:00Z",
          updated_at: "2026-09-01T00:00:00Z",
          pushed_at: "2026-09-01T00:00:00Z",
          size: 120,
          stargazers_count: 2,
          forks_count: 0,
          language: "TypeScript",
        }));
        return new Response(JSON.stringify(page1), {
          status: 200,
          headers: {
            "x-ratelimit-limit": "60",
            "x-ratelimit-remaining": "54",
          },
        });
      }

      if (url.includes("/repos?") && url.includes("page=2")) {
        const page2 = Array.from({ length: 100 }, (_, i) => ({
          name: `repo-p2-${i}`,
          html_url: `https://github.com/largeprofile/repo-p2-${i}`,
          description: "Page 2 repo",
          fork: false,
          created_at: "2025-01-01T00:00:00Z",
          updated_at: "2026-08-01T00:00:00Z",
          pushed_at: "2026-08-01T00:00:00Z",
          size: 80,
          stargazers_count: 1,
          forks_count: 0,
          language: "Python",
        }));
        return new Response(JSON.stringify(page2), {
          status: 200,
          headers: {
            "x-ratelimit-limit": "60",
            "x-ratelimit-remaining": "53",
          },
        });
      }

      throw new Error(`Unexpected URL: ${url}`);
    };

    const result = await fetchGitHubProfileAndRepos("largeprofile", {
      maxPages: 2,
      perPage: 100,
      bypassCache: true,
      fetchFn: mockFetch as typeof fetch,
    });

    expect(result.repos.length).toBe(200);
    expect(result.pagination.pagesFetched).toBe(2);
    expect(result.pagination.totalPublicRepos).toBe(250);
    expect(result.pagination.isComplete).toBe(false);
    expect(result.pagination.truncationReason).toBe("MAX_PAGES_REACHED");
    expect(result.pagination.coveragePercentage).toBe(80);
    expect(result.pagination.coverageNotice).toContain(
      "Partial profile coverage (80%)"
    );
  });

  it("stops pagination gracefully when rate-limit quota drops too low", async () => {
    clearGitHubCache();

    const mockFetch = async (input: RequestInfo | URL): Promise<Response> => {
      const url = String(input);
      if (url.endsWith("/users/QuotaUser")) {
        return new Response(
          JSON.stringify({
            login: "QuotaUser",
            id: 600,
            public_repos: 200,
            created_at: "2020-01-01T00:00:00Z",
          }),
          {
            status: 200,
            headers: { "x-ratelimit-remaining": "10" },
          }
        );
      }
      const page1 = Array.from({ length: 100 }, (_, i) => ({
        name: `repo-${i}`,
        created_at: "2025-01-01T00:00:00Z",
      }));
      return new Response(JSON.stringify(page1), {
        status: 200,
        headers: { "x-ratelimit-remaining": "1" },
      });
    };

    const result = await fetchGitHubProfileAndRepos("QuotaUser", {
      maxPages: 5,
      perPage: 100,
      bypassCache: true,
      fetchFn: mockFetch as typeof fetch,
    });

    expect(result.repos.length).toBe(100);
    expect(result.pagination.isComplete).toBe(false);
    expect(result.pagination.truncationReason).toBe("RATE_LIMIT_LOW");
  });

  it("throws typed USER_NOT_FOUND error on 404 without falling back to snapshots", async () => {
    clearGitHubCache();

    const mock404Fetch = async (): Promise<Response> =>
      new Response(JSON.stringify({ message: "Not Found" }), { status: 404 });

    let caught: GitHubApiError | null = null;
    try {
      await fetchGitHubProfileAndRepos("torvalds", {
        bypassCache: true,
        fetchFn: mock404Fetch as typeof fetch,
      });
    } catch (err) {
      caught = err as GitHubApiError;
    }

    expect(caught).not.toBeNull();
    expect(caught?.code).toBe("USER_NOT_FOUND");
    expect(caught?.status).toBe(404);
  });

  it("throws typed RATE_LIMITED error on 429/403", async () => {
    clearGitHubCache();

    const mock429Fetch = async (): Promise<Response> =>
      new Response(JSON.stringify({ message: "API rate limit exceeded" }), {
        status: 429,
        headers: {
          "x-ratelimit-limit": "60",
          "x-ratelimit-remaining": "0",
          "x-ratelimit-reset": "1792100000",
        },
      });

    let caught: GitHubApiError | null = null;
    try {
      await fetchGitHubProfileAndRepos("gaearon", {
        bypassCache: true,
        fetchFn: mock429Fetch as typeof fetch,
      });
    } catch (err) {
      caught = err as GitHubApiError;
    }

    expect(caught).not.toBeNull();
    expect(caught?.code).toBe("RATE_LIMITED");
    expect(caught?.status).toBe(429);
    expect(caught?.resetAt).not.toBeNull();
  });

  it("aborts and throws UPSTREAM_TIMEOUT (504) when GitHub API headers exceed requestTimeoutMs", async () => {
    clearGitHubCache();

    const slowHeaderFetch = async (
      _input: RequestInfo | URL,
      init?: RequestInit
    ): Promise<Response> => {
      return new Promise((_resolve, reject) => {
        if (init?.signal) {
          init.signal.addEventListener("abort", () => {
            const abortErr = new Error("The operation was aborted");
            abortErr.name = "AbortError";
            reject(abortErr);
          });
        }
      });
    };

    let caught: GitHubApiError | null = null;
    try {
      await fetchGitHubProfileAndRepos("torvalds", {
        bypassCache: true,
        requestTimeoutMs: 25,
        fetchFn: slowHeaderFetch as typeof fetch,
      });
    } catch (err) {
      caught = err as GitHubApiError;
    }

    expect(caught).not.toBeNull();
    expect(caught?.code).toBe("UPSTREAM_TIMEOUT");
    expect(caught?.status).toBe(504);
  });

  it("aborts and throws UPSTREAM_TIMEOUT (504) when GitHub response headers arrive promptly but response body hangs", async () => {
    clearGitHubCache();

    const hangingBodyFetch = async (): Promise<Response> => {
      const res = new Response("{}", {
        status: 200,
        headers: { "content-type": "application/json" },
      });
      // Simulate a stalled body stream where .text()/.json() never resolves
      res.text = () => new Promise<string>(() => {});
      return res;
    };

    let caught: GitHubApiError | null = null;
    try {
      await fetchGitHubProfileAndRepos("torvalds", {
        bypassCache: true,
        requestTimeoutMs: 30,
        fetchFn: hangingBodyFetch as typeof fetch,
      });
    } catch (err) {
      caught = err as GitHubApiError;
    }

    expect(caught).not.toBeNull();
    expect(caught?.code).toBe("UPSTREAM_TIMEOUT");
    expect(caught?.status).toBe(504);
  });
});
