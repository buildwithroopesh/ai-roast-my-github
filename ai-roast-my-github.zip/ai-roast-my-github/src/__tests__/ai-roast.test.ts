import { describe, it, expect } from "vitest";
import {
  AiRoastError,
  buildOpenAiChatCompletionsBody,
  DEFAULT_AI_MODELS,
  generateAiRoastAnalysis,
  resolveAiProviderConfig,
  validateAiClaimsAgainstEvidence,
  validateRecommendationStack,
} from "@/lib/ai-roast";
import {
  buildStructuredEvidenceForAI,
  classifyPersonality,
  computeTrustworthyScores,
  normalizeGitHubMetrics,
} from "@/lib/scoring";
import { DEMO_FIXTURES } from "@/lib/fixtures";

describe("Server-Side AI Integration, Evidence Integrity & Timeouts", () => {
  const sampleUser = DEMO_FIXTURES.torvalds.user;
  const sampleRepos = DEMO_FIXTURES.torvalds.repos;
  const analysis = normalizeGitHubMetrics(sampleUser, sampleRepos);
  const scores = computeTrustworthyScores(sampleUser, analysis);
  const personality = classifyPersonality(sampleUser, analysis, scores);
  const evidence = buildStructuredEvidenceForAI(
    sampleUser,
    analysis,
    scores,
    personality
  );

  it("defaults to Gemini (gemini-3.5-flash-lite) and requires explicit AI_PROVIDER for paid OpenAI (gpt-5.4-mini) or Anthropic (claude-haiku-5-5)", () => {
    expect(resolveAiProviderConfig({})).toBeNull();

    // Free-first Gemini default when AI_PROVIDER is omitted
    const geminiCfg = resolveAiProviderConfig({ GEMINI_API_KEY: "AIza-test" });
    expect(geminiCfg?.provider).toBe("gemini");
    expect(geminiCfg?.model).toBe(DEFAULT_AI_MODELS.gemini);
    expect(geminiCfg?.model).toBe("gemini-3.5-flash-lite");

    // When multiple keys are present and AI_PROVIDER is omitted, Gemini wins as free-first default
    const multiKeyCfg = resolveAiProviderConfig({
      GEMINI_API_KEY: "AIza-test",
      OPENAI_API_KEY: "sk-test-123",
      ANTHROPIC_API_KEY: "sk-ant-test",
    });
    expect(multiKeyCfg?.provider).toBe("gemini");
    expect(multiKeyCfg?.model).toBe("gemini-3.5-flash-lite");

    // Paid OpenAI provider is ONLY selected when AI_PROVIDER="openai" is explicitly configured
    expect(
      resolveAiProviderConfig({ OPENAI_API_KEY: "sk-test-123" })
    ).toBeNull();
    const openaiCfg = resolveAiProviderConfig({
      AI_PROVIDER: "openai",
      OPENAI_API_KEY: "sk-test-123",
    });
    expect(openaiCfg?.provider).toBe("openai");
    expect(openaiCfg?.model).toBe(DEFAULT_AI_MODELS.openai);
    expect(openaiCfg?.model).toBe("gpt-5.4-mini");

    // Paid Anthropic provider is ONLY selected when AI_PROVIDER="anthropic" is explicitly configured
    expect(
      resolveAiProviderConfig({ ANTHROPIC_API_KEY: "sk-ant-test" })
    ).toBeNull();
    const anthropicCfg = resolveAiProviderConfig({
      AI_PROVIDER: "anthropic",
      ANTHROPIC_API_KEY: "sk-ant-test",
    });
    expect(anthropicCfg?.provider).toBe("anthropic");
    expect(anthropicCfg?.model).toBe(DEFAULT_AI_MODELS.anthropic);
    expect(anthropicCfg?.model).toBe("claude-haiku-5-5");

    // Custom AI_MODEL override
    const customCfg = resolveAiProviderConfig({
      AI_PROVIDER: "openai",
      GEMINI_API_KEY: "AIza-test",
      OPENAI_API_KEY: "sk-test-123",
      AI_MODEL: "gpt-5.4",
    });
    expect(customCfg?.provider).toBe("openai");
    expect(customCfg?.model).toBe("gpt-5.4");
  });

  it("never falls back to paid OpenAI or Anthropic when AI_PROVIDER is gemini or omitted and GEMINI_API_KEY is missing", async () => {
    // 1. AI_PROVIDER=gemini with missing GEMINI_API_KEY, even when paid keys are present
    expect(
      resolveAiProviderConfig({
        AI_PROVIDER: "gemini",
        OPENAI_API_KEY: "sk-paid-openai",
        ANTHROPIC_API_KEY: "sk-ant-paid",
      })
    ).toBeNull();

    // 2. AI_PROVIDER omitted with missing GEMINI_API_KEY, even when paid keys are present
    expect(
      resolveAiProviderConfig({
        OPENAI_API_KEY: "sk-paid-openai",
        ANTHROPIC_API_KEY: "sk-ant-paid",
      })
    ).toBeNull();

    let paidNetworkCalls = 0;
    const forbiddenPaidFetch = async (): Promise<Response> => {
      paidNetworkCalls++;
      throw new Error("Should never make a paid provider request implicitly");
    };

    let caughtImplicit: AiRoastError | null = null;
    try {
      await generateAiRoastAnalysis(
        sampleUser,
        analysis,
        scores,
        personality,
        evidence,
        {
          env: {
            AI_PROVIDER: "gemini",
            OPENAI_API_KEY: "sk-paid-openai",
            ANTHROPIC_API_KEY: "sk-ant-paid",
          },
          fetchFn: forbiddenPaidFetch as typeof fetch,
          allowHeuristicFallback: false,
          isDemoFixture: false,
        }
      );
    } catch (err) {
      caughtImplicit = err as AiRoastError;
    }

    expect(caughtImplicit).not.toBeNull();
    expect(caughtImplicit?.code).toBe("MISSING_AI_API_KEY");
    expect(caughtImplicit?.status).toBe(503);
    expect(caughtImplicit?.message).toContain("GEMINI_API_KEY");
    expect(paidNetworkCalls).toBe(0);
  });

  it("constructs Chat Completions payloads compatible with gpt-5.4-mini and reasoning-only overrides", () => {
    const gpt54MiniBody = buildOpenAiChatCompletionsBody(
      "gpt-5.4-mini",
      "sys",
      "usr"
    );
    expect(gpt54MiniBody.model).toBe("gpt-5.4-mini");
    expect(gpt54MiniBody.response_format).toEqual({ type: "json_object" });
    expect(gpt54MiniBody.reasoning_effort).toBe("none");
    expect(gpt54MiniBody.temperature).toBe(0.5);

    // Models that do not support reasoning_effort: "none" or custom temperature omit both
    const gpt6AstraBody = buildOpenAiChatCompletionsBody(
      "gpt-6-astra",
      "sys",
      "usr"
    );
    expect(gpt6AstraBody.model).toBe("gpt-6-astra");
    expect(gpt6AstraBody.response_format).toEqual({ type: "json_object" });
    expect(gpt6AstraBody.reasoning_effort).toBe(undefined);
    expect(gpt6AstraBody.temperature).toBe(undefined);
  });

  it("throws MISSING_AI_API_KEY (503) when no AI key is configured on live requests", async () => {
    let caught: AiRoastError | null = null;
    try {
      await generateAiRoastAnalysis(
        sampleUser,
        analysis,
        scores,
        personality,
        evidence,
        {
          env: {},
          allowHeuristicFallback: false,
          isDemoFixture: false,
        }
      );
    } catch (err) {
      caught = err as AiRoastError;
    }

    expect(caught).not.toBeNull();
    expect(caught?.code).toBe("MISSING_AI_API_KEY");
    expect(caught?.status).toBe(503);
    expect(caught?.message).toContain("GEMINI_API_KEY");
    expect(caught?.configurationHint).toContain("gemini-3.5-flash-lite");
    expect(caught?.configurationHint).toContain("gpt-5.4-mini");
  });

  it("validates AI claims against evidence and rejects invented numbers, hyphenated metric claims, and quoted/unquoted repo names", () => {
    const validClaim = validateAiClaimsAgainstEvidence(
      'With 184,500 stars on "linux" across 3 analyzed repos, your C codebase is legendary.',
      evidence,
      analysis
    );
    expect(validClaim.valid).toBe(true);

    // 1. Rejects large invented numbers
    const hallucinatedNumber = validateAiClaimsAgainstEvidence(
      "You have 999,999 stars and 412 repositories on GitHub.",
      evidence,
      analysis
    );
    expect(hallucinatedNumber.valid).toBe(false);
    expect(hallucinatedNumber.reason).toContain("UNGROUNDED_NUMBER");

    // 2. Rejects small numbers (0-10) or constants (30, 90) when not in evidence
    const smallInventedRepoCount = validateAiClaimsAgainstEvidence(
      "You have 8 repositories and 90 stars on your profile.",
      evidence,
      analysis
    );
    expect(smallInventedRepoCount.valid).toBe(false);
    expect(smallInventedRepoCount.reason).toContain("UNGROUNDED_NUMBER");

    // 3. Rejects cross-metric number misuse (7 is in publicRepos, but NOT in stars)
    const crossMetricMisuse = validateAiClaimsAgainstEvidence(
      "Your flagship repository has earned 7 stars in total.",
      evidence,
      analysis
    );
    expect(crossMetricMisuse.valid).toBe(false);
    expect(crossMetricMisuse.reason).toContain("UNGROUNDED_NUMBER");

    // 4. Rejects hyphenated cross-metric or ungrounded claims ("7-star", "8-repo")
    const hyphenatedStarMisuse = validateAiClaimsAgainstEvidence(
      'Your 7-star repository "linux" is written in C.',
      evidence,
      analysis
    );
    expect(hyphenatedStarMisuse.valid).toBe(false);
    expect(hyphenatedStarMisuse.reason).toContain("UNGROUNDED_NUMBER");

    const hyphenatedRepoMisuse = validateAiClaimsAgainstEvidence(
      "Your 8-repo profile is written in C.",
      evidence,
      analysis
    );
    expect(hyphenatedRepoMisuse.valid).toBe(false);
    expect(hyphenatedRepoMisuse.reason).toContain("UNGROUNDED_NUMBER");

    // 5. Rejects quoted and unquoted fabricated repository names
    const hallucinatedQuotedRepo = validateAiClaimsAgainstEvidence(
      'Your repository "phantom-blockchain-ai" has 720 stars.',
      evidence,
      analysis
    );
    expect(hallucinatedQuotedRepo.valid).toBe(false);
    expect(hallucinatedQuotedRepo.reason).toContain("UNGROUNDED_REPO_NAME");

    const hallucinatedUnquotedSlug = validateAiClaimsAgainstEvidence(
      "Your work on phantom-blockchain-ai shows questionable commit habits.",
      evidence,
      analysis
    );
    expect(hallucinatedUnquotedSlug.valid).toBe(false);
    expect(hallucinatedUnquotedSlug.reason).toContain("UNGROUNDED_REPO_NAME");

    const hallucinatedUnquotedContextual = validateAiClaimsAgainstEvidence(
      "In repository superkernel you wrote everything in C.",
      evidence,
      analysis
    );
    expect(hallucinatedUnquotedContextual.valid).toBe(false);
    expect(hallucinatedUnquotedContextual.reason).toContain(
      "UNGROUNDED_REPO_NAME"
    );
  });

  it("rejects repository topics when falsely referenced as repositories and separates followers from following", () => {
    // On torvalds/linux, "operating-system" and "kernel" are topics, NOT repository names.
    const topicUsedAsRepo = validateAiClaimsAgainstEvidence(
      'Your repository "operating-system" has 184,500 stars.',
      evidence,
      analysis
    );
    expect(topicUsedAsRepo.valid).toBe(false);
    expect(topicUsedAsRepo.reason).toContain("UNGROUNDED_REPO_NAME");

    const unquotedTopicUsedAsRepo = validateAiClaimsAgainstEvidence(
      "In project kernel you wrote C.",
      evidence,
      analysis
    );
    expect(unquotedTopicUsedAsRepo.valid).toBe(false);
    expect(unquotedTopicUsedAsRepo.reason).toContain("UNGROUNDED_REPO_NAME");

    // Topic explicitly labeled as a topic is allowed
    const validTopicReference = validateAiClaimsAgainstEvidence(
      'Your repository "linux" uses the topic "operating-system".',
      evidence,
      analysis
    );
    expect(validTopicReference.valid).toBe(true);

    // stealth-zero-repos has 12 followers and 4 following
    const stealthUser = DEMO_FIXTURES["stealth-zero-repos"].user;
    const stealthAnalysis = normalizeGitHubMetrics(stealthUser, []);
    const stealthScores = computeTrustworthyScores(stealthUser, stealthAnalysis);
    const stealthPersonality = classifyPersonality(
      stealthUser,
      stealthAnalysis,
      stealthScores
    );
    const stealthEvidence = buildStructuredEvidenceForAI(
      stealthUser,
      stealthAnalysis,
      stealthScores,
      stealthPersonality
    );

    // Swapping followers (12) and following (4) must be rejected
    const swappedFollowers = validateAiClaimsAgainstEvidence(
      "You have 4 followers on GitHub.",
      stealthEvidence,
      stealthAnalysis
    );
    expect(swappedFollowers.valid).toBe(false);
    expect(swappedFollowers.reason).toContain("UNGROUNDED_NUMBER");

    const swappedFollowing = validateAiClaimsAgainstEvidence(
      "You have 12 following on GitHub.",
      stealthEvidence,
      stealthAnalysis
    );
    expect(swappedFollowing.valid).toBe(false);
    expect(swappedFollowing.reason).toContain("UNGROUNDED_NUMBER");

    const accurateFollowersAndFollowing = validateAiClaimsAgainstEvidence(
      "You have 12 followers and 4 following on GitHub.",
      stealthEvidence,
      stealthAnalysis
    );
    expect(accurateFollowersAndFollowing.valid).toBe(true);
  });

  it("validates recommendation stacks and falls back when ungrounded stack items are supplied", () => {
    const validStack = validateRecommendationStack(
      ["C", "POSIX", "Makefile"],
      ["C", "GitHub Actions"],
      evidence,
      analysis
    );
    expect(validStack).toEqual(["C", "POSIX", "Makefile"]);

    const invalidStack = validateRecommendationStack(
      ["C", "FakeFramework9000", "QuantumScript"],
      ["C", "GitHub Actions"],
      evidence,
      analysis
    );
    expect(invalidStack).toEqual(["C", "GitHub Actions"]);
  });

  it("locks deterministic observedFact and metricBadge fields when merging valid Gemini (gemini-3.5-flash-lite) and explicit OpenAI (gpt-5.4-mini) interpretations", async () => {
    const mockAiPayload = {
      personalityExplanation: {
        tagline: "Maintains the kernel that runs the planet.",
        interpretation:
          'Observed 184,500 stars on "linux" confirms single-repo global gravity.',
      },
      shortCardRoast: "7 public repos, 186,670 stars, 100% C specialization.",
      lenses: {
        default: {
          headline:
            'With 184,500 stars on "linux" across 3 analyzed repos, you don\'t need framework churn.',
          paragraphs: [
            'Across 3 analyzed repositories and 7 total public repos, "linux" leads with 184,500 stars.',
            "All 3 analyzed repositories are written in C (100%).",
            'Your secondary repo "uemacs" has 1,450 stars while "test-tlb" sits at 720 stars.',
          ],
        },
      },
      receiptInterpretations: [
        "Quality and impact vastly outweigh repository quantity.",
      ],
      strengths: [
        {
          title: "Unmatched Systems Depth",
          observedFact: "AI TRYING TO OVERWRITE FACT WITH 999999",
          interpretation: "Sustained multi-decade systems engineering.",
          metricBadge: "AI FAKE BADGE",
        },
      ],
    };

    // 1. Test default free-first Gemini provider (gemini-3.5-flash-lite)
    const mockGeminiFetch = async (input: RequestInfo | URL): Promise<Response> => {
      expect(String(input)).toContain(
        "models/gemini-3.5-flash-lite:generateContent"
      );
      return new Response(
        JSON.stringify({
          candidates: [
            {
              content: {
                parts: [{ text: JSON.stringify(mockAiPayload) }],
              },
            },
          ],
        }),
        { status: 200 }
      );
    };

    const geminiResult = await generateAiRoastAnalysis(
      sampleUser,
      analysis,
      scores,
      personality,
      evidence,
      {
        env: { GEMINI_API_KEY: "AIza-live-test" },
        fetchFn: mockGeminiFetch as typeof fetch,
      }
    );

    expect(geminiResult.roast.generationSource).toBe("ai-live");
    expect(geminiResult.roast.aiModelUsed).toBe("gemini:gemini-3.5-flash-lite");
    expect(geminiResult.personality.tagline).toBe(
      "Maintains the kernel that runs the planet."
    );
    expect(geminiResult.roast.strengths[0].observedFact).not.toContain("999999");
    expect(geminiResult.roast.strengths[0].metricBadge).not.toBe("AI FAKE BADGE");

    // 2. Test explicit OpenAI provider (AI_PROVIDER=openai, gpt-5.4-mini) with multi-part content array
    const mockOpenAiFetch = async (
      _input: RequestInfo | URL,
      init?: RequestInit
    ): Promise<Response> => {
      const sentBody = JSON.parse(String(init?.body));
      expect(sentBody.model).toBe("gpt-5.4-mini");
      expect(sentBody.reasoning_effort).toBe("none");
      expect(sentBody.temperature).toBe(0.5);
      expect(sentBody.response_format).toEqual({ type: "json_object" });

      return new Response(
        JSON.stringify({
          choices: [
            {
              message: {
                content: [{ type: "text", text: JSON.stringify(mockAiPayload) }],
              },
            },
          ],
        }),
        { status: 200 }
      );
    };

    const openAiResult = await generateAiRoastAnalysis(
      sampleUser,
      analysis,
      scores,
      personality,
      evidence,
      {
        env: { AI_PROVIDER: "openai", OPENAI_API_KEY: "sk-live-test" },
        fetchFn: mockOpenAiFetch as typeof fetch,
      }
    );

    expect(openAiResult.roast.generationSource).toBe("ai-live");
    expect(openAiResult.roast.aiModelUsed).toBe("openai:gpt-5.4-mini");

    // 3. Test OpenAI refusal handling in response parser
    const mockRefusalFetch = async (): Promise<Response> =>
      new Response(
        JSON.stringify({
          choices: [
            {
              message: {
                content: null,
                refusal: "Safety refusal triggered",
              },
            },
          ],
        }),
        { status: 200 }
      );

    let refusalErr: AiRoastError | null = null;
    try {
      await generateAiRoastAnalysis(
        sampleUser,
        analysis,
        scores,
        personality,
        evidence,
        {
          env: { AI_PROVIDER: "openai", OPENAI_API_KEY: "sk-live-test" },
          fetchFn: mockRefusalFetch as typeof fetch,
        }
      );
    } catch (err) {
      refusalErr = err as AiRoastError;
    }
    expect(refusalErr).not.toBeNull();
    expect(refusalErr?.code).toBe("AI_PROVIDER_ERROR");
    expect(refusalErr?.message).toContain("Safety refusal triggered");
  });

  it("throws AI_EVIDENCE_VIOLATION (502) when AI fabricates statistics or unquoted repo names in primary roast", async () => {
    const hallucinatedPayload = {
      lenses: {
        default: {
          headline:
            "Across 3 analyzed repos, your project fake-kernel-2000 is broken.",
          paragraphs: ["Completely invented repository reference."],
        },
      },
    };

    const mockFetch = async (): Promise<Response> =>
      new Response(
        JSON.stringify({
          choices: [
            {
              message: {
                content: JSON.stringify(hallucinatedPayload),
              },
            },
          ],
        }),
        { status: 200 }
      );

    let caught: AiRoastError | null = null;
    try {
      await generateAiRoastAnalysis(
        sampleUser,
        analysis,
        scores,
        personality,
        evidence,
        {
          env: { AI_PROVIDER: "openai", OPENAI_API_KEY: "sk-live-test" },
          fetchFn: mockFetch as typeof fetch,
        }
      );
    } catch (err) {
      caught = err as AiRoastError;
    }

    expect(caught).not.toBeNull();
    expect(caught?.code).toBe("AI_EVIDENCE_VIOLATION");
    expect(caught?.status).toBe(502);
  });

  it("throws AI_PROVIDER_TIMEOUT (504) when upstream AI call headers exceed timeoutMs", async () => {
    const slowAiFetch = async (
      _input: RequestInfo | URL,
      init?: RequestInit
    ): Promise<Response> => {
      return new Promise((_resolve, reject) => {
        if (init?.signal) {
          init.signal.addEventListener("abort", () => {
            const abortErr = new Error("Aborted");
            abortErr.name = "AbortError";
            reject(abortErr);
          });
        }
      });
    };

    let caught: AiRoastError | null = null;
    try {
      await generateAiRoastAnalysis(
        sampleUser,
        analysis,
        scores,
        personality,
        evidence,
        {
          env: { GEMINI_API_KEY: "AIza-live-test" },
          timeoutMs: 25,
          fetchFn: slowAiFetch as typeof fetch,
        }
      );
    } catch (err) {
      caught = err as AiRoastError;
    }

    expect(caught).not.toBeNull();
    expect(caught?.code).toBe("AI_PROVIDER_TIMEOUT");
    expect(caught?.status).toBe(504);
  });

  it("throws AI_PROVIDER_TIMEOUT (504) when AI response headers arrive promptly but response body hangs", async () => {
    const hangingAiBodyFetch = async (): Promise<Response> => {
      const res = new Response("{}", {
        status: 200,
        headers: { "content-type": "application/json" },
      });
      res.text = () => new Promise<string>(() => {});
      return res;
    };

    let caught: AiRoastError | null = null;
    try {
      await generateAiRoastAnalysis(
        sampleUser,
        analysis,
        scores,
        personality,
        evidence,
        {
          env: { GEMINI_API_KEY: "AIza-live-test" },
          timeoutMs: 30,
          fetchFn: hangingAiBodyFetch as typeof fetch,
        }
      );
    } catch (err) {
      caught = err as AiRoastError;
    }

    expect(caught).not.toBeNull();
    expect(caught?.code).toBe("AI_PROVIDER_TIMEOUT");
    expect(caught?.status).toBe(504);
  });
});
