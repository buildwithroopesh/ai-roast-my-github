import { describe, it, expect } from "vitest";
import { NextRequest } from "next/server";
import { GET } from "@/app/api/roast/route";
import { assembleRoastReport } from "@/lib/analyzer";
import { DEMO_FIXTURES } from "@/lib/fixtures";
import { buildCoverageNotice, clearGitHubCache } from "@/lib/github";
import {
  buildRateLimitHeaders,
  checkRateLimit,
  extractClientIp,
  generateRequestMemberId,
  isValidIpAddress,
  REDIS_SLIDING_WINDOW_LUA,
  resetRateLimiterState,
} from "@/lib/rate-limit";

describe("API Rate Limiting, Proxy Trust, Atomic Redis Lua EVAL & Route Integration Tests", () => {
  it("extracts client IP safely, disables all forwarded headers when TRUST_PROXY=false, and rejects malformed IPv6 inputs", () => {
    // Multiple forwarded addresses
    const multiForwarded = new Headers({
      "x-forwarded-for": "203.0.113.195, 70.41.3.18, 150.172.238.178",
    });
    expect(extractClientIp(multiForwarded, { TRUST_PROXY: "true" })).toBe(
      "203.0.113.195"
    );

    // Spoofed non-IP token followed by valid IP
    const spoofedInvalid = new Headers({
      "x-forwarded-for": "not-an-ip-script, 198.51.100.7",
    });
    expect(extractClientIp(spoofedInvalid, { TRUST_PROXY: "true" })).toBe(
      "198.51.100.7"
    );

    // TRUST_PROXY=false must disable ALL forwarded headers, including x-vercel-forwarded-for and cf-connecting-ip
    const spoofedPlatformHeaders = new Headers({
      "x-vercel-forwarded-for": "203.0.113.50",
      "cf-connecting-ip": "203.0.113.51",
      "x-real-ip": "203.0.113.52",
      "x-forwarded-for": "203.0.113.53",
    });
    expect(
      extractClientIp(spoofedPlatformHeaders, { TRUST_PROXY: "false" })
    ).toBe("127.0.0.1");

    // When TRUST_PROXY=false and a valid runtimePeerIp is provided by the runtime, it uses runtimePeerIp while ignoring spoofed headers
    expect(
      extractClientIp(
        spoofedPlatformHeaders,
        { TRUST_PROXY: "false" },
        "198.51.100.77"
      )
    ).toBe("198.51.100.77");

    // Malformed IPv6 inputs must be rejected
    expect(isValidIpAddress(":::")).toBe(false);
    expect(isValidIpAddress("2001::85a3::8a2e")).toBe(false);
    expect(isValidIpAddress("12345::1")).toBe(false);
    expect(isValidIpAddress(":1")).toBe(false);
    expect(isValidIpAddress("fe80:1:2:3:4:5:6:7:8:9")).toBe(false);

    // Valid IPv6 and IPv4 addresses are accepted
    expect(isValidIpAddress("2001:db8::1")).toBe(true);
    expect(isValidIpAddress("203.0.113.195")).toBe(true);

    const malformedIpv6Headers = new Headers({
      "x-vercel-forwarded-for": ":::, 2001::85a3::8a2e",
      "cf-connecting-ip": "12345::1",
      "x-forwarded-for": "2001:db8::1, 198.51.100.2",
    });
    expect(extractClientIp(malformedIpv6Headers, { TRUST_PROXY: "true" })).toBe(
      "2001:db8::1"
    );
  });

  it("shares the fallback 127.0.0.1 rate-limit key across all callers when TRUST_PROXY=false and no runtime peer IP is available", async () => {
    resetRateLimiterState();
    const nowMs = 1_700_000_000_000;
    const untrustedEnv = { TRUST_PROXY: "false" };

    // Two distinct callers send different spoofed headers, but with TRUST_PROXY=false and no runtimePeerIp,
    // both resolve to the shared key "127.0.0.1" and share the same maxRequests=2 bucket.
    const caller1Ip = extractClientIp(
      new Headers({ "x-forwarded-for": "203.0.113.10" }),
      untrustedEnv
    );
    const caller2Ip = extractClientIp(
      new Headers({ "cf-connecting-ip": "198.51.100.20" }),
      untrustedEnv
    );
    const caller3Ip = extractClientIp(
      new Headers({ "x-vercel-forwarded-for": "192.0.2.30" }),
      untrustedEnv
    );

    expect(caller1Ip).toBe("127.0.0.1");
    expect(caller2Ip).toBe("127.0.0.1");
    expect(caller3Ip).toBe("127.0.0.1");

    const res1 = await checkRateLimit(caller1Ip, {
      maxRequests: 2,
      globalMaxPerMinute: 60,
      nowFn: () => nowMs,
      env: untrustedEnv,
    });
    const res2 = await checkRateLimit(caller2Ip, {
      maxRequests: 2,
      globalMaxPerMinute: 60,
      nowFn: () => nowMs + 50,
      env: untrustedEnv,
    });
    const res3 = await checkRateLimit(caller3Ip, {
      maxRequests: 2,
      globalMaxPerMinute: 60,
      nowFn: () => nowMs + 100,
      env: untrustedEnv,
    });

    expect(res1.allowed).toBe(true);
    expect(res2.allowed).toBe(true);
    expect(res3.allowed).toBe(false);
    expect(res3.reason).toBe("IP_LIMIT_EXCEEDED");
  });

  it("generates collision-free member IDs across concurrent requests at the same timestamp", () => {
    const fixedTs = 1_700_000_000_000;
    const ids = new Set<string>();
    for (let i = 0; i < 100; i++) {
      ids.add(generateRequestMemberId(fixedTs));
    }
    expect(ids.size).toBe(100);
  });

  it("enforces per-IP sliding window rate limits and ensures a blocked IP cannot consume the global budget", async () => {
    resetRateLimiterState();
    const nowMs = 1_700_000_000_000;

    // IP 1 has a limit of 2; global limit is 3
    const r1 = await checkRateLimit("198.51.100.42", {
      maxRequests: 2,
      globalMaxPerMinute: 3,
      windowMs: 60_000,
      nowFn: () => nowMs,
      env: {},
    });
    const r2 = await checkRateLimit("198.51.100.42", {
      maxRequests: 2,
      globalMaxPerMinute: 3,
      windowMs: 60_000,
      nowFn: () => nowMs + 100,
      env: {},
    });

    // IP 1 sends 5 more blocked requests; these MUST NOT consume the 3rd global slot!
    for (let i = 0; i < 5; i++) {
      const blocked = await checkRateLimit("198.51.100.42", {
        maxRequests: 2,
        globalMaxPerMinute: 3,
        windowMs: 60_000,
        nowFn: () => nowMs + 200 + i * 10,
        env: {},
      });
      expect(blocked.allowed).toBe(false);
      expect(blocked.reason).toBe("IP_LIMIT_EXCEEDED");
    }

    // IP 2 should still be allowed to use the 3rd global slot!
    const ip2Allowed = await checkRateLimit("198.51.100.99", {
      maxRequests: 2,
      globalMaxPerMinute: 3,
      windowMs: 60_000,
      nowFn: () => nowMs + 500,
      env: {},
    });
    expect(r1.allowed).toBe(true);
    expect(r2.allowed).toBe(true);
    expect(ip2Allowed.allowed).toBe(true);

    // Now the global budget (3) is full, so IP 3 is blocked by GLOBAL_BURST_EXCEEDED
    const ip3GlobalBlocked = await checkRateLimit("198.51.100.100", {
      maxRequests: 2,
      globalMaxPerMinute: 3,
      windowMs: 60_000,
      nowFn: () => nowMs + 600,
      env: {},
    });
    expect(ip3GlobalBlocked.allowed).toBe(false);
    expect(ip3GlobalBlocked.reason).toBe("GLOBAL_BURST_EXCEEDED");

    const headers = buildRateLimitHeaders(ip3GlobalBlocked);
    expect(headers["Retry-After"]).toBe("60");
    expect(headers["X-RateLimit-Remaining"]).toBe("0");
  });

  it("executes atomic Redis Lua EVAL script for concurrent requests and fails closed on Redis outage", async () => {
    resetRateLimiterState();
    const redisEnv = {
      UPSTASH_REDIS_REST_URL: "https://fake-redis.upstash.io",
      UPSTASH_REDIS_REST_TOKEN: "test-token",
    };

    // Simulate an in-memory Redis server executing the exact Lua EVAL commands concurrently
    const zsets = new Map<string, Array<{ score: number; member: string }>>();
    const capturedCommands: any[] = [];

    const mockAtomicRedisEvalFetch = async (
      _input: RequestInfo | URL,
      init?: RequestInit
    ): Promise<Response> => {
      const cmd = JSON.parse(String(init?.body));
      capturedCommands.push(cmd);

      const [
        op,
        script,
        numKeys,
        globalKey,
        ipKey,
        nowStr,
        winStr,
        globMaxStr,
        ipLimStr,
        memberId,
      ] = cmd;
      expect(op).toBe("EVAL");
      expect(script).toBe(REDIS_SLIDING_WINDOW_LUA);
      expect(numKeys).toBe("2");

      const nowMs = Number(nowStr);
      const windowMs = Number(winStr);
      const globalMax = Number(globMaxStr);
      const ipLimit = Number(ipLimStr);
      const windowStart = nowMs - windowMs;

      const gList = (zsets.get(globalKey) || []).filter(
        (x) => x.score > windowStart
      );
      const iList = (zsets.get(ipKey) || []).filter(
        (x) => x.score > windowStart
      );
      zsets.set(globalKey, gList);
      zsets.set(ipKey, iList);

      if (iList.length >= ipLimit) {
        const oldestTs = iList[0]?.score || nowMs;
        return new Response(
          JSON.stringify({
            result: [0, "IP_LIMIT_EXCEEDED", iList.length, oldestTs + windowMs],
          }),
          { status: 200 }
        );
      }

      if (gList.length >= globalMax) {
        const oldestGlobalTs = gList[0]?.score || nowMs;
        return new Response(
          JSON.stringify({
            result: [
              0,
              "GLOBAL_BURST_EXCEEDED",
              iList.length,
              oldestGlobalTs + windowMs,
            ],
          }),
          { status: 200 }
        );
      }

      iList.push({ score: nowMs, member: memberId });
      gList.push({ score: nowMs, member: memberId });
      zsets.set(ipKey, iList);
      zsets.set(globalKey, gList);

      return new Response(
        JSON.stringify({
          result: [1, "ALLOWED", iList.length, iList[0].score + windowMs],
        }),
        { status: 200 }
      );
    };

    // Fire 5 concurrent requests from the same IP with maxRequests = 2, globalMax = 4
    const nowMs = 1_700_000_000_000;
    const concurrentResults = await Promise.all(
      [1, 2, 3, 4, 5].map(() =>
        checkRateLimit("203.0.113.5", {
          maxRequests: 2,
          globalMaxPerMinute: 4,
          nowFn: () => nowMs,
          env: redisEnv,
          fetchFn: mockAtomicRedisEvalFetch as typeof fetch,
        })
      )
    );

    const allowedCount = concurrentResults.filter((r) => r.allowed).length;
    const ipBlockedCount = concurrentResults.filter(
      (r) => !r.allowed && r.reason === "IP_LIMIT_EXCEEDED"
    ).length;
    expect(allowedCount).toBe(2);
    expect(ipBlockedCount).toBe(3);

    // Verify all 5 concurrent requests generated distinct member IDs
    const memberIds = new Set(capturedCommands.map((c) => c[9]));
    expect(memberIds.size).toBe(5);

    // Verify that the 3 blocked requests from 203.0.113.5 did NOT consume the remaining 2 global slots
    const otherIpRes = await checkRateLimit("203.0.113.99", {
      maxRequests: 2,
      globalMaxPerMinute: 4,
      nowFn: () => nowMs,
      env: redisEnv,
      fetchFn: mockAtomicRedisEvalFetch as typeof fetch,
    });
    expect(otherIpRes.allowed).toBe(true);
    expect(zsets.get("airoast:sw:global")?.length).toBe(3);

    // Verify Redis outage fails closed
    const mockRedisDown = async (): Promise<Response> =>
      new Response("Internal Error", { status: 500 });

    const failClosed = await checkRateLimit("203.0.113.5", {
      maxRequests: 10,
      globalMaxPerMinute: 60,
      env: redisEnv,
      fetchFn: mockRedisDown as typeof fetch,
    });
    expect(failClosed.allowed).toBe(false);
    expect(failClosed.reason).toBe("RATE_LIMIT_BACKEND_UNAVAILABLE");
    expect(failClosed.backend).toBe("redis-unavailable");
  });

  it("executes GET /api/roast and blocks rate-limited requests with HTTP 429 before any GitHub or AI fetch occurs", async () => {
    resetRateLimiterState();
    clearGitHubCache();

    const origFetch = globalThis.fetch;
    const origMax = process.env.ROAST_RATE_LIMIT_MAX;
    process.env.ROAST_RATE_LIMIT_MAX = "1";

    let externalFetchCount = 0;
    globalThis.fetch = (async () => {
      externalFetchCount++;
      throw new Error("Should not be called when rate-limited");
    }) as unknown as typeof fetch;

    try {
      const req1 = new NextRequest(
        "http://localhost:3000/api/roast?username=torvalds&demo=true",
        { headers: { "x-forwarded-for": "192.0.2.88" } }
      );
      const res1 = await GET(req1);
      expect(res1.status).toBe(200);

      const req2 = new NextRequest(
        "http://localhost:3000/api/roast?username=torvalds",
        { headers: { "x-forwarded-for": "192.0.2.88" } }
      );
      const res2 = await GET(req2);
      const body2 = await res2.json();

      expect(res2.status).toBe(429);
      expect(body2.code).toBe("CLIENT_RATE_LIMITED");
      expect(res2.headers.get("Retry-After")).not.toBeNull();
      expect(res2.headers.get("X-RateLimit-Remaining")).toBe("0");
      expect(externalFetchCount).toBe(0);
    } finally {
      globalThis.fetch = origFetch;
      if (origMax === undefined) delete process.env.ROAST_RATE_LIMIT_MAX;
      else process.env.ROAST_RATE_LIMIT_MAX = origMax;
    }
  });

  it("executes GET /api/roast and rejects AI output containing unquoted fabricated repository names with HTTP 502", async () => {
    resetRateLimiterState();
    clearGitHubCache();

    const origFetch = globalThis.fetch;
    const origProvider = process.env.AI_PROVIDER;
    const origKey = process.env.OPENAI_API_KEY;
    process.env.AI_PROVIDER = "openai";
    process.env.OPENAI_API_KEY = "sk-test-route-key";

    globalThis.fetch = (async (input: RequestInfo | URL) => {
      const url = String(input);
      if (url.includes("api.github.com/users/torvalds/repos")) {
        return new Response(JSON.stringify(DEMO_FIXTURES.torvalds.repos), {
          status: 200,
        });
      }
      if (url.includes("api.github.com/users/torvalds")) {
        return new Response(JSON.stringify(DEMO_FIXTURES.torvalds.user), {
          status: 200,
        });
      }
      if (url.includes("api.openai.com/v1/chat/completions")) {
        return new Response(
          JSON.stringify({
            choices: [
              {
                message: {
                  content: JSON.stringify({
                    lenses: {
                      default: {
                        headline:
                          "Across 3 analyzed repos, your repository mysterykernel is a disaster.",
                        paragraphs: ["Unquoted repo fabrication test."],
                      },
                    },
                  }),
                },
              },
            ],
          }),
          { status: 200 }
        );
      }
      throw new Error(`Unexpected URL: ${url}`);
    }) as unknown as typeof fetch;

    try {
      const req = new NextRequest(
        "http://localhost:3000/api/roast?username=torvalds",
        { headers: { "x-forwarded-for": "192.0.2.99" } }
      );
      const res = await GET(req);
      const body = await res.json();

      expect(res.status).toBe(502);
      expect(body.code).toBe("AI_EVIDENCE_VIOLATION");
    } finally {
      globalThis.fetch = origFetch;
      if (origProvider === undefined) delete process.env.AI_PROVIDER;
      else process.env.AI_PROVIDER = origProvider;
      if (origKey === undefined) delete process.env.OPENAI_API_KEY;
      else process.env.OPENAI_API_KEY = origKey;
    }
  });

  it("returns HTTP 503 RATE_LIMIT_BACKEND_UNAVAILABLE from GET /api/roast when configured Redis is unreachable", async () => {
    resetRateLimiterState();
    const origFetch = globalThis.fetch;
    const origUrl = process.env.UPSTASH_REDIS_REST_URL;
    const origToken = process.env.UPSTASH_REDIS_REST_TOKEN;

    process.env.UPSTASH_REDIS_REST_URL = "https://unreachable-redis.upstash.io";
    process.env.UPSTASH_REDIS_REST_TOKEN = "token-123";

    let githubCalled = false;
    globalThis.fetch = (async (input: RequestInfo | URL) => {
      const url = String(input);
      if (url.includes("upstash.io")) {
        return new Response("Redis Down", { status: 500 });
      }
      githubCalled = true;
      return new Response("{}", { status: 200 });
    }) as unknown as typeof fetch;

    try {
      const req = new NextRequest(
        "http://localhost:3000/api/roast?username=torvalds",
        { headers: { "x-forwarded-for": "192.0.2.111" } }
      );
      const res = await GET(req);
      const body = await res.json();

      expect(res.status).toBe(503);
      expect(body.code).toBe("RATE_LIMIT_BACKEND_UNAVAILABLE");
      expect(res.headers.get("X-RateLimit-Backend")).toBe("redis-unavailable");
      expect(githubCalled).toBe(false);
    } finally {
      globalThis.fetch = origFetch;
      if (origUrl === undefined) delete process.env.UPSTASH_REDIS_REST_URL;
      else process.env.UPSTASH_REDIS_REST_URL = origUrl;
      if (origToken === undefined) delete process.env.UPSTASH_REDIS_REST_TOKEN;
      else process.env.UPSTASH_REDIS_REST_TOKEN = origToken;
    }
  });

  it("returns HTTP 504 UPSTREAM_TIMEOUT from GET /api/roast when upstream GitHub response body hangs", async () => {
    resetRateLimiterState();
    clearGitHubCache();

    const origFetch = globalThis.fetch;
    const origTimeout = process.env.GITHUB_REQUEST_TIMEOUT_MS;
    process.env.GITHUB_REQUEST_TIMEOUT_MS = "30";

    globalThis.fetch = (async () => {
      const res = new Response("{}", { status: 200 });
      res.text = () => new Promise<string>(() => {});
      return res;
    }) as unknown as typeof fetch;

    try {
      const req = new NextRequest(
        "http://localhost:3000/api/roast?username=torvalds",
        { headers: { "x-forwarded-for": "192.0.2.112" } }
      );
      const res = await GET(req);
      const body = await res.json();

      expect(res.status).toBe(504);
      expect(body.code).toBe("UPSTREAM_TIMEOUT");
    } finally {
      globalThis.fetch = origFetch;
      if (origTimeout === undefined)
        delete process.env.GITHUB_REQUEST_TIMEOUT_MS;
      else process.env.GITHUB_REQUEST_TIMEOUT_MS = origTimeout;
    }
  });

  it("assembles a complete RoastReport for explicit demo fixtures", async () => {
    const fixture = DEMO_FIXTURES.torvalds;
    const pagination = {
      totalPublicRepos: fixture.user.public_repos,
      fetchedRepoCount: fixture.repos.length,
      coveragePercentage: Math.round(
        (fixture.repos.length / fixture.user.public_repos) * 100
      ),
      pagesFetched: 1,
      maxPagesAllowed: 5,
      isComplete: false,
      truncationReason: "MAX_PAGES_REACHED" as const,
      coverageNotice: buildCoverageNotice(
        fixture.user.public_repos,
        fixture.repos.length,
        1,
        false,
        "MAX_PAGES_REACHED"
      ),
    };

    const report = await assembleRoastReport(
      fixture.user,
      fixture.repos,
      pagination,
      {
        limit: 60,
        remaining: 59,
        resetAt: null,
        cached: true,
        sourceLabel: "Explicit Demo Snapshot",
      },
      {
        isDemoFixture: true,
        allowHeuristicFallback: true,
      },
      new Date("2026-10-15T00:00:00Z")
    );

    expect(report.profile.username).toBe("torvalds");
    expect(report.analysis.pagination.isComplete).toBe(false);
    expect(report.analysis.pagination.coveragePercentage).toBe(43);
    expect(report.roast.generationSource).toBe("demo-fixture");
    expect(report.scores.breakdown.length).toBe(6);
    expect(report.roast.recommendations.length).toBe(3);
  });
});
