"use client";

import React, { useState } from "react";
import { RoastReport } from "@/types/roast";
import { sanitizeAndValidateUsername } from "@/lib/github";
import { Navbar } from "@/components/Navbar";
import { ErrorState, HeroSearch } from "@/components/HeroSearch";
import { TerminalLoader } from "@/components/TerminalLoader";
import { LandingPreview } from "@/components/LandingPreview";
import { ProfileBanner } from "@/components/ProfileBanner";
import { RoastSection } from "@/components/RoastSection";
import { ScoreSection } from "@/components/ScoreSection";
import { TelemetrySection } from "@/components/TelemetrySection";
import { RepositoryExplorer } from "@/components/RepositoryExplorer";
import { StrengthsAndFlags } from "@/components/StrengthsAndFlags";
import { RecommendationsSection } from "@/components/RecommendationsSection";
import { ShareableCard } from "@/components/ShareableCard";
import { ArchitectureModal } from "@/components/ArchitectureModal";

export default function HomePage() {
  const [usernameInput, setUsernameInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [loadingLogs, setLoadingLogs] = useState<string[]>([]);
  const [error, setError] = useState<ErrorState | null>(null);
  const [report, setReport] = useState<RoastReport | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2800);
  };

  const handleReset = () => {
    setError(null);
    setReport(null);
    setUsernameInput("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const runLiveInspection = async (
    overrideUsername?: string,
    allowFallback: boolean = false
  ) => {
    const rawTarget = overrideUsername ?? usernameInput;
    const validation = sanitizeAndValidateUsername(rawTarget);
    if (!validation.valid) {
      setError({
        title: "Invalid GitHub Username",
        message: validation.error || "Please enter a valid GitHub username.",
        code: "INVALID_USERNAME",
      });
      return;
    }

    const cleanUsername = validation.username;
    setUsernameInput(cleanUsername);
    setError(null);
    setLoading(true);
    setReport(null);
    setLoadingLogs([
      `Validating GitHub handle @${cleanUsername}...`,
      `GET /api/roast?username=${cleanUsername} (paginating public repositories)...`,
      `Computing heuristic scores & invoking server-side AI model...`,
    ]);

    try {
      const url = `/api/roast?username=${encodeURIComponent(cleanUsername)}${
        allowFallback ? "&fallback=true" : ""
      }`;
      const res = await fetch(url);
      const data = await res.json();

      if (!res.ok) {
        setError({
          title:
            data.code === "MISSING_AI_API_KEY"
              ? "Server AI Configuration Required"
              : data.code === "USER_NOT_FOUND"
              ? `User "@${cleanUsername}" Not Found (404)`
              : data.code === "RATE_LIMITED"
              ? "GitHub API Rate Limit Exceeded"
              : "Inspection Failed",
          message:
            data.error || "Unable to analyze this GitHub profile right now.",
          code: data.code,
          configurationHint: data.configurationHint,
        });
        return;
      }

      setReport(data as RoastReport);
    } catch {
      setError({
        title: "Network / Server Connection Failure",
        message:
          "Could not reach the /api/roast endpoint. Verify the Next.js server is running and try again.",
        code: "NETWORK_ERROR",
      });
    } finally {
      setLoading(false);
    }
  };

  const runDemoInspection = async (fixtureKey: string) => {
    setUsernameInput(fixtureKey);
    setError(null);
    setLoading(true);
    setReport(null);
    setLoadingLogs([
      `Loading explicit test fixture "${fixtureKey}"...`,
      `Running deterministic scoring & evidence synthesis...`,
    ]);

    try {
      const res = await fetch(
        `/api/roast?username=${encodeURIComponent(fixtureKey)}&demo=true`
      );
      const data = await res.json();
      if (!res.ok) {
        setError({
          title: "Demo Fixture Error",
          message: data.error || "Unable to load demo fixture.",
          code: data.code,
        });
        return;
      }
      setReport(data as RoastReport);
    } catch {
      setError({
        title: "Demo Request Failed",
        message: "Could not load the demo fixture from /api/roast.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="hero-glow min-h-screen flex flex-col justify-between">
      <Navbar
        rateLimit={report?.rateLimit ?? null}
        aiModelUsed={report?.roast.aiModelUsed ?? null}
        onReset={handleReset}
        onOpenModal={() => setModalOpen(true)}
      />

      <main className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8 py-10 sm:py-14 flex-1 space-y-12">
        <HeroSearch
          usernameInput={usernameInput}
          onUsernameChange={setUsernameInput}
          onSubmitLive={runLiveInspection}
          onSubmitDemo={runDemoInspection}
          loading={loading}
          error={error}
        />

        {loading && <TerminalLoader logs={loadingLogs} />}

        {!loading && !report && <LandingPreview />}

        {!loading && report && (
          <div className="space-y-10 animate-fade-in">
            <ProfileBanner report={report} />
            <RoastSection roast={report.roast} />
            <ScoreSection scores={report.scores} />
            <TelemetrySection analysis={report.analysis}>
              <RepositoryExplorer
                username={report.profile.username}
                analysis={report.analysis}
              />
            </TelemetrySection>
            <StrengthsAndFlags
              strengths={report.roast.strengths}
              redFlags={report.roast.redFlags}
            />
            <RecommendationsSection
              recommendations={report.roast.recommendations}
            />
            <ShareableCard report={report} onToast={triggerToast} />
          </div>
        )}
      </main>

      <footer className="border-t border-zinc-900 bg-zinc-950/90 py-6 mt-12">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <div className="flex items-center gap-2">
            <span className="font-bold text-zinc-300">AI Roast My GitHub</span>
            <span>—</span>
            <span>
              Every observation is computed from structured GitHub REST API
              evidence.
            </span>
          </div>
          <div className="font-mono text-[11px]">
            Next.js App Router • TypeScript • Tailwind CSS • Vitest
          </div>
        </div>
      </footer>

      <ArchitectureModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
      />

      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 rounded-xl border border-orange-500/40 bg-zinc-900/95 px-4 py-3 text-xs font-mono text-white shadow-2xl"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
}
