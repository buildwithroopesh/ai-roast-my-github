import { NextRequest, NextResponse } from "next/server";
import {
  buildCoverageNotice,
  fetchGitHubProfileAndRepos,
  GitHubApiError,
  sanitizeAndValidateUsername,
} from "@/lib/github";
import { DEMO_FIXTURES } from "@/lib/fixtures";
import { assembleRoastReport } from "@/lib/analyzer";
import { AiRoastError } from "@/lib/ai-roast";
import {
  buildRateLimitHeaders,
  checkRateLimit,
  extractClientIp,
} from "@/lib/rate-limit";

export async function GET(request: NextRequest) {
  // 1. Enforce rate limiting & abuse protection before any GitHub or AI work.
  // Pass runtime peer IP (`request.ip`) when provided by the hosting runtime.
  const runtimePeerIp = (request as NextRequest & { ip?: string }).ip ?? null;
  const clientIp = extractClientIp(request.headers, process.env, runtimePeerIp);
  const rateLimitResult = await checkRateLimit(clientIp);
  const rateLimitHeaders = buildRateLimitHeaders(rateLimitResult);

  if (!rateLimitResult.allowed) {
    if (rateLimitResult.reason === "RATE_LIMIT_BACKEND_UNAVAILABLE") {
      return NextResponse.json(
        {
          error:
            "Distributed rate-limit store (Redis) is currently unreachable. Requests are temporarily paused to protect service limits.",
          code: "RATE_LIMIT_BACKEND_UNAVAILABLE",
          retryAfterSeconds: rateLimitResult.retryAfterSeconds,
        },
        {
          status: 503,
          headers: rateLimitHeaders,
        }
      );
    }

    return NextResponse.json(
      {
        error:
          rateLimitResult.reason === "GLOBAL_BURST_EXCEEDED"
            ? `Server is experiencing high roast volume. Please wait ${rateLimitResult.retryAfterSeconds}s and try again.`
            : `Too many roast requests (${rateLimitResult.limit} requests/min limit). Please wait ${rateLimitResult.retryAfterSeconds}s before trying again.`,
        code: "CLIENT_RATE_LIMITED",
        retryAfterSeconds: rateLimitResult.retryAfterSeconds,
      },
      {
        status: 429,
        headers: rateLimitHeaders,
      }
    );
  }

  const { searchParams } = new URL(request.url);
  const rawUsername = searchParams.get("username") || "";
  const isDemoRequest = searchParams.get("demo") === "true";
  const allowFallbackParam = searchParams.get("fallback") === "true";
  const maxPagesParam = Number(searchParams.get("maxPages") || "0");

  try {
    // Explicit Demo Fixture mode (only when ?demo=true is explicitly passed)
    if (isDemoRequest) {
      const cleanedKey = rawUsername.trim().toLowerCase().replace(/^@/, "");
      const fixture = DEMO_FIXTURES[cleanedKey];
      if (!fixture) {
        return NextResponse.json(
          {
            error: `Demo fixture "${cleanedKey}" does not exist. Available demo fixtures: ${Object.keys(
              DEMO_FIXTURES
            ).join(", ")}.`,
            code: "USER_NOT_FOUND",
          },
          { status: 404, headers: rateLimitHeaders }
        );
      }

      const pagination = {
        totalPublicRepos: fixture.user.public_repos,
        fetchedRepoCount: fixture.repos.length,
        coveragePercentage:
          fixture.user.public_repos === 0
            ? 100
            : Math.round(
                (fixture.repos.length /
                  Math.max(1, fixture.user.public_repos)) *
                  100
              ),
        pagesFetched: 1,
        maxPagesAllowed: 5,
        isComplete: fixture.repos.length >= fixture.user.public_repos,
        truncationReason:
          fixture.repos.length < fixture.user.public_repos
            ? ("MAX_PAGES_REACHED" as const)
            : null,
        coverageNotice: buildCoverageNotice(
          fixture.user.public_repos,
          fixture.repos.length,
          1,
          fixture.repos.length >= fixture.user.public_repos,
          fixture.repos.length < fixture.user.public_repos
            ? "MAX_PAGES_REACHED"
            : null
        ),
      };

      const report = await assembleRoastReport(
        fixture.user,
        fixture.repos,
        pagination,
        {
          limit: 60,
          remaining: 60,
          resetAt: null,
          cached: true,
          sourceLabel: "Explicit Demo Snapshot",
        },
        {
          isDemoFixture: true,
          allowHeuristicFallback: true,
        }
      );

      return NextResponse.json(report, {
        status: 200,
        headers: rateLimitHeaders,
      });
    }

    // Live GitHub REST API + Server-Side AI Flow
    const validation = sanitizeAndValidateUsername(rawUsername);
    if (!validation.valid) {
      return NextResponse.json(
        {
          error: validation.error || "Invalid GitHub username.",
          code: "INVALID_USERNAME",
        },
        { status: 400, headers: rateLimitHeaders }
      );
    }

    const { user, repos, pagination, rateLimit } =
      await fetchGitHubProfileAndRepos(validation.username, {
        maxPages:
          Number.isFinite(maxPagesParam) && maxPagesParam > 0
            ? Math.min(10, maxPagesParam)
            : undefined,
      });

    const report = await assembleRoastReport(
      user,
      repos,
      pagination,
      rateLimit,
      {
        allowHeuristicFallback: allowFallbackParam,
      }
    );

    return NextResponse.json(report, {
      status: 200,
      headers: {
        ...rateLimitHeaders,
        "Cache-Control": "public, s-maxage=300, stale-while-revalidate=600",
      },
    });
  } catch (err) {
    if (err instanceof GitHubApiError) {
      return NextResponse.json(
        {
          error: err.message,
          code: err.code,
          resetAt: err.resetAt,
        },
        { status: err.status, headers: rateLimitHeaders }
      );
    }

    if (err instanceof AiRoastError) {
      return NextResponse.json(
        {
          error: err.message,
          code: err.code,
          configurationHint: err.configurationHint,
        },
        { status: err.status, headers: rateLimitHeaders }
      );
    }

    return NextResponse.json(
      {
        error:
          "An unexpected server error occurred while analyzing the GitHub profile.",
        code: "INTERNAL_ERROR",
      },
      { status: 500, headers: rateLimitHeaders }
    );
  }
}
