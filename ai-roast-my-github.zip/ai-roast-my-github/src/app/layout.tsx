import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI Roast My GitHub — Developer Profile Analyzer & Roast Generator",
  description:
    "Let AI inspect your public repositories, analyze your coding habits, and roast your GitHub profile with evidence-backed metrics.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen subtle-grid selection:bg-orange-500/30 selection:text-orange-200">
        {children}
      </body>
    </html>
  );
}
