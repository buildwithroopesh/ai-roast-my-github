import {
  DeveloperPersonality,
  DeveloperScores,
  GitHubAnalysisMetrics,
  GitHubRepo,
  GitHubUser,
  LanguageStat,
  PaginationMeta,
  RepoSummary,
  StructuredGitHubEvidence,
} from "@/types/roast";

export const LANGUAGE_COLORS: Record<string, string> = {
  TypeScript: "#3178c6",
  JavaScript: "#f1e05a",
  Python: "#3572A5",
  Rust: "#dea584",
  Go: "#00ADD8",
  Java: "#b07219",
  "C++": "#f34b7d",
  C: "#6b7280",
  "C#": "#178600",
  HTML: "#e34c26",
  CSS: "#563d7c",
  Shell: "#89e051",
  Swift: "#F05138",
  Kotlin: "#A97BFF",
  Ruby: "#701516",
  PHP: "#4F5D95",
  Dart: "#00B4AB",
  Vue: "#41b883",
  Svelte: "#ff3e00",
  Astro: "#ff5a03",
  Zig: "#ec915c",
  Lua: "#3b82f6",
};

export function clampScore(value: number): number {
  const bounded = Math.max(0, Math.min(10, value));
  return Math.round(bounded * 10) / 10;
}

export function daysBetween(dateIso: string | null | undefined, referenceMs: number): number {
  if (!dateIso) return 999;
  const parsed = Date.parse(dateIso);
  if (Number.isNaN(parsed)) return 999;
  return Math.max(0, Math.floor((referenceMs - parsed) / (1000 * 60 * 60 * 24)));
}

/**
 * Pure normalization function that transforms raw GitHub user + repo payloads
 * into verifiable metrics while handling partial/missing fields safely.
 */
export function normalizeGitHubMetrics(
  user: GitHubUser,
  repos: GitHubRepo[],
  pagination?: PaginationMeta,
  referenceDate: Date = new Date()
): GitHubAnalysisMetrics {
  const nowMs = referenceDate.getTime();
  const safeRepos = Array.isArray(repos)
    ? repos.filter((r): r is GitHubRepo => Boolean(r && typeof r === "object"))
    : [];

  const accountCreatedMs = Date.parse(user?.created_at || "");
  const accountAgeDays = Number.isNaN(accountCreatedMs)
    ? 365
    : Math.max(1, Math.floor((nowMs - accountCreatedMs) / (1000 * 60 * 60 * 24)));
  const accountAgeYears = Math.max(
    0.1,
    Math.round((accountAgeDays / 365.25) * 10) / 10
  );

  const normalizedRepos: RepoSummary[] = safeRepos.map((r, index) => {
    const createdIso = r.created_at || new Date(nowMs).toISOString();
    const pushedIso = r.pushed_at || r.updated_at || createdIso;
    const createdMs = Date.parse(createdIso);
    const pushedMs = Date.parse(pushedIso);

    const activeLifespanHours =
      !Number.isNaN(createdMs) && !Number.isNaN(pushedMs)
        ? Math.max(0, (pushedMs - createdMs) / (1000 * 60 * 60))
        : 0;
    const activeLifespanDays = Math.round((activeLifespanHours / 24) * 10) / 10;

    const daysSinceLastPush = daysBetween(pushedIso, nowMs);
    const sizeKb = Math.max(0, Number(r.size) || 0);
    const isFork = Boolean(r.fork);

    // A repository is only flagged as "initialCommitOnly" if it is an original repo,
    // had its final push within 24 hours of creation, is small (< 35 KB), and is older than 14 days.
    // Substantive or multi-day repositories that haven't been pushed recently are treated as stable/completed.
    const initialCommitOnly =
      !isFork &&
      activeLifespanHours <= 24 &&
      sizeKb < 35 &&
      daysSinceLastPush > 14;

    const isStableInactive =
      daysSinceLastPush > 365 &&
      !initialCommitOnly &&
      (activeLifespanHours > 48 || sizeKb >= 35 || (Number(r.stargazers_count) || 0) > 0);

    const rawDesc = typeof r.description === "string" ? r.description.trim() : "";
    const rawHomepage = typeof r.homepage === "string" ? r.homepage.trim() : "";
    const topics = Array.isArray(r.topics)
      ? r.topics.filter((t): t is string => typeof t === "string" && t.trim().length > 0)
      : [];

    return {
      name:
        typeof r.name === "string" && r.name.trim().length > 0
          ? r.name.trim()
          : `repo-${index + 1}`,
      htmlUrl:
        typeof r.html_url === "string" && r.html_url.trim().length > 0
          ? r.html_url.trim()
          : `https://github.com/${user?.login || "unknown"}`,
      description: rawDesc.length > 0 ? rawDesc : null,
      language:
        typeof r.language === "string" && r.language.trim().length > 0
          ? r.language.trim()
          : null,
      stars: Math.max(0, Number(r.stargazers_count) || 0),
      forks: Math.max(0, Number(r.forks_count) || 0),
      isFork,
      isArchived: Boolean(r.archived),
      sizeKb,
      createdAt: createdIso,
      pushedAt: pushedIso,
      daysSinceLastPush,
      activeLifespanDays,
      initialCommitOnly,
      isStableInactive,
      topics,
      hasHomepage: rawHomepage.length > 0,
      hasLicense: Boolean(r.license && r.license.name),
      hasPagesOrWiki: Boolean(r.has_pages || r.has_wiki),
    };
  });

  const analyzedRepoCount = normalizedRepos.length;
  const publicRepoCount = Math.max(
    Number(user?.public_repos) || 0,
    analyzedRepoCount
  );
  const originalRepos = normalizedRepos.filter((r) => !r.isFork);
  const forkRepos = normalizedRepos.filter((r) => r.isFork);
  const originalRepoCount = originalRepos.length;
  const forkRepoCount = forkRepos.length;
  const originalPercentage =
    analyzedRepoCount > 0
      ? Math.round((originalRepoCount / analyzedRepoCount) * 100)
      : 0;

  const totalStars = normalizedRepos.reduce((acc, r) => acc + r.stars, 0);
  const originalStars = originalRepos.reduce((acc, r) => acc + r.stars, 0);
  const totalForks = normalizedRepos.reduce((acc, r) => acc + r.forks, 0);

  const activeLast30Days = normalizedRepos.filter(
    (r) => r.daysSinceLastPush <= 30
  ).length;
  const activeLast90Days = normalizedRepos.filter(
    (r) => r.daysSinceLastPush <= 90
  ).length;
  const activeLast365Days = normalizedRepos.filter(
    (r) => r.daysSinceLastPush <= 365
  ).length;
  const inactiveOver1YearCount = normalizedRepos.filter(
    (r) => r.daysSinceLastPush > 365
  ).length;
  const stableCompletedCount = normalizedRepos.filter(
    (r) => r.isStableInactive
  ).length;

  const daysSinceLastActive =
    normalizedRepos.length > 0
      ? Math.min(...normalizedRepos.map((r) => r.daysSinceLastPush))
      : daysBetween(user?.updated_at || user?.created_at, nowMs);

  const initialCommitOnlyCount = originalRepos.filter(
    (r) => r.initialCommitOnly
  ).length;

  const substantiveOriginalCount = originalRepos.filter(
    (r) => r.sizeKb >= 25 || r.activeLifespanDays >= 3
  ).length;

  const poolForMetadata =
    originalRepos.length > 0 ? originalRepos : normalizedRepos;
  const missingDescriptionCount = poolForMetadata.filter(
    (r) => !r.description
  ).length;
  const missingDescriptionPercent =
    poolForMetadata.length > 0
      ? Math.round((missingDescriptionCount / poolForMetadata.length) * 100)
      : 100;

  const reposWithTopicsCount = normalizedRepos.filter(
    (r) => r.topics.length > 0
  ).length;
  const reposWithHomepageCount = normalizedRepos.filter(
    (r) => r.hasHomepage
  ).length;
  const reposWithLicenseCount = normalizedRepos.filter(
    (r) => r.hasLicense
  ).length;
  const reposWithDocsSignalCount = poolForMetadata.filter(
    (r) =>
      Boolean(r.description) ||
      r.hasHomepage ||
      r.topics.length > 0 ||
      r.hasPagesOrWiki
  ).length;

  // Language distribution across original repos (fallback to all repos if all are forks)
  const langSource = originalRepos.length > 0 ? originalRepos : normalizedRepos;
  const langMap = new Map<
    string,
    { count: number; stars: number; sizeKb: number }
  >();

  for (const r of langSource) {
    if (!r.language) continue;
    const prev = langMap.get(r.language) || { count: 0, stars: 0, sizeKb: 0 };
    langMap.set(r.language, {
      count: prev.count + 1,
      stars: prev.stars + r.stars,
      sizeKb: prev.sizeKb + r.sizeKb,
    });
  }

  const totalLangTagged = Array.from(langMap.values()).reduce(
    (sum, item) => sum + item.count,
    0
  );

  const languages: LanguageStat[] = Array.from(langMap.entries())
    .map(([language, stats]) => ({
      language,
      repoCount: stats.count,
      percentage:
        totalLangTagged > 0
          ? Math.round((stats.count / totalLangTagged) * 100)
          : 0,
      stars: stats.stars,
      sizeKb: stats.sizeKb,
      color: LANGUAGE_COLORS[language] || "#f97316",
    }))
    .sort(
      (a, b) =>
        b.repoCount - a.repoCount ||
        b.sizeKb - a.sizeKb ||
        b.stars - a.stars
    );

  const topLanguage =
    languages.length > 0 ? languages[0].language : "None / Markdown";

  let languageSpecialization:
    | "Polyglot"
    | "Focused Specialist"
    | "Dual-Stack"
    | "Unclassified" = "Unclassified";
  if (languages.length >= 4) {
    languageSpecialization = "Polyglot";
  } else if (languages.length === 2 || languages.length === 3) {
    languageSpecialization =
      languages[0].percentage >= 80 ? "Focused Specialist" : "Dual-Stack";
  } else if (languages.length === 1) {
    languageSpecialization = "Focused Specialist";
  }

  // Sort most active / notable repos by substance, lifespan, recency, and community usage
  const mostActiveRepos = [...normalizedRepos]
    .sort((a, b) => {
      const scoreA =
        (a.isFork ? 0 : 20) +
        Math.min(30, a.activeLifespanDays * 0.4) +
        Math.min(25, Math.log10(a.sizeKb + 1) * 8) +
        Math.min(25, Math.log10(a.stars + a.forks + 1) * 8) +
        Math.max(0, 180 - a.daysSinceLastPush) * 0.08;
      const scoreB =
        (b.isFork ? 0 : 20) +
        Math.min(30, b.activeLifespanDays * 0.4) +
        Math.min(25, Math.log10(b.sizeKb + 1) * 8) +
        Math.min(25, Math.log10(b.stars + b.forks + 1) * 8) +
        Math.max(0, 180 - b.daysSinceLastPush) * 0.08;
      return scoreB - scoreA;
    })
    .slice(0, 6);

  const recentlyUpdatedRepos = [...normalizedRepos]
    .sort((a, b) => a.daysSinceLastPush - b.daysSinceLastPush)
    .slice(0, 6);

  const reposPerYear =
    Math.round((publicRepoCount / Math.max(0.5, accountAgeYears)) * 10) / 10;

  const resolvedPagination: PaginationMeta = pagination || {
    totalPublicRepos: publicRepoCount,
    fetchedRepoCount: analyzedRepoCount,
    coveragePercentage:
      publicRepoCount === 0
        ? 100
        : Math.min(100, Math.round((analyzedRepoCount / publicRepoCount) * 100)),
    pagesFetched: analyzedRepoCount > 0 ? Math.ceil(analyzedRepoCount / 100) : 0,
    maxPagesAllowed: 5,
    isComplete: analyzedRepoCount >= publicRepoCount,
    truncationReason:
      analyzedRepoCount < publicRepoCount ? "MAX_PAGES_REACHED" : null,
    coverageNotice:
      analyzedRepoCount >= publicRepoCount
        ? `Complete profile analysis: inspected all ${analyzedRepoCount} public repositories.`
        : `Partial profile coverage: analyzed ${analyzedRepoCount} of ${publicRepoCount} public repositories.`,
  };

  return {
    publicRepoCount,
    analyzedRepoCount,
    originalRepoCount,
    forkRepoCount,
    originalPercentage,
    totalStars,
    originalStars,
    totalForks,
    accountAgeYears,
    reposPerYear,
    daysSinceLastActive,
    activeLast30Days,
    activeLast90Days,
    activeLast365Days,
    inactiveOver1YearCount,
    stableCompletedCount,
    initialCommitOnlyCount,
    substantiveOriginalCount,
    missingDescriptionCount,
    missingDescriptionPercent,
    reposWithTopicsCount,
    reposWithHomepageCount,
    reposWithLicenseCount,
    reposWithDocsSignalCount,
    topLanguage,
    languageSpecialization,
    languages,
    mostActiveRepos,
    recentlyUpdatedRepos,
    allRepos: normalizedRepos,
    pagination: resolvedPagination,
  };
}

/**
 * Computes transparent, trustworthy 0-10 heuristic scores:
 * - Does NOT assume more stars = better code (stars are at most a 0.8pt visibility bonus).
 * - Does NOT penalize small repository counts when per-repo depth/substance is high.
 * - Does NOT penalize older completed/stable repositories as "abandoned".
 * - Does NOT equate a missing short description with a missing README if other metadata signals exist.
 * - Does NOT penalize single-language specialization.
 */
export function computeTrustworthyScores(
  user: GitHubUser,
  m: GitHubAnalysisMetrics
): DeveloperScores {
  const disclaimer =
    "Heuristic Public-Data Assessment — These 0–10 scores summarize observable GitHub repository metadata (commit lifespans, codebase size, licensing, and discoverability tags). They are not an objective measurement of code correctness, private repositories, or professional engineering skill.";

  if (m.analyzedRepoCount === 0) {
    return {
      quality: 0.5,
      consistency: 0.5,
      documentation: 0.5,
      ambition: 0.5,
      activity: 0.5,
      overall: 0.5,
      disclaimer,
      breakdown: [
        {
          key: "quality",
          label: "Code & Project Structure",
          score: 0.5,
          observedFact: "0 public repositories available to inspect.",
          methodologyNote:
            "Measures public repository substance, multi-day iteration, and licensing; private work is not visible.",
        },
        {
          key: "consistency",
          label: "Follow-Through & Consistency",
          score: 0.5,
          observedFact: `Account registered for ${m.accountAgeYears} yrs with 0 public repository pushes.`,
          methodologyNote:
            "Evaluates multi-day project follow-through vs single-commit throwaways.",
        },
        {
          key: "documentation",
          label: "Public Metadata & Discoverability",
          score: 0.5,
          observedFact: user.bio
            ? "Profile bio is present, but 0 public repositories exist."
            : "No profile bio and 0 public repositories.",
          methodologyNote:
            "Evaluates public repo descriptions, topics, homepage links, and licenses.",
        },
        {
          key: "ambition",
          label: "Project Ambition & Depth",
          score: 0.5,
          observedFact: "No public codebases or open-source footprints found.",
          methodologyNote:
            "Evaluates codebase depth and iteration lifespan rather than sheer repository count.",
        },
        {
          key: "activity",
          label: "Public Activity Recency",
          score: 0.5,
          observedFact: "0 active public repositories in the last 365 days.",
          methodologyNote:
            "Reflects recent public push timestamps only.",
        },
        {
          key: "overall",
          label: "Overall Public Profile",
          score: 0.5,
          observedFact: `Public profile with ${user.followers || 0} followers and 0 public repositories.`,
          methodologyNote:
            "Weighted heuristic summary of public GitHub signals.",
        },
      ],
    };
  }

  const origPoolCount = Math.max(1, m.originalRepoCount || m.analyzedRepoCount);
  const substantiveRatio = m.substantiveOriginalCount / origPoolCount;
  const multiDayRepos = m.allRepos.filter(
    (r) => !r.isFork && r.activeLifespanDays >= 7
  ).length;
  const multiDayRatio = multiDayRepos / origPoolCount;
  const licenseRatio = m.reposWithLicenseCount / m.analyzedRepoCount;
  const docsSignalRatio = m.reposWithDocsSignalCount / origPoolCount;

  // 1. Code & Project Structure (Quality)
  // Driven by substantive codebases, multi-day iteration, original work, and licensing.
  // Stars are capped at a tiny 0.8pt community validation bonus so 0-star substantive code still scores up to 9.2/10.
  const communityValidationBonus = Math.min(
    0.8,
    Math.log10(m.totalStars + m.totalForks + 1) * 0.25
  );
  const quality = clampScore(
    3.0 +
      substantiveRatio * 2.8 +
      multiDayRatio * 1.8 +
      licenseRatio * 0.8 +
      (m.originalPercentage / 100) * 0.8 +
      communityValidationBonus
  );

  // 2. Follow-Through & Consistency
  // Distinguishes single-day throwaways from completed/stable repositories.
  // Inactive repos that had multi-day development or substantive size are NOT penalized!
  const throwawayRatio = m.initialCommitOnlyCount / origPoolCount;
  const followThroughRatio = 1 - throwawayRatio;
  const multiMonthRepos = m.allRepos.filter(
    (r) => !r.isFork && r.activeLifespanDays >= 30
  ).length;
  const sustainedBonus = Math.min(2.2, (multiMonthRepos / origPoolCount) * 3.0);
  const recentTouchBonus =
    m.daysSinceLastActive <= 30
      ? 1.5
      : m.daysSinceLastActive <= 180
      ? 1.0
      : 0.5;
  const consistency = clampScore(
    2.8 + followThroughRatio * 3.5 + sustainedBonus + recentTouchBonus
  );

  // 3. Public Metadata & Discoverability (Documentation)
  // Combines descriptions, homepage links, topics, wikis/pages, and licenses without assuming missing description = no README.
  const describedRatio = (100 - m.missingDescriptionPercent) / 100;
  const topicBonus = Math.min(1.5, (m.reposWithTopicsCount / m.analyzedRepoCount) * 2.2);
  const homepageBonus = Math.min(
    1.2,
    (m.reposWithHomepageCount / m.analyzedRepoCount) * 2.0
  );
  const bioBonus = user.bio && user.bio.trim().length > 5 ? 0.5 : 0;
  const documentation = clampScore(
    2.2 +
      docsSignalRatio * 3.0 +
      describedRatio * 1.8 +
      topicBonus +
      homepageBonus +
      licenseRatio * 0.8 +
      bioBonus
  );

  // 4. Project Ambition & Depth
  // Evaluates per-project depth (top 3 repositories' size and lifespan) so a developer with 1-3 deep projects is NOT penalized for low repo count, nor penalized for single-language specialization.
  const topOriginals = m.allRepos
    .filter((r) => !r.isFork)
    .sort((a, b) => b.sizeKb - a.sizeKb)
    .slice(0, 3);
  const avgTopSizeKb =
    topOriginals.length > 0
      ? topOriginals.reduce((s, r) => s + r.sizeKb, 0) / topOriginals.length
      : 20;
  const depthSizeScore = Math.min(3.2, Math.log10(avgTopSizeKb + 1) * 1.15);
  const maxLifespanDays = Math.max(
    0,
    ...m.allRepos.map((r) => r.activeLifespanDays)
  );
  const depthLifespanScore = Math.min(
    2.6,
    Math.log10(maxLifespanDays + 1) * 1.1
  );
  // Reward either deep specialization OR polyglot breadth equally (up to 1.4 pts)
  const focusOrBreadthScore =
    m.languages.length >= 3
      ? 1.4
      : m.languages.length >= 1 && m.substantiveOriginalCount >= 1
      ? 1.3
      : 0.6;
  const ambition = clampScore(
    2.2 +
      depthSizeScore +
      depthLifespanScore +
      focusOrBreadthScore +
      communityValidationBonus
  );

  // 5. Public Activity Recency
  const recencyBase =
    m.daysSinceLastActive <= 7
      ? 4.8
      : m.daysSinceLastActive <= 30
      ? 4.0
      : m.daysSinceLastActive <= 90
      ? 3.2
      : m.daysSinceLastActive <= 180
      ? 2.4
      : m.daysSinceLastActive <= 365
      ? 1.6
      : 0.8;
  const recentVolumeBoost = Math.min(
    3.2,
    m.activeLast90Days * 0.7 + m.activeLast365Days * 0.25
  );
  const activity = clampScore(1.8 + recencyBase + recentVolumeBoost);

  // 6. Overall Heuristic Profile
  const overall = clampScore(
    quality * 0.25 +
      consistency * 0.22 +
      documentation * 0.16 +
      ambition * 0.22 +
      activity * 0.15
  );

  return {
    quality,
    consistency,
    documentation,
    ambition,
    activity,
    overall,
    disclaimer,
    breakdown: [
      {
        key: "quality",
        label: "Code & Project Structure",
        score: quality,
        observedFact: `${m.substantiveOriginalCount}/${origPoolCount} original repos show substantive size (>=25 KB) or multi-day commits; ${m.reposWithLicenseCount}/${m.analyzedRepoCount} include a license.`,
        methodologyNote:
          "Prioritizes repository substance, iteration span, and licensing rather than star popularity.",
      },
      {
        key: "consistency",
        label: "Follow-Through & Consistency",
        score: consistency,
        observedFact: `${origPoolCount - m.initialCommitOnlyCount}/${origPoolCount} original repos progressed beyond Day 1 (${m.stableCompletedCount} older repos are stable/completed, ${m.initialCommitOnlyCount} single-day prototypes).`,
        methodologyNote:
          "Distinguishes stable completed projects from small Day-1 abandoned prototypes.",
      },
      {
        key: "documentation",
        label: "Public Metadata & Discoverability",
        score: documentation,
        observedFact: `${100 - m.missingDescriptionPercent}% include a summary description, ${m.reposWithTopicsCount} use topic tags, and ${m.reposWithHomepageCount} link a live homepage/docs URL.`,
        methodologyNote:
          "Measures public repository metadata fields; repos without an 'About' blurb may still contain detailed README files.",
      },
      {
        key: "ambition",
        label: "Project Ambition & Depth",
        score: ambition,
        observedFact: `Top original repositories average ${Math.round(avgTopSizeKb).toLocaleString()} KB with up to ${Math.round(maxLifespanDays)} days of commit history (${m.languageSpecialization}: ${m.topLanguage}).`,
        methodologyNote:
          "Evaluates per-project depth and engineering lifespan rather than raw repository volume or language count.",
      },
      {
        key: "activity",
        label: "Public Activity Recency",
        score: activity,
        observedFact: `Most recent public push was ${m.daysSinceLastActive} day(s) ago (${m.activeLast90Days} repo(s) updated in 90d, ${m.activeLast365Days} in 365d).`,
        methodologyNote:
          "Reflects public repository push timestamps; private commit activity is not included.",
      },
      {
        key: "overall",
        label: "Overall Public Profile",
        score: overall,
        observedFact: `Weighted composite across ${m.analyzedRepoCount} analyzed repositories (${m.pagination.coveragePercentage}% of ${m.publicRepoCount} public repos) over ${m.accountAgeYears} yrs.`,
        methodologyNote:
          "Heuristic synthesis of public GitHub signals—not an objective measure of engineering ability.",
      },
    ],
  };
}

/**
 * Classifies developer personality using transparent, explainable rules.
 */
export function classifyPersonality(
  user: GitHubUser,
  m: GitHubAnalysisMetrics,
  scores: DeveloperScores
): DeveloperPersonality {
  if (m.analyzedRepoCount === 0) {
    return {
      id: "stealth-ghost",
      title: "The Stealth Mode Lurker",
      tagline: "Zero public repositories. Zero public bugs. Undefeated in code review.",
      observedSignal: `Account created ${m.accountAgeYears} years ago with 0 public repositories and ${user.followers || 0} followers.`,
      interpretation:
        "Either all engineering work happens inside private organizations, or this account exists purely to star other people's repositories.",
      badgeColor:
        "from-zinc-500/20 to-slate-500/20 text-zinc-300 border-zinc-700",
    };
  }

  const topStarRepo = [...m.allRepos].sort(
    (a, b) => b.stars - a.stars || b.sizeKb - a.sizeKb
  )[0];

  // 1. The One-Project Wonder (1 flagship repo carries >=78% of stars or account has 1-2 deep repos)
  if (
    m.analyzedRepoCount === 1 ||
    (m.totalStars >= 30 &&
      topStarRepo &&
      topStarRepo.stars / Math.max(1, m.totalStars) >= 0.78)
  ) {
    const share =
      m.totalStars > 0
        ? Math.round((topStarRepo.stars / m.totalStars) * 100)
        : 100;
    return {
      id: "one-project-wonder",
      title: "The One-Project Wonder",
      tagline:
        "Focused engineering gravity: one flagship repository commands the spotlight.",
      observedSignal:
        m.analyzedRepoCount === 1
          ? `Profile contains 1 public repository ("${topStarRepo.name}", ${topStarRepo.sizeKb.toLocaleString()} KB, ${Math.round(topStarRepo.activeLifespanDays)}d lifespan).`
          : `"${topStarRepo.name}" accounts for ${topStarRepo.stars.toLocaleString()} of ${m.totalStars.toLocaleString()} total stars (${share}%).`,
      interpretation:
        "Rather than scattering attention across dozens of throwaway repos, your public reputation is anchored by a single standout project.",
      badgeColor:
        "from-amber-500/20 to-orange-500/20 text-amber-300 border-amber-500/40",
    };
  }

  // 2. The Open Source Goblin
  if (
    m.totalStars >= 120 ||
    (m.substantiveOriginalCount >= 15 &&
      scores.activity >= 6.8 &&
      m.originalPercentage >= 65)
  ) {
    return {
      id: "open-source-goblin",
      title: "The Open Source Goblin",
      tagline:
        "Lives in git log, ships sustained codebases, and treats public repositories like a full-time craft.",
      observedSignal: `${m.totalStars.toLocaleString()} total stars, ${m.totalForks.toLocaleString()} forks, and ${m.substantiveOriginalCount} substantive original repositories across ${m.analyzedRepoCount} analyzed repos.`,
      interpretation:
        "Consistent public shipping combined with real community adoption or deep repository maintenance.",
      badgeColor:
        "from-emerald-500/20 to-teal-500/20 text-emerald-300 border-emerald-500/40",
    };
  }

  // 3. The Serial Project Starter (requires true small Day-1 initialCommitOnly drops)
  if (
    m.initialCommitOnlyCount >= 4 ||
    (m.originalRepoCount >= 6 &&
      m.initialCommitOnlyCount / Math.max(1, m.originalRepoCount) >= 0.4)
  ) {
    return {
      id: "serial-project-starter",
      title: "The Serial Project Starter",
      tagline:
        "Unstoppable on git init; frequently moves on to the next big idea within 24 hours.",
      observedSignal: `${m.initialCommitOnlyCount} of ${m.originalRepoCount} original repositories had their final push within 24 hours of creation (<35 KB each).`,
      interpretation:
        "High ideation velocity paired with a graveyard of Day-1 prototypes waiting for a second commit.",
      badgeColor:
        "from-orange-500/20 to-pink-500/20 text-orange-300 border-orange-500/40",
    };
  }

  // 4. The Documentation Avoider (missing descriptions AND missing other metadata like topics/homepages)
  if (
    m.missingDescriptionPercent >= 50 &&
    m.reposWithDocsSignalCount / Math.max(1, m.originalRepoCount || m.analyzedRepoCount) < 0.5 &&
    m.analyzedRepoCount >= 4
  ) {
    return {
      id: "documentation-avoider",
      title: "The Documentation Avoider",
      tagline:
        "Leaves repository metadata blank so visitors have to read the source code like detectives.",
      observedSignal: `${m.missingDescriptionCount} of ${
        m.originalRepoCount || m.analyzedRepoCount
      } repositories (${m.missingDescriptionPercent}%) omit a description, and ${
        m.analyzedRepoCount - m.reposWithTopicsCount
      } omit topic tags.`,
      interpretation:
        "While your repositories may contain internal README files, skipping GitHub's summary metadata makes browsing your profile a guessing game.",
      badgeColor:
        "from-rose-500/20 to-red-500/20 text-rose-300 border-rose-500/40",
    };
  }

  // 5. The Framework Collector
  if (m.languages.length >= 5) {
    const langList = m.languages
      .slice(0, 5)
      .map((l) => l.language)
      .join(", ");
    return {
      id: "framework-collector",
      title: "The Framework Collector",
      tagline:
        "Explores programming languages and ecosystems like a polyglot tourist.",
      observedSignal: `${m.languages.length} distinct primary languages (${langList}) detected across ${m.analyzedRepoCount} analyzed repositories.`,
      interpretation:
        "High curiosity across diverse toolchains and runtimes rather than staying locked into a single ecosystem.",
      badgeColor:
        "from-violet-500/20 to-indigo-500/20 text-violet-300 border-violet-500/40",
    };
  }

  // 6. The Fork Curator
  if (m.forkRepoCount > m.originalRepoCount && m.analyzedRepoCount >= 4) {
    return {
      id: "fork-curator",
      title: "The Fork Curator",
      tagline:
        "Uses the Fork button as a personal library of interesting upstream projects.",
      observedSignal: `${m.forkRepoCount} forked repositories vs ${m.originalRepoCount} original repositories (${100 - m.originalPercentage}% forks).`,
      interpretation:
        "Your public profile heavily indexes upstream forks, which can overshadow your own original repositories unless pinned.",
      badgeColor:
        "from-cyan-500/20 to-blue-500/20 text-cyan-300 border-cyan-500/40",
    };
  }

  // Default: The Weekend Coder / Focused Builder
  return {
    id: "weekend-coder",
    title: "The Weekend Coder",
    tagline:
      "Ships in focused bursts of pragmatic building between quiet intervals.",
    observedSignal: `${m.activeLast90Days} repo(s) updated in the last 90 days, ${m.stableCompletedCount} stable older repo(s), and ${m.substantiveOriginalCount} substantive original project(s).`,
    interpretation:
      "Balances periodic hands-on project sprints with stretches where completed repositories sit stable without unnecessary churn.",
    badgeColor:
      "from-sky-500/20 to-blue-500/20 text-sky-300 border-sky-500/40",
  };
}

/**
 * Packages the normalized metrics, scores, and personality into a structured,
 * verifiable evidence payload for the server-side AI model.
 */
export function buildStructuredEvidenceForAI(
  user: GitHubUser,
  analysis: GitHubAnalysisMetrics,
  scores: DeveloperScores,
  personality: DeveloperPersonality
): StructuredGitHubEvidence {
  return {
    username: user.login,
    displayName: user.name || user.login,
    accountType: user.type || "User",
    accountAgeYears: analysis.accountAgeYears,
    bio: user.bio,
    followers: Number(user.followers) || 0,
    following: Number(user.following) || 0,
    pagination: analysis.pagination,
    counts: {
      totalPublicRepos: analysis.publicRepoCount,
      analyzedRepos: analysis.analyzedRepoCount,
      originalRepos: analysis.originalRepoCount,
      forkedRepos: analysis.forkRepoCount,
      originalPercentage: analysis.originalPercentage,
      totalStars: analysis.totalStars,
      originalStars: analysis.originalStars,
      totalForks: analysis.totalForks,
    },
    activity: {
      daysSinceLastPush: analysis.daysSinceLastActive,
      activeLast30Days: analysis.activeLast30Days,
      activeLast90Days: analysis.activeLast90Days,
      activeLast365Days: analysis.activeLast365Days,
      inactiveOver1YearCount: analysis.inactiveOver1YearCount,
      stableCompletedCount: analysis.stableCompletedCount,
      initialCommitOnlyCount: analysis.initialCommitOnlyCount,
      substantiveOriginalCount: analysis.substantiveOriginalCount,
    },
    metadataHygiene: {
      missingDescriptionCount: analysis.missingDescriptionCount,
      missingDescriptionPercent: analysis.missingDescriptionPercent,
      reposWithTopicsCount: analysis.reposWithTopicsCount,
      reposWithHomepageCount: analysis.reposWithHomepageCount,
      reposWithLicenseCount: analysis.reposWithLicenseCount,
      reposWithDocsSignalCount: analysis.reposWithDocsSignalCount,
      note: "GitHub list repos API provides summary descriptions, topics, homepage links, and licenses; internal README.md length is not directly exposed.",
    },
    languages: {
      topLanguage: analysis.topLanguage,
      specializationPattern: analysis.languageSpecialization,
      breakdown: analysis.languages.slice(0, 6).map((l) => ({
        language: l.language,
        repoCount: l.repoCount,
        percentage: l.percentage,
        stars: l.stars,
        sizeKb: l.sizeKb,
      })),
    },
    scores: {
      overall: scores.overall,
      quality: scores.quality,
      consistency: scores.consistency,
      documentation: scores.documentation,
      ambition: scores.ambition,
      activity: scores.activity,
    },
    deterministicPersonality: {
      id: personality.id,
      title: personality.title,
      observedSignal: personality.observedSignal,
    },
    notableRepositories: analysis.mostActiveRepos.slice(0, 6).map((r) => ({
      name: r.name,
      isFork: r.isFork,
      language: r.language,
      stars: r.stars,
      forks: r.forks,
      sizeKb: r.sizeKb,
      daysSinceLastPush: r.daysSinceLastPush,
      activeLifespanDays: r.activeLifespanDays,
      initialCommitOnly: r.initialCommitOnly,
      description: r.description,
      topics: r.topics.slice(0, 5),
      hasHomepage: r.hasHomepage,
      hasLicense: r.hasLicense,
    })),
  };
}
