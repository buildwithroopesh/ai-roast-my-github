/**
 * Rate Limiting & Abuse Protection for `/api/roast`.
 *
 * Architecture & Deployment Semantics:
 * 1. Atomic Distributed Sliding-Window Mode (Upstash Redis Configured):
 *    When `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN` are set, `checkRateLimit`
 *    executes a single atomic Redis Lua `EVAL` script (`REDIS_SLIDING_WINDOW_LUA`) over
 *    sorted sets (`ZSet`) for both the per-IP key (`airoast:sw:ip:<clientIp>`) and the shared
 *    global budget key (`airoast:sw:global`):
 *      - Expired entries (`<= nowMs - windowMs`) are pruned first.
 *      - The per-IP count (`ZCARD ipKey`) is checked BEFORE checking or incrementing the
 *        global key so an already-blocked IP cannot consume the global accepted-request
 *        budget by flooding rejected requests.
 *      - Entries are inserted (`ZADD`) into `ipKey` and `globalKey` ONLY when both checks pass.
 *      - Each accepted request uses a cryptographically random member ID (`${nowMs}:${randomUUID()}`)
 *        so concurrent requests across serverless instances or cold starts can never collide.
 *    If Redis is configured but unreachable, the limiter FAILS CLOSED (`503 RATE_LIMIT_BACKEND_UNAVAILABLE`)
 *    unless `ROAST_RATE_LIMIT_FAIL_OPEN=true` is explicitly set.
 *
 * 2. Proxy Trust & Shared-Key Fallback Semantics (`TRUST_PROXY`):
 *    - `TRUST_PROXY=false`: Disables ALL forwarded headers (`x-vercel-forwarded-for`,
 *      `cf-connecting-ip`, `x-real-ip`, `x-forwarded-for`) so clients cannot spoof their IP
 *      when the server is directly exposed without a trusted reverse proxy.
 *      - If the runtime supplies a validated direct socket/peer IP (`runtimePeerIp`, such as
 *        a platform-populated `request.ip`), `extractClientIp` uses that peer IP.
 *      - Otherwise, `extractClientIp` returns `"127.0.0.1"`. IMPORTANT: In runtimes that do
 *        not expose a direct peer IP on `Request`, returning `"127.0.0.1"` does NOT provide
 *        individual per-IP rate limiting—ALL callers share the single `"127.0.0.1"` bucket
 *        (`ROAST_RATE_LIMIT_MAX` requests/min combined across all callers). Public deployments
 *        without a trustworthy client IP from a reverse proxy or runtime socket MUST enforce
 *        per-IP rate limiting at the network/edge layer (e.g., Cloudflare WAF, AWS WAF, Nginx).
 *    - `x-vercel-forwarded-for`: Only trustworthy when deployed on Vercel (where Vercel's edge
 *      overwrites the header on ingress).
 *    - `cf-connecting-ip`: Only trustworthy when traffic is proxied through Cloudflare with
 *      origin firewall rules blocking direct non-Cloudflare connections.
 *    - `x-real-ip` / `x-forwarded-for`: Only trustworthy behind a reverse proxy you control
 *      (e.g., AWS ALB, Nginx, Envoy) configured to strip or overwrite client-supplied headers.
 */

import { randomBytes, randomUUID } from "crypto";
import { isIP } from "net";
import { fetchWithTimeout } from "@/lib/github";

const DEFAULT_WINDOW_MS = 60_000; // 1 minute sliding window
const DEFAULT_MAX_REQUESTS = 10; // 10 requests per window per client key
const DEFAULT_GLOBAL_MAX_PER_MINUTE = 60; // 60 accepted requests per window across all clients
const MAX_TRACKED_CLIENTS = 5_000;
const REDIS_TIMEOUT_MS = 1_500;

export const REDIS_SLIDING_WINDOW_LUA = `
local globalKey = KEYS[1]
local ipKey = KEYS[2]
local nowMs = tonumber(ARGV[1])
local windowMs = tonumber(ARGV[2])
local globalMax = tonumber(ARGV[3])
local ipLimit = tonumber(ARGV[4])
local memberId = ARGV[5]
local windowStart = nowMs - windowMs

redis.call('ZREMRANGEBYSCORE', globalKey, '-inf', windowStart)
redis.call('ZREMRANGEBYSCORE', ipKey, '-inf', windowStart)

local ipCount = redis.call('ZCARD', ipKey)
if ipCount >= ipLimit then
  local oldestIp = redis.call('ZRANGE', ipKey, 0, 0, 'WITHSCORES')
  local oldestIpTs = tonumber(oldestIp[2]) or nowMs
  redis.call('PEXPIRE', ipKey, windowMs)
  return {0, 'IP_LIMIT_EXCEEDED', ipCount, oldestIpTs + windowMs}
end

local globalCount = redis.call('ZCARD', globalKey)
if globalCount >= globalMax then
  local oldestGlobal = redis.call('ZRANGE', globalKey, 0, 0, 'WITHSCORES')
  local oldestGlobalTs = tonumber(oldestGlobal[2]) or nowMs
  redis.call('PEXPIRE', globalKey, windowMs)
  return {0, 'GLOBAL_BURST_EXCEEDED', ipCount, oldestGlobalTs + windowMs}
end

redis.call('ZADD', ipKey, nowMs, memberId)
redis.call('PEXPIRE', ipKey, windowMs)
redis.call('ZADD', globalKey, nowMs, memberId)
redis.call('PEXPIRE', globalKey, windowMs)

local newIpCount = ipCount + 1
local firstIp = redis.call('ZRANGE', ipKey, 0, 0, 'WITHSCORES')
local firstIpTs = tonumber(firstIp[2]) or nowMs
return {1, 'ALLOWED', newIpCount, firstIpTs + windowMs}
`.trim();

interface SlidingWindowEntry {
  timestamps: number[];
}

const clientWindows = new Map<string, SlidingWindowEntry>();
let globalTimestamps: number[] = [];

export type RateLimitRejectReason =
  | "IP_LIMIT_EXCEEDED"
  | "GLOBAL_BURST_EXCEEDED"
  | "RATE_LIMIT_BACKEND_UNAVAILABLE";

export interface RateLimitResult {
  allowed: boolean;
  limit: number;
  remaining: number;
  resetAtMs: number;
  retryAfterSeconds: number;
  reason?: RateLimitRejectReason;
  backend: "memory" | "redis" | "redis-unavailable" | "memory-degraded";
}

export interface RateLimitOptions {
  maxRequests?: number;
  windowMs?: number;
  globalMaxPerMinute?: number;
  nowFn?: () => number;
  fetchFn?: typeof fetch;
  env?: Record<string, string | undefined>;
}

export function resetRateLimiterState(): void {
  clientWindows.clear();
  globalTimestamps = [];
}

/**
 * Generates a unique sorted-set member ID that cannot collide across serverless
 * instances, concurrent requests, or cold starts.
 */
export function generateRequestMemberId(nowMs: number = Date.now()): string {
  const uniquePart =
    typeof randomUUID === "function"
      ? randomUUID()
      : randomBytes(16).toString("hex");
  return `${nowMs}:${uniquePart}`;
}

/**
 * Validates that a candidate string is a strict, canonical IPv4 or IPv6 address
 * using Node's `net.isIP`, rejecting malformed IPv6 strings (such as `:::`,
 * `2001::85a3::8a2e`, `12345::1`, or `:1`).
 */
export function isValidIpAddress(ip: string): boolean {
  if (!ip || typeof ip !== "string") return false;
  if (ip !== ip.trim() || ip.length > 45) return false;
  return isIP(ip) !== 0;
}

/**
 * Extracts a validated client IP from proxy headers or an optional runtime peer IP.
 * - When `TRUST_PROXY=false` is set, ALL forwarded headers (including
 *   `x-vercel-forwarded-for` and `cf-connecting-ip`) are ignored. If a valid
 *   `runtimePeerIp` is provided by the server runtime, it is used; otherwise
 *   `"127.0.0.1"` is returned as a shared fallback key across all callers.
 */
export function extractClientIp(
  headers: Headers,
  env: Record<string, string | undefined> = process.env,
  runtimePeerIp?: string | null
): string {
  const validPeerIp =
    typeof runtimePeerIp === "string" && isValidIpAddress(runtimePeerIp.trim())
      ? runtimePeerIp.trim()
      : null;

  if (env.TRUST_PROXY?.toLowerCase() === "false") {
    return validPeerIp || "127.0.0.1";
  }

  const platformHeaders = [
    headers.get("x-vercel-forwarded-for"),
    headers.get("cf-connecting-ip"),
  ];

  for (const raw of platformHeaders) {
    if (raw) {
      const hops = raw
        .split(",")
        .map((part) => part.trim())
        .filter(isValidIpAddress);
      if (hops.length > 0) {
        return hops[0];
      }
    }
  }

  const realIp = headers.get("x-real-ip")?.trim();
  if (realIp && isValidIpAddress(realIp)) {
    return realIp;
  }

  const xff = headers.get("x-forwarded-for");
  if (xff) {
    const hops = xff
      .split(",")
      .map((part) => part.trim())
      .filter(isValidIpAddress);
    if (hops.length > 0) {
      return hops[0];
    }
  }

  return validPeerIp || "127.0.0.1";
}

function checkInMemoryRateLimit(
  clientKey: string,
  limit: number,
  windowMs: number,
  globalMax: number,
  nowMs: number,
  backendLabel: "memory" | "memory-degraded" = "memory"
): RateLimitResult {
  const windowStart = nowMs - windowMs;

  // Prune expired global timestamps first
  globalTimestamps = globalTimestamps.filter((ts) => ts > windowStart);

  // Evict oldest key if map exceeds MAX_TRACKED_CLIENTS
  if (
    !clientWindows.has(clientKey) &&
    clientWindows.size >= MAX_TRACKED_CLIENTS
  ) {
    const oldestKey = clientWindows.keys().next().value;
    if (oldestKey !== undefined) {
      clientWindows.delete(oldestKey);
    }
  }

  const entry = clientWindows.get(clientKey) || { timestamps: [] };
  entry.timestamps = entry.timestamps.filter((ts) => ts > windowStart);

  // 1. Check per-key limit FIRST so a blocked key cannot consume the global budget
  if (entry.timestamps.length >= limit) {
    clientWindows.set(clientKey, entry);
    const oldestClientTs = entry.timestamps[0] || nowMs;
    const resetAtMs = oldestClientTs + windowMs;
    return {
      allowed: false,
      limit,
      remaining: 0,
      resetAtMs,
      retryAfterSeconds: Math.max(1, Math.ceil((resetAtMs - nowMs) / 1000)),
      reason: "IP_LIMIT_EXCEEDED",
      backend: backendLabel,
    };
  }

  // 2. Check global accepted-request budget
  if (globalTimestamps.length >= globalMax) {
    const oldestGlobal = globalTimestamps[0] || nowMs;
    const resetAtMs = oldestGlobal + windowMs;
    return {
      allowed: false,
      limit,
      remaining: 0,
      resetAtMs,
      retryAfterSeconds: Math.max(1, Math.ceil((resetAtMs - nowMs) / 1000)),
      reason: "GLOBAL_BURST_EXCEEDED",
      backend: backendLabel,
    };
  }

  // 3. Record accepted request in both per-key and global sliding windows
  entry.timestamps.push(nowMs);
  globalTimestamps.push(nowMs);
  clientWindows.set(clientKey, entry);

  const remaining = Math.max(0, limit - entry.timestamps.length);
  const resetAtMs = (entry.timestamps[0] || nowMs) + windowMs;

  return {
    allowed: true,
    limit,
    remaining,
    resetAtMs,
    retryAfterSeconds: 0,
    backend: backendLabel,
  };
}

/**
 * Executes an atomic Redis Lua `EVAL` script for distributed sliding-window
 * rate limiting across both the per-IP key and the global accepted-request key.
 */
async function checkDistributedRedisRateLimit(
  redisUrl: string,
  redisToken: string,
  clientKey: string,
  limit: number,
  windowMs: number,
  globalMax: number,
  nowMs: number,
  fetchImpl: typeof fetch
): Promise<RateLimitResult | null> {
  const memberId = generateRequestMemberId(nowMs);
  const globalKey = "airoast:sw:global";
  const ipKey = `airoast:sw:ip:${clientKey}`;

  try {
    const res = await fetchWithTimeout(
      redisUrl.replace(/\/$/, ""),
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${redisToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify([
          "EVAL",
          REDIS_SLIDING_WINDOW_LUA,
          "2",
          globalKey,
          ipKey,
          String(nowMs),
          String(windowMs),
          String(globalMax),
          String(limit),
          memberId,
        ]),
      },
      REDIS_TIMEOUT_MS,
      fetchImpl
    );

    if (!res.ok) return null;
    const payload = await res.json();
    const resultTuple = payload?.result;
    if (!Array.isArray(resultTuple) || resultTuple.length < 4) {
      return null;
    }

    const allowedFlag = Number(resultTuple[0]);
    const statusCode = String(resultTuple[1]);
    const currentIpCount = Number(resultTuple[2]);
    const resetAtMs = Number(resultTuple[3]) || nowMs + windowMs;

    if (!Number.isFinite(allowedFlag) || !Number.isFinite(currentIpCount)) {
      return null;
    }

    const retryAfterSeconds = Math.max(
      1,
      Math.ceil((resetAtMs - nowMs) / 1000)
    );

    if (allowedFlag !== 1) {
      const reason: RateLimitRejectReason =
        statusCode === "GLOBAL_BURST_EXCEEDED"
          ? "GLOBAL_BURST_EXCEEDED"
          : "IP_LIMIT_EXCEEDED";
      return {
        allowed: false,
        limit,
        remaining: 0,
        resetAtMs,
        retryAfterSeconds,
        reason,
        backend: "redis",
      };
    }

    return {
      allowed: true,
      limit,
      remaining: Math.max(0, limit - currentIpCount),
      resetAtMs,
      retryAfterSeconds: 0,
      backend: "redis",
    };
  } catch {
    return null;
  }
}

export async function checkRateLimit(
  clientKey: string,
  options: RateLimitOptions = {}
): Promise<RateLimitResult> {
  const env = options.env || process.env;
  const now = options.nowFn || Date.now;
  const fetchImpl = options.fetchFn || globalThis.fetch;

  const envMax = Number(env.ROAST_RATE_LIMIT_MAX);
  const limit =
    options.maxRequests ??
    (Number.isFinite(envMax) && envMax > 0 ? envMax : DEFAULT_MAX_REQUESTS);

  const envWindow = Number(env.ROAST_RATE_LIMIT_WINDOW_MS);
  const windowMs =
    options.windowMs ??
    (Number.isFinite(envWindow) && envWindow >= 1000
      ? envWindow
      : DEFAULT_WINDOW_MS);

  const envGlobal = Number(env.ROAST_GLOBAL_MAX_PER_MINUTE);
  const globalMax =
    options.globalMaxPerMinute ??
    (Number.isFinite(envGlobal) && envGlobal > 0
      ? envGlobal
      : DEFAULT_GLOBAL_MAX_PER_MINUTE);

  const nowMs = now();

  const redisUrl = env.UPSTASH_REDIS_REST_URL?.trim();
  const redisToken = env.UPSTASH_REDIS_REST_TOKEN?.trim();

  if (redisUrl && redisToken) {
    const distributed = await checkDistributedRedisRateLimit(
      redisUrl,
      redisToken,
      clientKey,
      limit,
      windowMs,
      globalMax,
      nowMs,
      fetchImpl
    );
    if (distributed) {
      return distributed;
    }

    if (env.ROAST_RATE_LIMIT_FAIL_OPEN?.toLowerCase() === "true") {
      return checkInMemoryRateLimit(
        clientKey,
        limit,
        windowMs,
        globalMax,
        nowMs,
        "memory-degraded"
      );
    }

    return {
      allowed: false,
      limit,
      remaining: 0,
      resetAtMs: nowMs + 15_000,
      retryAfterSeconds: 15,
      reason: "RATE_LIMIT_BACKEND_UNAVAILABLE",
      backend: "redis-unavailable",
    };
  }

  return checkInMemoryRateLimit(
    clientKey,
    limit,
    windowMs,
    globalMax,
    nowMs,
    "memory"
  );
}

export function buildRateLimitHeaders(
  rl: RateLimitResult
): Record<string, string> {
  const headers: Record<string, string> = {
    "X-RateLimit-Limit": String(rl.limit),
    "X-RateLimit-Remaining": String(rl.remaining),
    "X-RateLimit-Reset": String(Math.ceil(rl.resetAtMs / 1000)),
    "X-RateLimit-Backend": rl.backend,
  };
  if (!rl.allowed) {
    headers["Retry-After"] = String(rl.retryAfterSeconds);
  }
  return headers;
}
