import {
  GitHubRepo,
  GitHubUser,
  PaginationMeta,
  RateLimitMeta,
  RoastReport,
} from "@/types/roast";
import {
  buildStructuredEvidenceForAI,
  classifyPersonality,
  computeTrustworthyScores,
  normalizeGitHubMetrics,
} from "@/lib/scoring";
import { AiGeneratorOptions, generateAiRoastAnalysis } from "@/lib/ai-roast";

export async function assembleRoastReport(
  user: GitHubUser,
  repos: GitHubRepo[],
  pagination: PaginationMeta,
  rateLimit: RateLimitMeta,
  aiOptions: AiGeneratorOptions = {},
  referenceDate: Date = new Date()
): Promise<RoastReport> {
  const analysis = normalizeGitHubMetrics(
    user,
    repos,
    pagination,
    referenceDate
  );
  const scores = computeTrustworthyScores(user, analysis);
  const basePersonality = classifyPersonality(user, analysis, scores);
  const evidence = buildStructuredEvidenceForAI(
    user,
    analysis,
    scores,
    basePersonality
  );

  const { roast, personality } = await generateAiRoastAnalysis(
    user,
    analysis,
    scores,
    basePersonality,
    evidence,
    aiOptions
  );

  return {
    generatedAt: referenceDate.toISOString(),
    profile: {
      username: user.login,
      name: user.name || user.login,
      avatarUrl:
        user.avatar_url || "https://avatars.githubusercontent.com/u/9919?v=4",
      htmlUrl: user.html_url || `https://github.com/${user.login}`,
      bio: user.bio,
      location: user.location,
      company: user.company,
      blog: user.blog,
      followers: Number(user.followers) || 0,
      following: Number(user.following) || 0,
      publicRepos: analysis.publicRepoCount,
      publicGists: Number(user.public_gists) || 0,
      createdAt: user.created_at,
      accountType: user.type || "User",
    },
    scores,
    personality,
    analysis,
    roast,
    rateLimit,
  };
}
