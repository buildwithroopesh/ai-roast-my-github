import {
  ApiErrorCode,
  DeveloperPersonality,
  DeveloperScores,
  EvidencePoint,
  FactInterpretationReceipt,
  GitHubAnalysisMetrics,
  GitHubUser,
  ProjectRecommendation,
  RoastContent,
  StructuredGitHubEvidence,
} from "@/types/roast";
import { fetchWithTimeout, isAbortOrTimeoutError } from "@/lib/github";

const DEFAULT_AI_TIMEOUT_MS = 12_000; // 12s explicit timeout covering headers + body

export const DEFAULT_AI_MODELS = {
  gemini: "gemini-3.5-flash-lite",
  openai: "gpt-5.4-mini",
  anthropic: "claude-haiku-5-5",
} as const;

export class AiRoastError extends Error {
  public status: number;
  public code: ApiErrorCode;
  public configurationHint?: string;

  constructor(
    message: string,
    status: number,
    code: ApiErrorCode,
    configurationHint?: string
  ) {
    super(message);
    this.name = "AiRoastError";
    this.status = status;
    this.code = code;
    this.configurationHint = configurationHint;
  }
}

export interface AiGeneratorOptions {
  env?: Record<string, string | undefined>;
  fetchFn?: typeof fetch;
  timeoutMs?: number;
  allowHeuristicFallback?: boolean;
  isDemoFixture?: boolean;
}

export interface AiProviderConfig {
  provider: "openai" | "gemini" | "anthropic";
  apiKey: string;
  model: string;
}

/**
 * Resolves the active AI provider configuration while strictly preventing
 * unexpected paid API usage:
 * - Defaults to `AI_PROVIDER="gemini"` (`gemini-3.5-flash-lite`) when `AI_PROVIDER`
 *   is omitted.
 * - Never falls back to OpenAI or Anthropic when `AI_PROVIDER` is `"gemini"` or omitted
 *   and `GEMINI_API_KEY` is missing.
 * - Only selects OpenAI when `AI_PROVIDER="openai"` is explicitly configured.
 * - Only selects Anthropic when `AI_PROVIDER="anthropic"` is explicitly configured.
 */
export function resolveAiProviderConfig(
  env: Record<string, string | undefined> = process.env
): AiProviderConfig | null {
  const rawProvider = env.AI_PROVIDER?.trim().toLowerCase();
  const selectedProvider = rawProvider || "gemini";
  const customModel = env.AI_MODEL?.trim();

  const geminiKey = env.GEMINI_API_KEY?.trim();
  const openAiKey = env.OPENAI_API_KEY?.trim();
  const anthropicKey = env.ANTHROPIC_API_KEY?.trim();

  if (selectedProvider === "gemini") {
    if (!geminiKey) {
      return null;
    }
    return {
      provider: "gemini",
      apiKey: geminiKey,
      model: customModel || DEFAULT_AI_MODELS.gemini,
    };
  }

  if (selectedProvider === "openai") {
    if (!openAiKey) {
      return null;
    }
    return {
      provider: "openai",
      apiKey: openAiKey,
      model: customModel || DEFAULT_AI_MODELS.openai,
    };
  }

  if (selectedProvider === "anthropic") {
    if (!anthropicKey) {
      return null;
    }
    return {
      provider: "anthropic",
      apiKey: anthropicKey,
      model: customModel || DEFAULT_AI_MODELS.anthropic,
    };
  }

  return null;
}

export interface EvidenceMetricBuckets {
  repos: Set<number>;
  stars: Set<number>;
  forks: Set<number>;
  percentages: Set<number>;
  languages: Set<number>;
  followers: Set<number>;
  following: Set<number>;
  years: Set<number>;
  days: Set<number>;
  kb: Set<number>;
  scores: Set<number>;
  allExactNumbers: Set<number>;
}

export interface EvidenceVocabularySets {
  repoNameSet: Set<string>;
  topicSet: Set<string>;
  languageSet: Set<string>;
  generalVocabSet: Set<string>;
}

/**
 * Builds category-specific numeric sets strictly from the deterministic GitHub evidence.
 * Separates `followers` and `following` into distinct buckets and does NOT include
 * any blanket allowlist for 0..10 or 30/90 constants.
 */
export function buildEvidenceMetricBuckets(
  evidence: StructuredGitHubEvidence,
  analysis?: GitHubAnalysisMetrics
): EvidenceMetricBuckets {
  const buckets: EvidenceMetricBuckets = {
    repos: new Set<number>(),
    stars: new Set<number>(),
    forks: new Set<number>(),
    percentages: new Set<number>(),
    languages: new Set<number>(),
    followers: new Set<number>(),
    following: new Set<number>(),
    years: new Set<number>(),
    days: new Set<number>(),
    kb: new Set<number>(),
    scores: new Set<number>(),
    allExactNumbers: new Set<number>(),
  };

  const addTo = (set: Set<number>, val: unknown) => {
    const n = Number(val);
    if (Number.isFinite(n)) {
      const rounded1 = Math.round(n * 10) / 10;
      const roundedInt = Math.round(n);
      set.add(n);
      set.add(rounded1);
      set.add(roundedInt);
      buckets.allExactNumbers.add(n);
      buckets.allExactNumbers.add(rounded1);
      buckets.allExactNumbers.add(roundedInt);
    }
  };

  // Years
  addTo(buckets.years, evidence.accountAgeYears);

  // Separate Followers and Following buckets
  addTo(buckets.followers, evidence.followers);
  addTo(buckets.following, evidence.following);

  // Pagination & Repository counts
  addTo(buckets.repos, evidence.pagination.totalPublicRepos);
  addTo(buckets.repos, evidence.pagination.fetchedRepoCount);
  addTo(buckets.repos, evidence.counts.totalPublicRepos);
  addTo(buckets.repos, evidence.counts.analyzedRepos);
  addTo(buckets.repos, evidence.counts.originalRepos);
  addTo(buckets.repos, evidence.counts.forkedRepos);
  addTo(buckets.repos, evidence.activity.activeLast30Days);
  addTo(buckets.repos, evidence.activity.activeLast90Days);
  addTo(buckets.repos, evidence.activity.activeLast365Days);
  addTo(buckets.repos, evidence.activity.inactiveOver1YearCount);
  addTo(buckets.repos, evidence.activity.stableCompletedCount);
  addTo(buckets.repos, evidence.activity.initialCommitOnlyCount);
  addTo(buckets.repos, evidence.activity.substantiveOriginalCount);
  addTo(
    buckets.repos,
    evidence.counts.originalRepos - evidence.activity.initialCommitOnlyCount
  );
  addTo(buckets.repos, evidence.metadataHygiene.missingDescriptionCount);
  addTo(buckets.repos, evidence.metadataHygiene.reposWithTopicsCount);
  addTo(
    buckets.repos,
    evidence.counts.analyzedRepos - evidence.metadataHygiene.reposWithTopicsCount
  );
  addTo(buckets.repos, evidence.metadataHygiene.reposWithHomepageCount);
  addTo(
    buckets.repos,
    evidence.counts.analyzedRepos -
      evidence.metadataHygiene.reposWithHomepageCount
  );
  addTo(buckets.repos, evidence.metadataHygiene.reposWithLicenseCount);
  addTo(
    buckets.repos,
    evidence.counts.analyzedRepos -
      evidence.metadataHygiene.reposWithLicenseCount
  );
  addTo(buckets.repos, evidence.metadataHygiene.reposWithDocsSignalCount);

  // Percentages
  addTo(buckets.percentages, evidence.pagination.coveragePercentage);
  addTo(buckets.percentages, evidence.counts.originalPercentage);
  addTo(buckets.percentages, 100 - evidence.counts.originalPercentage);
  addTo(buckets.percentages, evidence.metadataHygiene.missingDescriptionPercent);
  addTo(
    buckets.percentages,
    100 - evidence.metadataHygiene.missingDescriptionPercent
  );
  if (evidence.counts.analyzedRepos === 0) {
    addTo(buckets.percentages, 0);
  }

  // Stars & Forks
  addTo(buckets.stars, evidence.counts.totalStars);
  addTo(buckets.stars, evidence.counts.originalStars);
  addTo(buckets.forks, evidence.counts.totalForks);
  addTo(buckets.forks, evidence.counts.forkedRepos);

  // Days
  addTo(buckets.days, evidence.activity.daysSinceLastPush);

  // Languages
  addTo(buckets.languages, evidence.languages.breakdown.length);
  for (const lang of evidence.languages.breakdown) {
    addTo(buckets.repos, lang.repoCount);
    addTo(buckets.percentages, lang.percentage);
    addTo(buckets.stars, lang.stars);
    addTo(buckets.kb, lang.sizeKb);
  }

  // Scores
  addTo(buckets.scores, evidence.scores.overall);
  addTo(buckets.scores, evidence.scores.quality);
  addTo(buckets.scores, evidence.scores.consistency);
  addTo(buckets.scores, evidence.scores.documentation);
  addTo(buckets.scores, evidence.scores.ambition);
  addTo(buckets.scores, evidence.scores.activity);

  // Notable repositories
  for (const r of evidence.notableRepositories) {
    addTo(buckets.stars, r.stars);
    addTo(buckets.forks, r.forks);
    addTo(buckets.kb, r.sizeKb);
    addTo(buckets.days, r.daysSinceLastPush);
    addTo(buckets.days, r.activeLifespanDays);
    if (evidence.counts.totalStars > 0) {
      addTo(
        buckets.percentages,
        Math.round((r.stars / evidence.counts.totalStars) * 100)
      );
    }
  }

  if (analysis) {
    addTo(buckets.repos, analysis.reposPerYear);
    addTo(buckets.languages, analysis.languages.length);
    for (const r of analysis.allRepos) {
      addTo(buckets.stars, r.stars);
      addTo(buckets.forks, r.forks);
      addTo(buckets.kb, r.sizeKb);
      addTo(buckets.days, r.daysSinceLastPush);
      addTo(buckets.days, r.activeLifespanDays);
    }
  }

  return buckets;
}

const ALLOWED_QUOTED_TERMS = new Set<string>([
  "git init",
  "git push",
  "git push --public",
  "git log",
  "git blame",
  "file > new repository",
  "about",
  "readme",
  "readme.md",
  "package.json",
  "tsconfig.json",
  ".env",
  ".env.local",
  "main",
  "master",
  "mit",
  "apache-2.0",
  "gpl-2.0",
  "gpl-3.0",
  "bsd-3-clause",
  "unclassified",
  "focused specialist",
  "dual-stack",
  "polyglot",
  "weekend build",
  "intermediate",
  "ambitious",
  "n/a",
]);

const ALLOWED_COMPOUND_WORDS = new Set<string>([
  "open-source",
  "closed-source",
  "single-day",
  "single-repo",
  "single-commit",
  "single-language",
  "multi-day",
  "multi-week",
  "multi-month",
  "multi-year",
  "multi-decade",
  "multi-page",
  "multi-language",
  "multi-ecosystem",
  "multi-milestone",
  "multi-instance",
  "day-one",
  "day-1",
  "day-to-day",
  "full-time",
  "part-time",
  "read-only",
  "write-only",
  "real-time",
  "well-tested",
  "well-documented",
  "well-maintained",
  "self-contained",
  "high-signal",
  "high-caffeine",
  "high-res",
  "point-in-time",
  "end-to-end",
  "long-term",
  "short-term",
  "non-proprietary",
  "non-trivial",
  "private-first",
  "one-line",
  "1-line",
  "two-service",
  "zero-dependency",
  "command-line",
  "drop-off",
  "drop-offs",
  "follow-up",
  "follow-through",
  "star-to-repo",
  "original-to-fork",
  "fact-vs-interpretation",
  "evidence-grounded",
  "evidence-backed",
  "ai-generated",
  "ai-live",
  "public-data",
  "language-tagged",
  "topic-tag",
  "rate-limit",
  "avant-garde",
  "micro-repos",
  "ci/cd",
  "next.js",
  "node.js",
  "gemini-3.8-flash",
  "gemini-3.5-flash-lite",
  "gemini-4-argon",
  "gpt-5.4-mini",
  "gpt-5.4-mini-2026-03-17",
  "gpt-5.4",
  "gpt-5.5",
  "gpt-5.6-luna",
  "gpt-5.6-terra",
  "gpt-5.6-sol",
  "gpt-6-luna",
  "gpt-6-sol",
  "gpt-6.1-sol",
  "gpt-6-astra",
  "claude-haiku-5-5",
  "claude-sonnet-5-5",
  "gpt-5-mini",
  "gpt-4.1-mini",
  "gpt-4o-mini",
  "gemini-2.5-flash",
  "claude-sonnet-4-20250514",
  "claude-3-5-haiku-latest",
  "gpl-2.0",
  "gpl-3.0",
  "lgpl-2.1",
  "apache-2.0",
  "bsd-2-clause",
  "bsd-3-clause",
]);

const PROSE_WORDS_AFTER_REPO_NOUN = new Set<string>([
  "that",
  "with",
  "from",
  "where",
  "which",
  "when",
  "while",
  "has",
  "have",
  "had",
  "was",
  "were",
  "is",
  "are",
  "for",
  "and",
  "or",
  "but",
  "the",
  "your",
  "this",
  "these",
  "those",
  "their",
  "into",
  "onto",
  "over",
  "under",
  "across",
  "without",
  "within",
  "like",
  "such",
  "count",
  "counts",
  "list",
  "lists",
  "tab",
  "metadata",
  "history",
  "activity",
  "descriptions",
  "description",
  "structure",
  "quality",
  "hygiene",
  "size",
  "sizes",
  "stars",
  "star",
  "forks",
  "fork",
  "names",
  "name",
  "ideas",
  "recommendations",
  "signals",
  "ambition",
  "velocity",
  "ownership",
  "footprint",
  "surface",
  "tree",
  "index",
  "level",
  "scope",
  "profile",
  "uses",
  "work",
  "code",
  "files",
  "pushes",
  "commits",
  "updates",
  "on",
  "in",
  "at",
  "to",
  "of",
  "by",
  "as",
]);

const ALLOWED_RECOMMENDATION_STACK_TOOLS = new Set<string>([
  "typescript",
  "javascript",
  "python",
  "rust",
  "go",
  "c",
  "c++",
  "c#",
  "java",
  "shell",
  "markdown",
  "html",
  "css",
  "next.js",
  "next.js / astro",
  "astro",
  "react",
  "node.js",
  "tailwind css",
  "vitest",
  "vitest / automated tests",
  "github actions",
  "docker",
  "openapi",
  "rest api",
  "posix",
  "makefile",
  "ci/cd",
  "spdx license",
  "mit license",
  "markdown docs",
  "benchmark suite",
]);

/**
 * Builds strictly separated sets for:
 * - `repoNameSet`: Only actual repository names (and `username/repo` slugs)
 * - `topicSet`: Only repository topic tags
 * - `languageSet`: Only programming languages
 * - `generalVocabSet`: Allowed general technical terms and compound words
 */
export function buildEvidenceVocabularySets(
  evidence: StructuredGitHubEvidence,
  analysis?: GitHubAnalysisMetrics
): EvidenceVocabularySets {
  const repoNameSet = new Set<string>();
  const topicSet = new Set<string>();
  const languageSet = new Set<string>();
  const generalVocabSet = new Set<string>([
    ...Array.from(ALLOWED_QUOTED_TERMS),
    ...Array.from(ALLOWED_COMPOUND_WORDS),
    evidence.username.toLowerCase(),
    evidence.displayName.toLowerCase(),
  ]);

  // Special profile README repo is only valid as username/username
  repoNameSet.add(`${evidence.username}/${evidence.username}`.toLowerCase());

  for (const r of evidence.notableRepositories) {
    repoNameSet.add(r.name.toLowerCase());
    repoNameSet.add(`${evidence.username}/${r.name}`.toLowerCase());
    if (r.language) {
      languageSet.add(r.language.toLowerCase());
    }
    for (const t of r.topics) {
      topicSet.add(t.toLowerCase());
    }
  }

  if (analysis) {
    for (const r of analysis.allRepos) {
      repoNameSet.add(r.name.toLowerCase());
      repoNameSet.add(`${evidence.username}/${r.name}`.toLowerCase());
      if (r.language) {
        languageSet.add(r.language.toLowerCase());
      }
      for (const t of r.topics) {
        topicSet.add(t.toLowerCase());
      }
    }
    for (const l of analysis.languages) {
      languageSet.add(l.language.toLowerCase());
    }
  }

  for (const l of evidence.languages.breakdown) {
    languageSet.add(l.language.toLowerCase());
  }

  return {
    repoNameSet,
    topicSet,
    languageSet,
    generalVocabSet,
  };
}

/**
 * Validates an AI-generated text string against the deterministic GitHub evidence:
 * 1. Maintains separate sets for repository names (`repoNameSet`), topics (`topicSet`),
 *    languages (`languageSet`), and general vocabulary (`generalVocabSet`). A topic or
 *    language is NOT accepted as a repository name when referenced as a repo/project.
 * 2. Rejects both quoted and unquoted fabricated repository names.
 * 3. Validates both whitespace-separated (`7 stars`, `7 repos`) and hyphenated (`7-star`,
 *    `7-repo`) metric claims against category-specific numeric buckets, with `followers`
 *    and `following` separated into distinct buckets.
 * Note: This validator checks quantitative metrics and repository/entity identifiers;
 * qualitative prose is constrained by prompt instructions and fallback structures.
 */
export function validateAiClaimsAgainstEvidence(
  text: string,
  evidence: StructuredGitHubEvidence,
  analysis?: GitHubAnalysisMetrics
): { valid: boolean; reason?: string } {
  if (!text || typeof text !== "string") {
    return { valid: false, reason: "EMPTY_TEXT" };
  }

  const { repoNameSet, topicSet, languageSet, generalVocabSet } =
    buildEvidenceVocabularySets(evidence, analysis);

  // 1. Check explicit repository/project references (quoted OR unquoted)
  // Any identifier immediately following repo/repository/project MUST be in repoNameSet (not merely in topicSet!)
  const contextualRepoRegex =
    /\b(?:repo|repository|project)\s+(?:named\s+|called\s+)?["'`]?([a-zA-Z0-9._-]+(?:\/[a-zA-Z0-9._-]+)?)["'`]?/gi;
  let ctxMatch: RegExpExecArray | null;
  while ((ctxMatch = contextualRepoRegex.exec(text)) !== null) {
    const rawCandidate = ctxMatch[1].replace(/[.,;:!?]+$/, "");
    const lower = rawCandidate.toLowerCase();
    if (/^\d+$/.test(lower)) continue;
    if (PROSE_WORDS_AFTER_REPO_NOUN.has(lower)) continue;
    if (!repoNameSet.has(lower)) {
      return {
        valid: false,
        reason: `UNGROUNDED_REPO_NAME: "${rawCandidate}" is not an actual repository in repoNameSet`,
      };
    }
  }

  // Also check `"identifier" repo/repository/project`
  const preRepoContextRegex =
    /["'`]([a-zA-Z0-9._-]+(?:\/[a-zA-Z0-9._-]+)?)["'`]\s+(?:repo|repository|project)\b/gi;
  while ((ctxMatch = preRepoContextRegex.exec(text)) !== null) {
    const rawCandidate = ctxMatch[1].trim();
    const lower = rawCandidate.toLowerCase();
    if (!repoNameSet.has(lower)) {
      return {
        valid: false,
        reason: `UNGROUNDED_REPO_NAME: "${rawCandidate}" is not an actual repository in repoNameSet`,
      };
    }
  }

  // 2. Check quoted slug identifiers (e.g. "fake-repo-name")
  // Topics in quotes are ONLY permitted if preceded by "topic", "topics", "tag", "tags", or "#"
  const quoteRegex =
    /([a-zA-Z0-9_#]+\s+)?["'`]([a-zA-Z0-9._-]+(?:\/[a-zA-Z0-9._-]+)?)["'`]/g;
  let match: RegExpExecArray | null;
  while ((match = quoteRegex.exec(text)) !== null) {
    const precedingWord = (match[1] || "").trim().toLowerCase();
    const candidate = match[2].trim();
    const lower = candidate.toLowerCase();
    if (/^\d+(?:[.,]\d+)?%?$/.test(lower)) continue;

    const isTopicContext =
      precedingWord === "topic" ||
      precedingWord === "topics" ||
      precedingWord === "tag" ||
      precedingWord === "tags" ||
      precedingWord.endsWith("#");

    if (isTopicContext && topicSet.has(lower)) {
      continue;
    }

    if (
      repoNameSet.has(lower) ||
      languageSet.has(lower) ||
      generalVocabSet.has(lower)
    ) {
      continue;
    }

    if (/^[a-zA-Z0-9._-]+(?:\/[a-zA-Z0-9._-]+)?$/.test(candidate)) {
      return {
        valid: false,
        reason: `UNGROUNDED_REPO_NAME: "${candidate}" is not in the user's analyzed repositories`,
      };
    }
  }

  // 3. Check UNQUOTED slug-like tokens (containing hyphen, underscore, or slash)
  const unquotedSlugRegex =
    /(?<!["\'`a-zA-Z0-9._-])([a-zA-Z0-9]+(?:[-_/][a-zA-Z0-9._-]+)+)(?!["\'`a-zA-Z0-9._-])/g;
  let slugMatch: RegExpExecArray | null;
  while ((slugMatch = unquotedSlugRegex.exec(text)) !== null) {
    const token = slugMatch[1].replace(/[.,;:!?]+$/, "");
    const lower = token.toLowerCase();
    // Skip pure numeric ranges or fractions like 3/3 or 8.5/10
    if (/^\d+(?:[-/.]\d+)+%?$/.test(lower)) continue;
    // Skip hyphenated numeric-unit tokens here so step 4 validates their numeric value against the exact metric bucket!
    if (
      /^\d+(?:\.\d+)?-(?:day|hour|week|month|year|yr|star|repo|repository|repositories|fork|language|follower|following|page|line)s?$/.test(
        lower
      )
    ) {
      continue;
    }
    if (
      repoNameSet.has(lower) ||
      languageSet.has(lower) ||
      generalVocabSet.has(lower)
    ) {
      continue;
    }
    return {
      valid: false,
      reason: `UNGROUNDED_REPO_NAME: unquoted identifier "${token}" is not in the user's analyzed repositories`,
    };
  }

  // 4. Validate numeric claims (including hyphenated forms like "7-star", "7-repo") against category buckets
  const buckets = buildEvidenceMetricBuckets(evidence, analysis);

  // Scrub only actual repository names and username that contain digits
  let scrubbed = text;
  for (const name of Array.from(repoNameSet)) {
    if (name.length >= 2 && /\d/.test(name)) {
      scrubbed = scrubbed
        .split(new RegExp(name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"))
        .join(" ");
    }
  }

  // Scrub fixed structural idioms that are not quantitative profile claims
  scrubbed = scrubbed.replace(
    /\b(?:GPL-2\.0|GPL-3\.0|LGPL-2\.1|Apache-2\.0|BSD-2-Clause|BSD-3-Clause|gemini-3\.8-flash|gemini-3\.5-flash-lite|gemini-4-argon|gpt-5\.4-mini-2026-03-17|gpt-5\.4-mini|gpt-5\.4|gpt-5\.5|gpt-5\.6-luna|gpt-5\.6-terra|gpt-5\.6-sol|gpt-6-luna|gpt-6-sol|gpt-6\.1-sol|gpt-6-astra|claude-haiku-5-5|claude-sonnet-5-5|gpt-5-mini|gpt-4\.1-mini|gpt-4o-mini|gemini-2\.5-flash|claude-sonnet-4-20250514|24(?:\s+|-)hours?|24h|48(?:\s+|-)hours?|48h|last\s+30\s+days|past\s+30\s+days|within\s+30\s+days|30-day\s+milestone|30d|last\s+90\s+days|past\s+90\s+days|within\s+90\s+days|90d|over\s+365\s+days|last\s+365\s+days|365\s+days|365d|Day\s*1|Day-1|1-line|one-line|2\s*AM|3–5|1–2|#1|\d+(?:\.\d+)?\s*\/\s*10)\b/gi,
    " "
  );

  const parseNum = (raw: string): number => Number(raw.replace(/,/g, ""));
  const hasMetricValue = (set: Set<number>, n: number): boolean =>
    set.has(n) || set.has(Math.round(n));

  // 4a. Percentage claims: `<N>%` or `<N> percent`
  const pctRegex =
    /(?<![a-zA-Z0-9_])(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)\s*(?:%|percent\b)/gi;
  let m: RegExpExecArray | null;
  while ((m = pctRegex.exec(scrubbed)) !== null) {
    const val = parseNum(m[1]);
    if (!hasMetricValue(buckets.percentages, val)) {
      return {
        valid: false,
        reason: `UNGROUNDED_NUMBER: percentage claim ${m[1]}% does not match any percentage metric in StructuredGitHubEvidence`,
      };
    }
  }

  // 4b. Repository count claims (including hyphenated "7-repo", "7-repository")
  const repoClaimRegex =
    /(?<![a-zA-Z0-9_])(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)(?:\s+|-)(?:(?:public|analyzed|inspected|original|forked|substantive|dormant|inactive|active|total|language-tagged|undescribed|small|older|secondary|completed|stable|throwaway)(?:\s+|-)){0,3}(?:repos?(?:itories|itory)?\b)/gi;
  while ((m = repoClaimRegex.exec(scrubbed)) !== null) {
    const val = parseNum(m[1]);
    if (!hasMetricValue(buckets.repos, val)) {
      return {
        valid: false,
        reason: `UNGROUNDED_NUMBER: repository count claim "${m[0].trim()}" does not match any repository count in StructuredGitHubEvidence`,
      };
    }
  }

  // 4c. Star count claims (including hyphenated "7-star", "7 stars", "7 ★")
  const starClaimRegex =
    /(?<![a-zA-Z0-9_])(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)(?:\s+|-)(?:(?:total|public|original)(?:\s+|-))?(?:stars?\b|★)/gi;
  while ((m = starClaimRegex.exec(scrubbed)) !== null) {
    const val = parseNum(m[1]);
    if (!hasMetricValue(buckets.stars, val)) {
      return {
        valid: false,
        reason: `UNGROUNDED_NUMBER: star claim "${m[0].trim()}" does not match any star count in StructuredGitHubEvidence`,
      };
    }
  }

  // 4d. Fork count claims (including hyphenated "7-fork", "7 forks")
  const forkClaimRegex =
    /(?<![a-zA-Z0-9_])(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)(?:\s+|-)(?:(?:total|public|upstream)(?:\s+|-))?forks?\b/gi;
  while ((m = forkClaimRegex.exec(scrubbed)) !== null) {
    const val = parseNum(m[1]);
    if (!hasMetricValue(buckets.forks, val)) {
      return {
        valid: false,
        reason: `UNGROUNDED_NUMBER: fork claim "${m[0].trim()}" does not match any fork count in StructuredGitHubEvidence`,
      };
    }
  }

  // 4e. Language count claims (including hyphenated "7-language", "7 languages")
  const langClaimRegex =
    /(?<![a-zA-Z0-9_])(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)(?:\s+|-)(?:(?:distinct|primary|programming|detected)(?:\s+|-)){0,2}languages?\b/gi;
  while ((m = langClaimRegex.exec(scrubbed)) !== null) {
    const val = parseNum(m[1]);
    if (!hasMetricValue(buckets.languages, val)) {
      return {
        valid: false,
        reason: `UNGROUNDED_NUMBER: language count claim "${m[0].trim()}" does not match detected language count in StructuredGitHubEvidence`,
      };
    }
  }

  // 4f. Follower claims (checked strictly against buckets.followers, NOT following)
  const followerClaimRegex =
    /(?:(?<![a-zA-Z0-9_])(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)(?:\s+|-)followers?\b|\bfollowers?\s*[:=]?\s*(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)(?![a-zA-Z0-9_]))/gi;
  while ((m = followerClaimRegex.exec(scrubbed)) !== null) {
    const rawVal = m[1] || m[2];
    const val = parseNum(rawVal);
    if (!hasMetricValue(buckets.followers, val)) {
      return {
        valid: false,
        reason: `UNGROUNDED_NUMBER: follower claim "${m[0].trim()}" does not match follower count in StructuredGitHubEvidence`,
      };
    }
  }

  // 4g. Following claims (checked strictly against buckets.following, NOT followers)
  const followingClaimRegex =
    /(?:(?<![a-zA-Z0-9_])(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)(?:\s+|-)following\b|\bfollowing(?:\s+|-)(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)(?![a-zA-Z0-9_]))/gi;
  while ((m = followingClaimRegex.exec(scrubbed)) !== null) {
    const rawVal = m[1] || m[2];
    const val = parseNum(rawVal);
    if (!hasMetricValue(buckets.following, val)) {
      return {
        valid: false,
        reason: `UNGROUNDED_NUMBER: following claim "${m[0].trim()}" does not match following count in StructuredGitHubEvidence`,
      };
    }
  }

  // 4h. Account tenure claims (including hyphenated "7-year", "7 years")
  const yearClaimRegex =
    /(?<![a-zA-Z0-9_])(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)(?:\s+|-)(?:years?\b|yrs?\b)/gi;
  while ((m = yearClaimRegex.exec(scrubbed)) !== null) {
    const val = parseNum(m[1]);
    if (!hasMetricValue(buckets.years, val)) {
      return {
        valid: false,
        reason: `UNGROUNDED_NUMBER: year claim "${m[0].trim()}" does not match accountAgeYears in StructuredGitHubEvidence`,
      };
    }
  }

  // 4i. Day claims (including hyphenated "7-day", "7 days")
  const dayClaimRegex =
    /(?<![a-zA-Z0-9_])(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)(?:\s+|-)days?\b/gi;
  while ((m = dayClaimRegex.exec(scrubbed)) !== null) {
    const val = parseNum(m[1]);
    if (!hasMetricValue(buckets.days, val)) {
      return {
        valid: false,
        reason: `UNGROUNDED_NUMBER: day claim "${m[0].trim()}" does not match any day metric in StructuredGitHubEvidence`,
      };
    }
  }

  // 4j. Any remaining numeric literal must exist in buckets.allExactNumbers
  const numberRegex =
    /(?<![a-zA-Z0-9_])(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)(?![a-zA-Z0-9_])/g;
  let numMatch: RegExpExecArray | null;
  while ((numMatch = numberRegex.exec(scrubbed)) !== null) {
    const parsed = parseNum(numMatch[1]);
    if (!Number.isFinite(parsed)) continue;

    if (
      !buckets.allExactNumbers.has(parsed) &&
      !buckets.allExactNumbers.has(Math.round(parsed))
    ) {
      return {
        valid: false,
        reason: `UNGROUNDED_NUMBER: ${numMatch[1]} does not match any metric in StructuredGitHubEvidence`,
      };
    }
  }

  return { valid: true };
}

export function validateRecommendationStack(
  candidateStack: unknown,
  fallbackStack: string[],
  evidence: StructuredGitHubEvidence,
  analysis?: GitHubAnalysisMetrics
): string[] {
  if (!Array.isArray(candidateStack) || candidateStack.length === 0) {
    return fallbackStack;
  }

  const allowedNames = new Set<string>(ALLOWED_RECOMMENDATION_STACK_TOOLS);
  allowedNames.add(evidence.languages.topLanguage.toLowerCase());
  for (const l of evidence.languages.breakdown) {
    allowedNames.add(l.language.toLowerCase());
  }
  for (const r of evidence.notableRepositories) {
    for (const t of r.topics) {
      allowedNames.add(t.toLowerCase());
    }
  }
  if (analysis) {
    for (const l of analysis.languages) {
      allowedNames.add(l.language.toLowerCase());
    }
  }

  const validated: string[] = [];
  for (const item of candidateStack.slice(0, 5)) {
    if (typeof item !== "string" || item.trim().length === 0) {
      return fallbackStack;
    }
    const clean = item.trim();
    if (!allowedNames.has(clean.toLowerCase())) {
      return fallbackStack;
    }
    validated.push(clean);
  }

  return validated.length > 0 ? validated : fallbackStack;
}

export function buildAiSystemPrompt(): string {
  return `You are the witty, observant developer critic powering "AI Roast My GitHub".
You will receive a JSON object named "StructuredGitHubEvidence" containing verified metrics from the GitHub REST API.

STRICT EVIDENCE INTEGRITY & FAIRNESS RULES:
1. NEVER invent repository names, commit messages, star counts, percentages, or statistics. Every single number or repository name you mention MUST appear verbatim inside StructuredGitHubEvidence and match the exact metric it describes.
2. Factual anchor fields (observedSignal, observedFact, metricBadge, observedBasis) are locked deterministically by the server. Your job is to provide the witty, insightful INTERPRETATIONS, roast lenses, and concrete project ideas grounded in those exact facts.
3. Respect pagination limits: if pagination.isComplete is false, acknowledge that the analysis covers the fetched sample (pagination.fetchedRepoCount of pagination.totalPublicRepos repositories).
4. Do NOT assume that:
   - More stars automatically means better code quality.
   - Fewer repositories means a lack of engineering skill.
   - An inactive repository (>1yr since push) is "abandoned" if it has substantive size or multi-day history (it may simply be stable/completed).
   - A missing repository description field means poor documentation (GitHub's repo list API only exposes the summary description field, not full README.md contents).
   - Primarily using one programming language indicates a lack of versatility (treat it as domain specialization).
5. Keep the roast funny, clever, specific, and lighthearted—never abusive or hateful.

Return ONLY a valid JSON object matching this exact schema:
{
  "personalityExplanation": {
    "tagline": "string (1 witty sentence summarizing their archetype without inventing numbers)",
    "interpretation": "string (1-2 sentences explaining how the deterministic observedSignal supports this personality)"
  },
  "shortCardRoast": "string (max 150 chars punchy roast citing only verified numbers from StructuredGitHubEvidence)",
  "lenses": {
    "default": {
      "headline": "string (1-2 punchy sentences citing only verified numbers/repo names from StructuredGitHubEvidence)",
      "paragraphs": ["string", "string", "string"]
    },
    "commits": {
      "headline": "string (commit lifecycle & follow-through angle)",
      "paragraphs": ["string", "string"]
    },
    "docs": {
      "headline": "string (metadata hygiene, discoverability & community traction angle)",
      "paragraphs": ["string", "string"]
    }
  },
  "receiptInterpretations": ["string", "string", "string", "string"],
  "strengthInterpretations": [
    {
      "title": "string",
      "interpretation": "string (why the deterministic observedFact is a positive signal)"
    }
  ],
  "redFlagInterpretations": [
    {
      "title": "string",
      "interpretation": "string (nuanced interpretation of the deterministic observedFact without unfair assumptions)"
    }
  ],
  "recommendations": [
    {
      "title": "string",
      "stack": ["string", "string", "string"],
      "difficulty": "Weekend Build" | "Intermediate" | "Ambitious",
      "description": "string",
      "whyItFits": "string"
    }
  ]
}`;
}

/**
 * Builds a Chat Completions request payload compatible with `gpt-5.4-mini` and
 * other OpenAI models:
 * - Per OpenAI API docs, `temperature` is only supported on reasoning-capable
 *   models when `reasoning_effort` is `"none"`.
 * - `gpt-5.4-mini`, `gpt-5.4`, `gpt-5.2`, `gpt-5.6-*`, `gpt-6-luna`, and `gpt-6-sol`
 *   support `reasoning_effort: "none"`, so we explicitly set `reasoning_effort: "none"`
 *   alongside `temperature: 0.5` and `response_format: { type: "json_object" }`.
 * - Models that disallow `reasoning_effort: "none"` and custom `temperature`
 *   (`gpt-6-astra`, `gpt-6.1-sol`, `gpt-5.5*`, `o1*`, `o3*`, `o4*`) omit both
 *   `temperature` and `reasoning_effort: "none"` to prevent HTTP 400 errors.
 */
export function buildOpenAiChatCompletionsBody(
  model: string,
  systemPrompt: string,
  userMessage: string
): Record<string, unknown> {
  const normalized = model.trim().toLowerCase();

  const disallowsNoneReasoningAndTemperature =
    normalized.startsWith("gpt-6-astra") ||
    normalized.startsWith("gpt-6.1-sol") ||
    normalized.startsWith("gpt-5.5") ||
    /^o\d/.test(normalized);

  const supportsNoneReasoningEffort =
    !disallowsNoneReasoningAndTemperature &&
    (normalized.startsWith("gpt-5.") || normalized.startsWith("gpt-6-"));

  const body: Record<string, unknown> = {
    model,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userMessage },
    ],
  };

  if (supportsNoneReasoningEffort) {
    body.reasoning_effort = "none";
    body.temperature = 0.5;
  } else if (!disallowsNoneReasoningAndTemperature) {
    body.temperature = 0.5;
  }

  return body;
}

async function callProviderApi(
  config: AiProviderConfig,
  evidence: StructuredGitHubEvidence,
  timeoutMs: number,
  fetchImpl: typeof fetch
): Promise<unknown> {
  const systemPrompt = buildAiSystemPrompt();
  const userMessage = `StructuredGitHubEvidence JSON:\n${JSON.stringify(
    evidence,
    null,
    2
  )}`;

  let res: Response;
  try {
    if (config.provider === "openai") {
      res = await fetchWithTimeout(
        "https://api.openai.com/v1/chat/completions",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${config.apiKey}`,
          },
          body: JSON.stringify(
            buildOpenAiChatCompletionsBody(
              config.model,
              systemPrompt,
              userMessage
            )
          ),
        },
        timeoutMs,
        fetchImpl
      );
    } else if (config.provider === "gemini") {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
        config.model
      )}:generateContent?key=${encodeURIComponent(config.apiKey)}`;
      res = await fetchWithTimeout(
        url,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            systemInstruction: {
              parts: [{ text: systemPrompt }],
            },
            contents: [
              {
                role: "user",
                parts: [{ text: userMessage }],
              },
            ],
            generationConfig: {
              temperature: 0.5,
              responseMimeType: "application/json",
            },
          }),
        },
        timeoutMs,
        fetchImpl
      );
    } else {
      res = await fetchWithTimeout(
        "https://api.anthropic.com/v1/messages",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": config.apiKey,
            "anthropic-version": "2023-06-01",
          },
          body: JSON.stringify({
            model: config.model,
            max_tokens: 2048,
            system: systemPrompt,
            messages: [
              {
                role: "user",
                content: `${userMessage}\n\nRespond with ONLY raw valid JSON matching the schema.`,
              },
            ],
          }),
        },
        timeoutMs,
        fetchImpl
      );
    }
  } catch (err) {
    if (isAbortOrTimeoutError(err)) {
      throw new AiRoastError(
        `AI provider (${config.provider}) request timed out after ${timeoutMs}ms.`,
        504,
        "AI_PROVIDER_TIMEOUT"
      );
    }
    const errMsg = err instanceof Error ? err.message : "network error";
    throw new AiRoastError(
      `Failed to connect to AI provider (${config.provider}): ${errMsg}`,
      502,
      "AI_PROVIDER_ERROR"
    );
  }

  if (!res.ok) {
    let errorDetail = `HTTP ${res.status}`;
    try {
      const errJson = await res.json();
      errorDetail =
        errJson?.error?.message ||
        errJson?.message ||
        JSON.stringify(errJson).slice(0, 200);
    } catch (err) {
      if (isAbortOrTimeoutError(err)) {
        throw new AiRoastError(
          `AI provider (${config.provider}) error response timed out after ${timeoutMs}ms.`,
          504,
          "AI_PROVIDER_TIMEOUT"
        );
      }
    }
    throw new AiRoastError(
      `AI provider (${config.provider}) returned an error: ${errorDetail}`,
      res.status === 504 ? 504 : 502,
      res.status === 504 ? "AI_PROVIDER_TIMEOUT" : "AI_PROVIDER_ERROR"
    );
  }

  let payload: any;
  try {
    payload = await res.json();
  } catch (err) {
    if (isAbortOrTimeoutError(err)) {
      throw new AiRoastError(
        `AI provider (${config.provider}) response body timed out after ${timeoutMs}ms.`,
        504,
        "AI_PROVIDER_TIMEOUT"
      );
    }
    throw new AiRoastError(
      `AI provider (${config.provider}) returned unreadable response body.`,
      502,
      "AI_PROVIDER_ERROR"
    );
  }

  let rawJsonText = "";

  if (config.provider === "openai") {
    const message = payload?.choices?.[0]?.message;
    if (
      typeof message?.refusal === "string" &&
      message.refusal.trim().length > 0
    ) {
      throw new AiRoastError(
        `AI provider (openai) refused the request: ${message.refusal.trim()}`,
        502,
        "AI_PROVIDER_ERROR"
      );
    }
    if (typeof message?.content === "string") {
      rawJsonText = message.content;
    } else if (Array.isArray(message?.content)) {
      rawJsonText = message.content
        .filter((part: any) => part && typeof part.text === "string")
        .map((part: any) => part.text)
        .join("");
    }
  } else if (config.provider === "gemini") {
    const parts = payload?.candidates?.[0]?.content?.parts;
    if (Array.isArray(parts)) {
      rawJsonText =
        parts
          .filter((p: any) => p && typeof p.text === "string" && !p.thought)
          .map((p: any) => p.text)
          .join("") ||
        parts[0]?.text ||
        "";
    }
  } else {
    const blocks = payload?.content;
    if (Array.isArray(blocks)) {
      const textBlock = blocks.find(
        (b: any) => b && b.type === "text" && typeof b.text === "string"
      );
      rawJsonText = textBlock?.text || blocks[0]?.text || "";
    }
  }

  if (!rawJsonText || typeof rawJsonText !== "string") {
    throw new AiRoastError(
      `AI provider (${config.provider}) returned an empty completion payload.`,
      502,
      "AI_PROVIDER_ERROR"
    );
  }

  const cleaned = rawJsonText
    .trim()
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/, "");

  try {
    return JSON.parse(cleaned);
  } catch {
    throw new AiRoastError(
      `AI provider (${config.provider}) returned malformed JSON output.`,
      502,
      "AI_PROVIDER_ERROR"
    );
  }
}

/**
 * Generates deterministic, evidence-grounded content from the GitHub metrics.
 * Used as the immutable source of truth for all `observedFact`, `metricBadge`,
 * and `observedBasis` fields, and as the fallback narrative in explicit demo/fallback mode.
 */
export function buildDeterministicGroundedRoast(
  user: GitHubUser,
  m: GitHubAnalysisMetrics,
  scores: DeveloperScores,
  personality: DeveloperPersonality,
  source: "heuristic-fallback" | "demo-fixture" = "heuristic-fallback"
): RoastContent {
  const displayName = user.name || `@${user.login}`;
  const coverageClause = m.pagination.isComplete
    ? `all ${m.analyzedRepoCount} public repositories`
    : `${m.analyzedRepoCount} analyzed repositories (${m.pagination.coveragePercentage}% sample of ${m.publicRepoCount} total public repos)`;

  if (m.analyzedRepoCount === 0) {
    return {
      shortCardRoast: `${m.accountAgeYears} years on GitHub, 0 public repos, and ${user.followers || 0} followers waiting for a public commit.`,
      lenses: {
        default: {
          headline: `${displayName} has ${m.accountAgeYears} years on GitHub and 0 public repositories—maintaining a spotless 0% public bug rate by never shipping in daylight.`,
          paragraphs: [
            `Observed fact: @${user.login} has been registered for ${m.accountAgeYears} years, has ${user.followers || 0} follower(s), and exposes 0 public repositories. Interpretation: either your entire engineering career lives behind private organization firewalls, or you use GitHub strictly as a read-only social network.`,
            user.bio
              ? `Observed fact: Your profile bio reads "${user.bio}". Interpretation: bold positioning for a profile whose public repository tab is currently an empty room.`
              : `Observed fact: Both your profile bio and public repository list are empty. Interpretation: maximum mystery, zero public attack surface.`,
          ],
        },
        commits: {
          headline: `Commit Lifecycle Audit: 0 public pushes across ${m.accountAgeYears} years on GitHub.`,
          paragraphs: [
            `Observed fact: There are 0 public repositories to measure commit lifespan or push recency. Interpretation: you cannot be accused of abandoning weekend prototypes if you never run git push --public.`,
          ],
        },
        docs: {
          headline: `Public Metadata Audit: 0 public repositories, ${user.public_gists || 0} public gists, and ${user.followers || 0} followers.`,
          paragraphs: [
            `Observed fact: No public repository descriptions, topics, or licenses exist on @${user.login}. Interpretation: adding a special ${user.login}/${user.login} profile README would give visitors context without requiring you to open-source private code.`,
          ],
        },
      },
      receipts: [
        {
          observedFact: `0 public repositories over ${m.accountAgeYears} years on GitHub.`,
          interpretation: "All coding activity is either private or off-platform.",
        },
        {
          observedFact: `${user.followers || 0} follower(s) and ${user.following || 0} following.`,
          interpretation:
            "Community connections exist despite zero public repositories.",
        },
      ],
      strengths: [
        {
          title: "Zero Public Prototype Clutter",
          observedFact:
            "0 public repositories and 0 abandoned public throwaways.",
          interpretation:
            "Unlike profiles cluttered with broken tutorial forks, your public surface area is completely clean.",
          metricBadge: "0 Clutter",
        },
        {
          title: "Established Account Tenure",
          observedFact: `Account registered ${m.accountAgeYears} years ago with ${user.followers || 0} follower(s).`,
          interpretation: `You've held the @${user.login} handle for ${m.accountAgeYears} years.`,
          metricBadge: `${m.accountAgeYears} Yrs Tenure`,
        },
        {
          title: "Private-First Engineering Posture",
          observedFact: `0 public repos exposed alongside ${user.public_gists || 0} public gists.`,
          interpretation:
            "Many commercial engineers commit exclusively to private corporate repositories.",
          metricBadge: "Stealth Profile",
        },
      ],
      redFlags: [
        {
          title: "No Public Code Samples Available",
          observedFact: "0 public repositories returned by the GitHub REST API.",
          interpretation:
            "Collaborators or prospective peers visiting your GitHub URL have no public code or architecture samples to inspect.",
          metricBadge: "0 Public Repos",
        },
        {
          title: "Missing Profile README Repository",
          observedFact: `No public "${user.login}/${user.login}" repository found.`,
          interpretation:
            "Without a profile README, visitors cannot tell what technologies or domains you specialize in.",
          metricBadge: "No Profile README",
        },
        {
          title: user.bio ? "Unverified Bio Claims" : "Sparse Profile Metadata",
          observedFact: user.bio
            ? `Bio states "${user.bio}" with 0 linked public repositories.`
            : "Bio, blog URL, and public repository list are all empty.",
          interpretation:
            "Adding a short bio or a single flagship showcase repository would immediately anchor your public profile.",
          metricBadge: "Low Discoverability",
        },
      ],
      recommendations: [
        {
          title: `Create a @${user.login} Profile README`,
          stack: ["Markdown", "GitHub Actions"],
          difficulty: "Weekend Build",
          description: `Initialize a public "${user.login}/${user.login}" repository with an overview of your core stack, engineering focus, and contact links.`,
          observedBasis: `0 public repositories over ${m.accountAgeYears} years on GitHub.`,
          whyItFits:
            "Gives visitors immediate context about your work even if your day-to-day codebases must remain private.",
        },
        {
          title: "Publish One Self-Contained Reference Utility",
          stack: ["TypeScript", "Node.js", "Vitest"],
          difficulty: "Intermediate",
          description:
            "Extract a non-proprietary CLI tool, parser, or library with unit tests, a clear README, and an open-source license.",
          observedBasis: `0 public repositories currently visible to your ${user.followers || 0} follower(s).`,
          whyItFits:
            "One deep, well-tested repository is far more effective than dozens of small filler repos.",
        },
        {
          title: "Interactive Technical Architecture Demo",
          stack: ["Next.js", "TypeScript", "Tailwind CSS"],
          difficulty: "Ambitious",
          description:
            "Build and deploy a single polished web application with a live homepage URL linked in the repository metadata.",
          observedBasis: `Profile currently has 0 linked homepage deployments.`,
          whyItFits:
            "Demonstrates end-to-end product execution with a single high-signal public project.",
        },
      ],
      generationSource: source,
      aiModelUsed:
        source === "demo-fixture"
          ? "deterministic-demo-engine"
          : "deterministic-heuristic-fallback",
    };
  }

  const mostNotable = m.mostActiveRepos[0];
  const newestRepo = m.recentlyUpdatedRepos[0];
  const oldestRepo = [...m.allRepos].sort(
    (a, b) => b.daysSinceLastPush - a.daysSinceLastPush
  )[0];
  const undescribedSample = m.allRepos
    .filter((r) => !r.description)
    .slice(0, 3)
    .map((r) => `"${r.name}"`);

  let defaultHeadline = "";
  let shortCardRoast = "";

  if (m.initialCommitOnlyCount >= 3) {
    defaultHeadline = `Across ${coverageClause}, ${m.initialCommitOnlyCount} of your original repositories had their final push within 24 hours of creation—proving that git init is your favorite part of the software lifecycle.`;
    shortCardRoast = `${m.analyzedRepoCount} repos analyzed: ${m.initialCommitOnlyCount} single-day prototypes and ${m.substantiveOriginalCount} substantive builds.`;
  } else if (m.missingDescriptionPercent >= 50) {
    defaultHeadline = `In ${coverageClause}, ${m.missingDescriptionCount} repositories (${m.missingDescriptionPercent}%) omit the GitHub summary description—turning ${
      undescribedSample[0] || `"${newestRepo.name}"`
    } into a mystery box for anyone browsing your profile.`;
    shortCardRoast = `${m.publicRepoCount} public repos with ${m.missingDescriptionPercent}% missing summary descriptions—leaving visitors to read raw source code.`;
  } else if (m.forkRepoCount > m.originalRepoCount) {
    defaultHeadline = `With ${m.forkRepoCount} forks versus ${m.originalRepoCount} original repositories in ${coverageClause}, your profile reads like a museum curation of other people's repositories.`;
    shortCardRoast = `${m.forkRepoCount} forks vs ${m.originalRepoCount} original repos—hitting Fork like it's a browser bookmark button.`;
  } else {
    defaultHeadline = `Across ${coverageClause} and ${m.accountAgeYears} years on GitHub, your ${m.topLanguage} focus (${
      m.languages[0]?.percentage || 100
    }% of tagged repos) and ${m.substantiveOriginalCount} substantive original project(s) show real depth—alongside ${m.inactiveOver1YearCount} older repo(s) resting in peace.`;
    shortCardRoast = `${m.publicRepoCount} public repos (${m.topLanguage} #1), ${m.totalStars.toLocaleString()} ★, and ${m.substantiveOriginalCount} substantive original builds.`;
  }

  const p1 = `Observed facts: Across ${coverageClause}, ${m.originalRepoCount} are original (${m.originalPercentage}%) and ${m.forkRepoCount} are forks, accumulating ${m.totalStars.toLocaleString()} star(s) and ${m.totalForks.toLocaleString()} fork(s), with "${mostNotable.name}" leading at ${mostNotable.stars.toLocaleString()} ★ and ${mostNotable.sizeKb.toLocaleString()} KB. Interpretation: ${
    m.substantiveOriginalCount >= Math.ceil(m.originalRepoCount * 0.5)
      ? `The majority of your original repositories (${m.substantiveOriginalCount}/${m.originalRepoCount}) have real codebase weight or multi-day commit history—even when star counts stay modest.`
      : `A few key repositories like "${mostNotable.name}" carry the technical depth while smaller experiments orbit around them.`
  }`;

  const p2 = `Observed facts: ${
    m.languages.length > 0
      ? `${m.topLanguage} leads across ${m.languages[0].repoCount} repo(s) (${m.languages[0].percentage}%), classified as "${m.languageSpecialization}" across ${m.languages.length} language(s).`
      : "No primary programming languages were tagged by GitHub."
  } Meanwhile, ${m.missingDescriptionCount} repo(s) (${m.missingDescriptionPercent}%) lack a short GitHub description, ${m.reposWithTopicsCount}/${m.analyzedRepoCount} include topic tags, and ${m.reposWithHomepageCount}/${m.analyzedRepoCount} link a homepage URL. Interpretation: ${
    m.languageSpecialization === "Focused Specialist"
      ? `Focusing heavily on ${m.topLanguage} reflects deliberate domain specialization rather than a lack of versatility, though filling in missing summary blurbs and topic tags would make that expertise much easier to discover.`
      : `Your multi-language footprint shows broad curiosity, though ${m.missingDescriptionCount} repository(s) without summary blurbs force visitors to open the code tree to see what they do.`
  }`;

  const p3 = `Observed facts: Your most recent public push was ${m.daysSinceLastActive} day(s) ago on "${newestRepo.name}", with ${m.activeLast90Days} repo(s) updated in the last 90 days, ${m.stableCompletedCount} older repo(s) sitting stable after multi-day development, and ${m.initialCommitOnlyCount} small original repo(s) untouched after Day 1. Interpretation: ${
    m.initialCommitOnlyCount > 0
      ? `Unlike your ${m.stableCompletedCount} completed/stable repositories (which simply don't need constant churn), those ${m.initialCommitOnlyCount} single-day prototypes look like 2 AM bursts of inspiration that never saw a second commit.`
      : `Your older inactive repositories (${m.stableCompletedCount} stable/completed) show multi-day engineering follow-through rather than Day-1 abandonment.`
  }`;

  const receipts: FactInterpretationReceipt[] = [
    {
      observedFact: `${m.substantiveOriginalCount} of ${m.originalRepoCount} original repos have >=25 KB size or >=3 days of commit history; total stars: ${m.totalStars.toLocaleString()}.`,
      interpretation:
        "Codebase depth and commit lifespan measure engineering substance independently of social star popularity.",
    },
    {
      observedFact: `${m.stableCompletedCount} inactive repo(s) (>1yr) had multi-day development or substantive size, vs ${m.initialCommitOnlyCount} small Day-1 throwaway(s).`,
      interpretation:
        "Finished tools and libraries naturally stop receiving commits once stable; only single-day micro-repos indicate early drop-off.",
    },
    {
      observedFact: `${m.missingDescriptionCount} repo(s) (${m.missingDescriptionPercent}%) omit the short 'About' description; ${m.reposWithTopicsCount}/${m.analyzedRepoCount} have topic tags.`,
      interpretation:
        "Repos without an 'About' blurb may still have good README.md files, but missing metadata hurts profile scanability.",
    },
    {
      observedFact: `Language profile: ${m.languageSpecialization} led by ${m.topLanguage} (${m.languages[0]?.percentage || 0}% across ${m.languages.length} language(s)).`,
      interpretation:
        m.languages.length === 1
          ? `Deep specialization in ${m.topLanguage} is a valid focus strategy, not a red flag.`
          : `Active across ${m.languages
              .map((l) => l.language)
              .slice(0, 4)
              .join(", ")}.`,
    },
  ];

  const strengths: EvidencePoint[] = [];

  if (m.substantiveOriginalCount > 0) {
    strengths.push({
      title: "Substantive Original Codebases",
      observedFact: `${m.substantiveOriginalCount} of ${m.originalRepoCount} original repositories exceed 25 KB or span multiple days of commit iteration (led by "${mostNotable.name}").`,
      interpretation:
        "Demonstrates ability to build and iterate on real codebases beyond initial boilerplate.",
      metricBadge: `${m.substantiveOriginalCount} Substantive Repos`,
    });
  }

  if (m.originalPercentage >= 70) {
    strengths.push({
      title: "High Original-to-Fork Ratio",
      observedFact: `${m.originalRepoCount} of ${m.analyzedRepoCount} analyzed repositories (${m.originalPercentage}%) are original repositories rather than upstream forks.`,
      interpretation:
        "Your public profile primarily reflects code you initiated yourself.",
      metricBadge: `${m.originalPercentage}% Original`,
    });
  }

  if (m.languages.length >= 3) {
    strengths.push({
      title: "Multi-Ecosystem Technical Breadth",
      observedFact: `Repositories span ${m.languages.length} primary languages (${m.languages
        .slice(0, 4)
        .map((l) => `${l.language}: ${l.repoCount}`)
        .join(", ")}).`,
      interpretation:
        "Comfortable shipping code across multiple runtimes and ecosystems.",
      metricBadge: `${m.languages.length} Languages`,
    });
  } else if (m.languages.length >= 1) {
    strengths.push({
      title: `Focused ${m.topLanguage} Specialization`,
      observedFact: `${m.languages[0].repoCount} repository(s) (${m.languages[0].percentage}%) built in ${m.topLanguage} totaling ${Math.round(
        m.languages[0].sizeKb
      ).toLocaleString()} KB.`,
      interpretation:
        "Consistent depth in a primary language builds stronger ecosystem mastery than shallow framework hopping.",
      metricBadge: `${m.topLanguage} Specialist`,
    });
  }

  if (m.totalStars > 0) {
    strengths.push({
      title: `Community Validation on "${mostNotable.name}"`,
      observedFact: `Earned ${m.totalStars.toLocaleString()} total stars and ${m.totalForks.toLocaleString()} forks across analyzed repositories.`,
      interpretation:
        "External developers have bookmarked or forked your public work.",
      metricBadge: `${m.totalStars.toLocaleString()} ★`,
    });
  }

  if (m.initialCommitOnlyCount === 0 && m.originalRepoCount > 0) {
    strengths.push({
      title: "Strong Project Follow-Through",
      observedFact: `0 of your ${m.originalRepoCount} original repositories were abandoned as small Day-1 throwaways.`,
      interpretation:
        "When you publish a public repository, you follow through past the initial commit.",
      metricBadge: "0 Day-1 Drops",
    });
  }

  while (strengths.length < 3) {
    strengths.push({
      title: "Established Public Engineering History",
      observedFact: `${m.publicRepoCount} public repository(s) maintained across ${m.accountAgeYears} years on GitHub.`,
      interpretation:
        "Consistent long-term presence on GitHub with verifiable repository history.",
      metricBadge: `${m.accountAgeYears} Yrs Active`,
    });
  }

  const redFlags: EvidencePoint[] = [];

  if (m.initialCommitOnlyCount > 0) {
    redFlags.push({
      title: "Single-Day Prototype Drop-Offs",
      observedFact: `${m.initialCommitOnlyCount} of ${m.originalRepoCount} original repositories (<35 KB) had their final push within 24 hours of creation.`,
      interpretation:
        "While completed projects naturally go quiet, small repositories with only Day-1 commits look like unfinished experiments.",
      metricBadge: `${m.initialCommitOnlyCount} Day-1 Prototypes`,
    });
  }

  if (m.missingDescriptionCount > 0) {
    redFlags.push({
      title: "Missing Summary Descriptions on Profile Index",
      observedFact: `${m.missingDescriptionCount} of ${
        m.originalRepoCount || m.analyzedRepoCount
      } repositories (${m.missingDescriptionPercent}%) have an empty GitHub 'About' description (${undescribedSample.join(
        ", "
      )}).`,
      interpretation:
        "Even if those repositories contain internal README.md files, omitting the 1-line summary description makes your profile harder to scan.",
      metricBadge: `${m.missingDescriptionPercent}% No Blurb`,
    });
  }

  if (m.reposWithTopicsCount < Math.ceil(m.analyzedRepoCount * 0.4)) {
    redFlags.push({
      title: "Low Topic Tag Discoverability",
      observedFact: `Only ${m.reposWithTopicsCount} of ${m.analyzedRepoCount} analyzed repositories include GitHub topic tags.`,
      interpretation:
        "Adding 3–5 topic tags per repository improves search indexing and clarifies what frameworks each project uses.",
      metricBadge: `${m.reposWithTopicsCount}/${m.analyzedRepoCount} Tagged`,
    });
  }

  if (m.forkRepoCount > 0 && m.originalPercentage < 60) {
    redFlags.push({
      title: "Forks Outnumber or Compete with Original Work",
      observedFact: `${m.forkRepoCount} of ${m.analyzedRepoCount} analyzed repositories (${
        100 - m.originalPercentage
      }%) are forks of upstream projects.`,
      interpretation:
        "Unmodified forks can bury your original repositories unless you curate your 6 pinned repositories.",
      metricBadge: `${m.forkRepoCount} Forks`,
    });
  }

  if (m.reposWithLicenseCount < Math.ceil(m.analyzedRepoCount * 0.4)) {
    redFlags.push({
      title: "Missing Open-Source License Declarations",
      observedFact: `${
        m.analyzedRepoCount - m.reposWithLicenseCount
      } of ${m.analyzedRepoCount} repositories do not declare an SPDX license in GitHub metadata.`,
      interpretation:
        "Without a license file (such as MIT or Apache-2.0), public code is 'all rights reserved' by default.",
      metricBadge: `${m.reposWithLicenseCount}/${m.analyzedRepoCount} Licensed`,
    });
  }

  if (m.reposWithHomepageCount < Math.ceil(m.analyzedRepoCount * 0.25)) {
    redFlags.push({
      title: "Few Linked Live Deployments or Docs URLs",
      observedFact: `Only ${m.reposWithHomepageCount} of ${m.analyzedRepoCount} repositories populate the homepage/documentation URL field.`,
      interpretation:
        "Linking a live demo, package registry page, or docs URL lets visitors experience your projects without cloning.",
      metricBadge: `${m.reposWithHomepageCount}/${m.analyzedRepoCount} Live Links`,
    });
  }

  while (redFlags.length < 3) {
    redFlags.push({
      title: "Recent Public Commit Cadence",
      observedFact: `${m.activeLast90Days} of ${m.analyzedRepoCount} repositories received pushes in the last 90 days (latest push: ${m.daysSinceLastActive}d ago on "${
        oldestRepo ? newestRepo.name : "N/A"
      }").`,
      interpretation:
        "Periodic maintenance releases or changelog updates help signal which repositories are actively supported.",
      metricBadge: `${m.activeLast90Days} Active (90d)`,
    });
  }

  const primary = m.languages[0]?.language || "TypeScript";
  const secondary = m.languages[1]?.language || primary;
  const existingTopics = Array.from(
    new Set(m.allRepos.flatMap((r) => r.topics))
  ).slice(0, 4);

  const recommendations: ProjectRecommendation[] = [
    {
      title: `Polished ${primary} Package or CLI with Automated Releases`,
      stack: [primary, "GitHub Actions", "Vitest / Automated Tests"],
      difficulty: "Intermediate",
      description: `Package your strongest ${primary} patterns into a well-tested library or CLI tool with CI badges, semantic releases, topic tags, and an SPDX license.`,
      observedBasis: `Top language is ${primary} (${
        m.languages[0]?.repoCount || 1
      } repos); ${m.reposWithLicenseCount}/${
        m.analyzedRepoCount
      } repos currently specify a license.`,
      whyItFits: `Showcases your ${primary} depth while directly improving your profile's license and topic-tag discoverability.`,
    },
    {
      title: `Interactive Documentation & Live Demo for "${mostNotable.name}"`,
      stack: [primary, "Next.js / Astro", "Markdown Docs"],
      difficulty: "Weekend Build",
      description: `Create an interactive browser playground or architecture microsite for "${mostNotable.name}" and attach the URL to its GitHub homepage field.`,
      observedBasis: `"${mostNotable.name}" is a top repository (${mostNotable.stars.toLocaleString()} ★, ${mostNotable.sizeKb.toLocaleString()} KB), while ${
        m.analyzedRepoCount - m.reposWithHomepageCount
      } repos lack a homepage URL.`,
      whyItFits: `Turns your most substantive existing repository into an immediately playable showcase for visitors.`,
    },
    {
      title:
        primary !== secondary
          ? `Multi-Milestone ${primary} + ${secondary} Architecture Project`
          : `Deep ${primary} Architecture Benchmark & Reference App`,
      stack:
        primary !== secondary
          ? [primary, secondary, "Docker", "OpenAPI"]
          : [primary, "Benchmark Suite", "CI/CD"],
      difficulty: "Ambitious",
      description: `Develop a multi-week flagship repository with weekly release tags, architecture decision records (ADRs), and clear summary metadata.`,
      observedBasis: `${
        existingTopics.length > 0
          ? `Existing topics include ${existingTopics.join(", ")}; `
          : ""
      }${m.initialCommitOnlyCount} single-day prototype(s) vs ${
        m.substantiveOriginalCount
      } substantive repo(s).`,
      whyItFits: `Demonstrates sustained multi-week engineering follow-through and architectural clarity.`,
    },
  ];

  return {
    shortCardRoast,
    lenses: {
      default: {
        headline: defaultHeadline,
        paragraphs: [p1, p2, p3],
      },
      commits: {
        headline: `Commit Lifecycle & Follow-Through: ${m.substantiveOriginalCount} substantive original project(s), ${m.stableCompletedCount} stable completed repo(s), and ${m.initialCommitOnlyCount} Day-1 prototype(s).`,
        paragraphs: [p3, p1],
      },
      docs: {
        headline: `Public Metadata & Discoverability: ${
          100 - m.missingDescriptionPercent
        }% with summary descriptions, ${m.reposWithTopicsCount}/${
          m.analyzedRepoCount
        } with topic tags, and ${m.reposWithLicenseCount}/${
          m.analyzedRepoCount
        } licensed.`,
        paragraphs: [p2, p1],
      },
    },
    receipts,
    strengths: strengths.slice(0, 5),
    redFlags: redFlags.slice(0, 5),
    recommendations,
    generationSource: source,
    aiModelUsed:
      source === "demo-fixture"
        ? "deterministic-demo-engine"
        : "deterministic-heuristic-fallback",
  };
}

/**
 * Validates the AI response against StructuredGitHubEvidence and merges only
 * verified interpretations while keeping all factual fields (`observedFact`,
 * `metricBadge`, `observedSignal`, `observedBasis`) locked to deterministic values.
 */
export function validateAndMergeAiOutput(
  rawAi: unknown,
  personality: DeveloperPersonality,
  fallback: RoastContent,
  modelName: string,
  evidence: StructuredGitHubEvidence,
  analysis?: GitHubAnalysisMetrics
): { roast: RoastContent; updatedPersonality: DeveloperPersonality } {
  if (!rawAi || typeof rawAi !== "object") {
    throw new AiRoastError(
      "AI response was not a valid JSON object.",
      502,
      "AI_PROVIDER_ERROR"
    );
  }

  const obj = rawAi as Record<string, any>;

  if (
    !obj.lenses?.default?.headline ||
    !Array.isArray(obj.lenses?.default?.paragraphs) ||
    obj.lenses.default.paragraphs.length === 0
  ) {
    throw new AiRoastError(
      "AI response omitted required roast lenses.default fields.",
      502,
      "AI_PROVIDER_ERROR"
    );
  }

  // Strictly validate primary default roast headline and paragraphs against evidence
  const defaultHeadline = String(obj.lenses.default.headline).trim();
  const headlineCheck = validateAiClaimsAgainstEvidence(
    defaultHeadline,
    evidence,
    analysis
  );
  if (!headlineCheck.valid) {
    throw new AiRoastError(
      `AI output rejected due to ungrounded claim in headline (${headlineCheck.reason}).`,
      502,
      "AI_EVIDENCE_VIOLATION"
    );
  }

  const defaultParagraphs: string[] = [];
  for (const rawP of obj.lenses.default.paragraphs.slice(0, 4)) {
    const pStr = String(rawP).trim();
    const pCheck = validateAiClaimsAgainstEvidence(pStr, evidence, analysis);
    if (!pCheck.valid) {
      throw new AiRoastError(
        `AI output rejected due to ungrounded claim in roast paragraph (${pCheck.reason}).`,
        502,
        "AI_EVIDENCE_VIOLATION"
      );
    }
    defaultParagraphs.push(pStr);
  }

  const pickVerifiedText = (candidate: unknown, fallbackText: string): string => {
    if (typeof candidate !== "string" || candidate.trim().length === 0) {
      return fallbackText;
    }
    const trimmed = candidate.trim();
    const check = validateAiClaimsAgainstEvidence(trimmed, evidence, analysis);
    return check.valid ? trimmed : fallbackText;
  };

  // Personality: keep id, title, and observedSignal 100% deterministic; only validate tagline & interpretation
  const updatedPersonality: DeveloperPersonality = {
    ...personality,
    observedSignal: personality.observedSignal,
    tagline: pickVerifiedText(
      obj.personalityExplanation?.tagline,
      personality.tagline
    ),
    interpretation: pickVerifiedText(
      obj.personalityExplanation?.interpretation,
      personality.interpretation
    ),
  };

  // Receipts: keep observedFact 100% deterministic; allow verified AI interpretation
  const rawReceiptInterps = Array.isArray(obj.receiptInterpretations)
    ? obj.receiptInterpretations
    : Array.isArray(obj.receipts)
    ? obj.receipts.map((r: any) => r?.interpretation)
    : [];

  const receipts: FactInterpretationReceipt[] = fallback.receipts.map(
    (detReceipt, idx) => ({
      observedFact: detReceipt.observedFact,
      interpretation: pickVerifiedText(
        rawReceiptInterps[idx],
        detReceipt.interpretation
      ),
    })
  );

  // Strengths: keep observedFact and metricBadge 100% deterministic
  const rawStrengthItems = Array.isArray(obj.strengthInterpretations)
    ? obj.strengthInterpretations
    : Array.isArray(obj.strengths)
    ? obj.strengths
    : [];

  const strengths: EvidencePoint[] = fallback.strengths.map(
    (detStrength, idx) => ({
      title: pickVerifiedText(
        rawStrengthItems[idx]?.title,
        detStrength.title
      ),
      observedFact: detStrength.observedFact,
      interpretation: pickVerifiedText(
        rawStrengthItems[idx]?.interpretation,
        detStrength.interpretation
      ),
      metricBadge: detStrength.metricBadge,
    })
  );

  // Red Flags: keep observedFact and metricBadge 100% deterministic
  const rawFlagItems = Array.isArray(obj.redFlagInterpretations)
    ? obj.redFlagInterpretations
    : Array.isArray(obj.redFlags)
    ? obj.redFlags
    : [];

  const redFlags: EvidencePoint[] = fallback.redFlags.map((detFlag, idx) => ({
    title: pickVerifiedText(rawFlagItems[idx]?.title, detFlag.title),
    observedFact: detFlag.observedFact,
    interpretation: pickVerifiedText(
      rawFlagItems[idx]?.interpretation,
      detFlag.interpretation
    ),
    metricBadge: detFlag.metricBadge,
  }));

  // Recommendations: keep observedBasis 100% deterministic and validate stack items + prose
  const rawRecs = Array.isArray(obj.recommendations) ? obj.recommendations : [];
  const recommendations: ProjectRecommendation[] = fallback.recommendations.map(
    (detRec, idx) => {
      const candidate = rawRecs[idx];
      return {
        title: pickVerifiedText(candidate?.title, detRec.title),
        stack: validateRecommendationStack(
          candidate?.stack,
          detRec.stack,
          evidence,
          analysis
        ),
        difficulty:
          candidate?.difficulty === "Weekend Build" ||
          candidate?.difficulty === "Intermediate" ||
          candidate?.difficulty === "Ambitious"
            ? candidate.difficulty
            : detRec.difficulty,
        description: pickVerifiedText(
          candidate?.description,
          detRec.description
        ),
        observedBasis: detRec.observedBasis,
        whyItFits: pickVerifiedText(candidate?.whyItFits, detRec.whyItFits),
      };
    }
  );

  // Secondary lenses (commits, docs) validated per string
  const validatePerspective = (
    rawLens: any,
    detLens: { headline: string; paragraphs: string[] }
  ) => {
    if (
      !rawLens ||
      typeof rawLens.headline !== "string" ||
      !Array.isArray(rawLens.paragraphs)
    ) {
      return detLens;
    }
    const hCheck = validateAiClaimsAgainstEvidence(
      rawLens.headline,
      evidence,
      analysis
    );
    if (!hCheck.valid) return detLens;
    const validParas: string[] = [];
    for (const p of rawLens.paragraphs.slice(0, 3)) {
      const pStr = String(p).trim();
      if (!validateAiClaimsAgainstEvidence(pStr, evidence, analysis).valid) {
        return detLens;
      }
      validParas.push(pStr);
    }
    return validParas.length > 0
      ? { headline: rawLens.headline.trim(), paragraphs: validParas }
      : detLens;
  };

  const roast: RoastContent = {
    shortCardRoast: pickVerifiedText(
      obj.shortCardRoast,
      fallback.shortCardRoast
    ),
    lenses: {
      default: {
        headline: defaultHeadline,
        paragraphs: defaultParagraphs,
      },
      commits: validatePerspective(obj.lenses?.commits, fallback.lenses.commits),
      docs: validatePerspective(obj.lenses?.docs, fallback.lenses.docs),
    },
    receipts,
    strengths,
    redFlags,
    recommendations,
    generationSource: "ai-live",
    aiModelUsed: modelName,
  };

  return { roast, updatedPersonality };
}

/**
 * Main entry point for generating the AI-powered developer report sections.
 * - Requires a valid server-side AI provider key unless allowHeuristicFallback or isDemoFixture is set.
 * - Enforces explicit request & response-body timeouts and strict post-generation evidence integrity checks.
 */
export async function generateAiRoastAnalysis(
  user: GitHubUser,
  analysis: GitHubAnalysisMetrics,
  scores: DeveloperScores,
  personality: DeveloperPersonality,
  evidence: StructuredGitHubEvidence,
  options: AiGeneratorOptions = {}
): Promise<{ roast: RoastContent; personality: DeveloperPersonality }> {
  const env = options.env || process.env;
  const fetchImpl = options.fetchFn || globalThis.fetch;

  const envTimeout = Number(env.AI_REQUEST_TIMEOUT_MS);
  const timeoutMs =
    options.timeoutMs ??
    (Number.isFinite(envTimeout) && envTimeout > 0
      ? envTimeout
      : DEFAULT_AI_TIMEOUT_MS);

  const fallbackSource = options.isDemoFixture
    ? "demo-fixture"
    : "heuristic-fallback";
  const deterministicBaseline = buildDeterministicGroundedRoast(
    user,
    analysis,
    scores,
    personality,
    fallbackSource
  );

  const providerConfig = resolveAiProviderConfig(env);

  if (!providerConfig) {
    const allowFallback =
      options.isDemoFixture ||
      options.allowHeuristicFallback ||
      env.ALLOW_HEURISTIC_FALLBACK?.toLowerCase() === "true";

    if (allowFallback) {
      return {
        roast: deterministicBaseline,
        personality,
      };
    }

    const requestedProvider = env.AI_PROVIDER?.trim().toLowerCase() || "gemini";
    const providerKeyMap: Record<string, string> = {
      gemini: "GEMINI_API_KEY (free-first default, model gemini-3.5-flash-lite)",
      openai: "OPENAI_API_KEY (explicit paid provider, model gpt-5.4-mini)",
      anthropic: "ANTHROPIC_API_KEY (explicit paid provider, model claude-haiku-5-5)",
    };
    const requiredKeyDesc =
      providerKeyMap[requestedProvider] ||
      `valid AI_PROVIDER ("gemini", "openai", or "anthropic") and corresponding API key`;

    throw new AiRoastError(
      `AI provider (${requestedProvider}) is not configured on the server: missing ${requiredKeyDesc}. Paid providers (openai, anthropic) are never selected automatically unless AI_PROVIDER is explicitly set.`,
      503,
      "MISSING_AI_API_KEY",
      "Set AI_PROVIDER=gemini and GEMINI_API_KEY (free tier via Google AI Studio, model gemini-3.5-flash-lite) in .env.local. To use a paid provider, you must explicitly set AI_PROVIDER=openai with OPENAI_API_KEY (gpt-5.4-mini) or AI_PROVIDER=anthropic with ANTHROPIC_API_KEY (claude-haiku-5-5)."
    );
  }

  const rawAiResponse = await callProviderApi(
    providerConfig,
    evidence,
    timeoutMs,
    fetchImpl
  );

  const { roast, updatedPersonality } = validateAndMergeAiOutput(
    rawAiResponse,
    personality,
    deterministicBaseline,
    `${providerConfig.provider}:${providerConfig.model}`,
    evidence,
    analysis
  );

  return {
    roast,
    personality: updatedPersonality,
  };
}
