import {
  ApiErrorCode,
  GitHubRepo,
  GitHubUser,
  PaginationMeta,
  RateLimitMeta,
  TruncationReason,
} from "@/types/roast";

const GITHUB_API_BASE = "https://api.github.com";
const CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes server-side TTL cache
const DEFAULT_PER_PAGE = 100;
const DEFAULT_MAX_PAGES = 5; // Up to 500 repositories by default
const DEFAULT_TIME_BUDGET_MS = 8000;
const DEFAULT_REQUEST_TIMEOUT_MS = 5000; // 5s explicit timeout covering headers + body
const MIN_SAFE_RATE_LIMIT_REMAINING = 2;

interface CacheEntry {
  timestamp: number;
  user: GitHubUser;
  repos: GitHubRepo[];
  pagination: PaginationMeta;
  rateLimit: Omit<RateLimitMeta, "cached" | "sourceLabel">;
}

const memoryCache = new Map<string, CacheEntry>();

export class GitHubApiError extends Error {
  public status: number;
  public code: ApiErrorCode;
  public resetAt: string | null;

  constructor(
    message: string,
    status: number,
    code: ApiErrorCode,
    resetAt: string | null = null
  ) {
    super(message);
    this.name = "GitHubApiError";
    this.status = status;
    this.code = code;
    this.resetAt = resetAt;
  }
}

export function clearGitHubCache(): void {
  memoryCache.clear();
}

export function isAbortOrTimeoutError(err: unknown): boolean {
  if (!err || typeof err !== "object") return false;
  const name = (err as { name?: string }).name || "";
  const message = (err as { message?: string }).message || "";
  return (
    name === "AbortError" ||
    name === "TimeoutError" ||
    message.toLowerCase().includes("aborted") ||
    message.toLowerCase().includes("timed out")
  );
}

function createTimeoutError(timeoutMs: number, phase: string): Error {
  const err = new Error(
    `Upstream request timed out after ${timeoutMs}ms (${phase})`
  );
  err.name = "TimeoutError";
  return err;
}

/**
 * Executes an upstream fetch request where the timeout budget covers BOTH
 * receiving response headers AND consuming/parsing the response body (`.json()` / `.text()`).
 */
export async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs: number,
  fetchImpl: typeof fetch
): Promise<Response> {
  const startMs = Date.now();
  const deadlineMs = startMs + timeoutMs;
  const controller = new AbortController();

  let headerTimer: ReturnType<typeof setTimeout> | null = null;
  const headerTimeoutPromise = new Promise<never>((_resolve, reject) => {
    headerTimer = setTimeout(() => {
      controller.abort();
      reject(createTimeoutError(timeoutMs, "awaiting response headers"));
    }, timeoutMs);
  });

  let rawRes: Response;
  try {
    rawRes = await Promise.race([
      fetchImpl(url, {
        ...init,
        signal: controller.signal,
      }),
      headerTimeoutPromise,
    ]);
  } catch (err) {
    if (isAbortOrTimeoutError(err)) {
      throw createTimeoutError(timeoutMs, "awaiting response headers");
    }
    throw err;
  } finally {
    if (headerTimer !== null) {
      clearTimeout(headerTimer);
    }
  }

  const origJson = rawRes.json.bind(rawRes);
  const origText = rawRes.text.bind(rawRes);

  const runBodyWithRemainingTimeout = async <T>(
    reader: () => Promise<T>
  ): Promise<T> => {
    const remainingMs = Math.max(1, deadlineMs - Date.now());
    let bodyTimer: ReturnType<typeof setTimeout> | null = null;

    const bodyTimeoutPromise = new Promise<never>((_resolve, reject) => {
      bodyTimer = setTimeout(() => {
        controller.abort();
        reject(createTimeoutError(timeoutMs, "reading response body"));
      }, remainingMs);
    });

    try {
      return await Promise.race([reader(), bodyTimeoutPromise]);
    } catch (err) {
      if (isAbortOrTimeoutError(err)) {
        throw createTimeoutError(timeoutMs, "reading response body");
      }
      throw err;
    } finally {
      if (bodyTimer !== null) {
        clearTimeout(bodyTimer);
      }
    }
  };

  // Override .json() and .text() on the Response instance so body consumption is bounded
  Object.defineProperty(rawRes, "json", {
    value: () =>
      runBodyWithRemainingTimeout(async () => {
        const text = await origText();
        return JSON.parse(text);
      }),
    configurable: true,
    writable: true,
  });

  Object.defineProperty(rawRes, "text", {
    value: () => runBodyWithRemainingTimeout(() => origText()),
    configurable: true,
    writable: true,
  });

  return rawRes;
}

/**
 * Sanitizes and validates a GitHub username or profile URL input.
 * GitHub usernames may only contain alphanumeric characters or single hyphens,
 * cannot begin or end with a hyphen, and must be 1-39 characters long.
 */
export function sanitizeAndValidateUsername(rawInput: string): {
  valid: boolean;
  username: string;
  error?: string;
} {
  if (!rawInput || typeof rawInput !== "string") {
    return {
      valid: false,
      username: "",
      error: "Please enter a GitHub username.",
    };
  }

  let cleaned = rawInput.trim();
  cleaned = cleaned.replace(/^https?:\/\/(www\.)?github\.com\//i, "");
  cleaned = cleaned.replace(/^@/, "");
  cleaned = cleaned.split("/")[0].split("?")[0].split("#")[0].trim();

  if (!cleaned) {
    return {
      valid: false,
      username: "",
      error: "Please enter a valid GitHub username.",
    };
  }

  if (cleaned.length > 39) {
    return {
      valid: false,
      username: cleaned,
      error: "GitHub usernames cannot exceed 39 characters.",
    };
  }

  const githubUsernameRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9]|-(?=[a-zA-Z0-9])){0,38}$/;
  if (!githubUsernameRegex.test(cleaned)) {
    return {
      valid: false,
      username: cleaned,
      error:
        "Invalid GitHub username format. Use only letters, numbers, and single hyphens (cannot start or end with a hyphen).",
    };
  }

  return { valid: true, username: cleaned };
}

function buildHeaders(customToken?: string): Record<string, string> {
  const headers: Record<string, string> = {
    Accept: "application/vnd.github+json",
    "User-Agent": "AI-Roast-My-GitHub/2.0",
    "X-GitHub-Api-Version": "2022-11-28",
  };

  const token = customToken || process.env.GITHUB_TOKEN;
  if (token && token.trim().length > 0) {
    headers.Authorization = `Bearer ${token.trim()}`;
  }

  return headers;
}

function extractRateLimit(res: Response): {
  limit: number;
  remaining: number;
  resetAt: string | null;
} {
  const limitHeader = res.headers?.get?.("x-ratelimit-limit");
  const remainingHeader = res.headers?.get?.("x-ratelimit-remaining");
  const resetHeader = res.headers?.get?.("x-ratelimit-reset");

  const limit =
    limitHeader !== null && limitHeader !== undefined ? Number(limitHeader) : 60;
  const remaining =
    remainingHeader !== null && remainingHeader !== undefined
      ? Number(remainingHeader)
      : 60;
  const resetAt =
    resetHeader && !Number.isNaN(Number(resetHeader))
      ? new Date(Number(resetHeader) * 1000).toISOString()
      : null;

  return {
    limit: Number.isFinite(limit) ? limit : 60,
    remaining: Number.isFinite(remaining) ? remaining : 60,
    resetAt,
  };
}

export interface FetchGitHubOptions {
  maxPages?: number;
  perPage?: number;
  timeBudgetMs?: number;
  requestTimeoutMs?: number;
  bypassCache?: boolean;
  githubToken?: string;
  fetchFn?: typeof fetch;
  nowFn?: () => number;
}

export function buildCoverageNotice(
  totalPublicRepos: number,
  fetchedRepoCount: number,
  pagesFetched: number,
  isComplete: boolean,
  truncationReason: TruncationReason
): string {
  if (totalPublicRepos === 0 || fetchedRepoCount === 0) {
    return "Profile has 0 public repositories.";
  }

  if (isComplete) {
    return `Complete profile analysis: inspected all ${fetchedRepoCount} public repositories across ${pagesFetched} page(s).`;
  }

  const pct = Math.round((fetchedRepoCount / Math.max(1, totalPublicRepos)) * 100);
  const reasonMap: Record<Exclude<TruncationReason, null>, string> = {
    MAX_PAGES_REACHED: `pagination cap of ${pagesFetched} page(s) (${fetchedRepoCount} repos) reached to keep response times fast`,
    RATE_LIMIT_LOW: `paused after ${pagesFetched} page(s) to preserve remaining GitHub API rate-limit quota`,
    TIME_BUDGET_REACHED: `paused after ${pagesFetched} page(s) to stay within the request execution-time budget`,
    PARTIAL_PAGE_ERROR: `subsequent repository page request returned an upstream error after ${pagesFetched} page(s)`,
  };

  const explanation = truncationReason
    ? reasonMap[truncationReason]
    : `stopped after ${pagesFetched} page(s)`;

  return `Partial profile coverage (${pct}%): analyzed the ${fetchedRepoCount} most recently updated repositories out of ${totalPublicRepos} total public repositories (${explanation}). All metrics reflect this analyzed subset.`;
}

/**
 * Fetches a user's public GitHub profile and paginates through their public repositories.
 * Enforces explicit timeouts across both headers and body consumption via fetchWithTimeout,
 * and never silently replaces failed live requests with hardcoded snapshots.
 */
export async function fetchGitHubProfileAndRepos(
  rawUsername: string,
  options: FetchGitHubOptions = {}
): Promise<{
  user: GitHubUser;
  repos: GitHubRepo[];
  pagination: PaginationMeta;
  rateLimit: RateLimitMeta;
}> {
  const validation = sanitizeAndValidateUsername(rawUsername);
  if (!validation.valid) {
    throw new GitHubApiError(
      validation.error || "Invalid GitHub username.",
      400,
      "INVALID_USERNAME"
    );
  }

  const fetchImpl = options.fetchFn || globalThis.fetch;
  const now = options.nowFn || Date.now;
  const perPage = options.perPage || DEFAULT_PER_PAGE;
  const envMaxPages = Number(process.env.GITHUB_MAX_PAGES);
  const maxPages =
    options.maxPages ??
    (Number.isFinite(envMaxPages) && envMaxPages > 0
      ? envMaxPages
      : DEFAULT_MAX_PAGES);
  const timeBudgetMs = options.timeBudgetMs ?? DEFAULT_TIME_BUDGET_MS;

  const envReqTimeout = Number(process.env.GITHUB_REQUEST_TIMEOUT_MS);
  const requestTimeoutMs =
    options.requestTimeoutMs ??
    (Number.isFinite(envReqTimeout) && envReqTimeout > 0
      ? envReqTimeout
      : DEFAULT_REQUEST_TIMEOUT_MS);

  const cacheKey = `${validation.username.toLowerCase()}:p${maxPages}:n${perPage}`;
  const startTime = now();

  if (!options.bypassCache) {
    const cachedEntry = memoryCache.get(cacheKey);
    if (cachedEntry && startTime - cachedEntry.timestamp < CACHE_TTL_MS) {
      return {
        user: cachedEntry.user,
        repos: cachedEntry.repos,
        pagination: cachedEntry.pagination,
        rateLimit: {
          ...cachedEntry.rateLimit,
          cached: true,
          sourceLabel: "Cached GitHub API (10m TTL)",
        },
      };
    }
  }

  const headers = buildHeaders(options.githubToken);

  let userRes: Response;
  try {
    userRes = await fetchWithTimeout(
      `${GITHUB_API_BASE}/users/${encodeURIComponent(validation.username)}`,
      { headers },
      requestTimeoutMs,
      fetchImpl
    );
  } catch (err) {
    if (isAbortOrTimeoutError(err)) {
      throw new GitHubApiError(
        `GitHub API request timed out after ${requestTimeoutMs}ms while fetching profile "@${validation.username}".`,
        504,
        "UPSTREAM_TIMEOUT"
      );
    }
    throw new GitHubApiError(
      `Network error while connecting to GitHub API: ${
        err instanceof Error ? err.message : "connection failed"
      }.`,
      502,
      "NETWORK_ERROR"
    );
  }

  const userRateLimit = extractRateLimit(userRes);

  if (userRes.status === 404) {
    throw new GitHubApiError(
      `GitHub user "@${validation.username}" was not found. Verify the spelling and ensure the profile is public.`,
      404,
      "USER_NOT_FOUND"
    );
  }

  if (userRes.status === 403 || userRes.status === 429) {
    const resetText = userRateLimit.resetAt
      ? ` Rate limit resets at ${new Date(userRateLimit.resetAt).toISOString()}.`
      : "";
    throw new GitHubApiError(
      `GitHub API rate limit exceeded (${userRateLimit.remaining}/${userRateLimit.limit} remaining).${resetText} Configure GITHUB_TOKEN on the server for 5,000 requests/hour.`,
      429,
      "RATE_LIMITED",
      userRateLimit.resetAt
    );
  }

  if (!userRes.ok) {
    throw new GitHubApiError(
      `GitHub API returned HTTP ${userRes.status} while fetching profile "@${validation.username}".`,
      502,
      "UPSTREAM_GITHUB_ERROR"
    );
  }

  let rawUser: unknown;
  try {
    rawUser = await userRes.json();
  } catch (err) {
    if (isAbortOrTimeoutError(err)) {
      throw new GitHubApiError(
        `GitHub API response body timed out after ${requestTimeoutMs}ms while reading profile "@${validation.username}".`,
        504,
        "UPSTREAM_TIMEOUT"
      );
    }
    throw new GitHubApiError(
      "Received malformed JSON from GitHub profile endpoint.",
      502,
      "UPSTREAM_GITHUB_ERROR"
    );
  }

  if (!rawUser || typeof rawUser !== "object" || !("login" in rawUser)) {
    throw new GitHubApiError(
      "Received incomplete profile payload from GitHub API.",
      502,
      "UPSTREAM_GITHUB_ERROR"
    );
  }

  const user = rawUser as GitHubUser;
  const totalPublicRepos = Math.max(0, Number(user.public_repos) || 0);
  const totalPagesNeeded = Math.max(1, Math.ceil(totalPublicRepos / perPage));

  const repos: GitHubRepo[] = [];
  let pagesFetched = 0;
  let truncationReason: TruncationReason = null;
  let latestRateLimit = userRateLimit;

  if (totalPublicRepos > 0) {
    for (let page = 1; page <= totalPagesNeeded; page++) {
      if (page > maxPages) {
        truncationReason = "MAX_PAGES_REACHED";
        break;
      }

      if (page > 1 && latestRateLimit.remaining <= MIN_SAFE_RATE_LIMIT_REMAINING) {
        truncationReason = "RATE_LIMIT_LOW";
        break;
      }

      if (page > 1 && now() - startTime >= timeBudgetMs) {
        truncationReason = "TIME_BUDGET_REACHED";
        break;
      }

      let reposRes: Response;
      try {
        reposRes = await fetchWithTimeout(
          `${GITHUB_API_BASE}/users/${encodeURIComponent(
            validation.username
          )}/repos?per_page=${perPage}&sort=updated&direction=desc&page=${page}`,
          { headers },
          requestTimeoutMs,
          fetchImpl
        );
      } catch (err) {
        if (pagesFetched === 0) {
          if (isAbortOrTimeoutError(err)) {
            throw new GitHubApiError(
              `GitHub API request timed out after ${requestTimeoutMs}ms while fetching repositories for "@${validation.username}".`,
              504,
              "UPSTREAM_TIMEOUT"
            );
          }
          throw new GitHubApiError(
            `Network error while fetching repositories for "@${validation.username}": ${
              err instanceof Error ? err.message : "connection failed"
            }.`,
            502,
            "NETWORK_ERROR"
          );
        }
        truncationReason = isAbortOrTimeoutError(err)
          ? "TIME_BUDGET_REACHED"
          : "PARTIAL_PAGE_ERROR";
        break;
      }

      latestRateLimit = extractRateLimit(reposRes);

      if (reposRes.status === 403 || reposRes.status === 429) {
        if (pagesFetched === 0) {
          throw new GitHubApiError(
            "GitHub API rate limit reached while fetching repositories.",
            429,
            "RATE_LIMITED",
            latestRateLimit.resetAt
          );
        }
        truncationReason = "RATE_LIMIT_LOW";
        break;
      }

      if (!reposRes.ok) {
        if (pagesFetched === 0) {
          throw new GitHubApiError(
            `GitHub API returned HTTP ${reposRes.status} while fetching repositories.`,
            502,
            "UPSTREAM_GITHUB_ERROR"
          );
        }
        truncationReason = "PARTIAL_PAGE_ERROR";
        break;
      }

      let pageData: unknown;
      try {
        pageData = await reposRes.json();
      } catch (err) {
        if (pagesFetched === 0) {
          if (isAbortOrTimeoutError(err)) {
            throw new GitHubApiError(
              `GitHub API response body timed out after ${requestTimeoutMs}ms while reading repositories for "@${validation.username}".`,
              504,
              "UPSTREAM_TIMEOUT"
            );
          }
          throw new GitHubApiError(
            "Malformed JSON returned from GitHub repositories endpoint.",
            502,
            "UPSTREAM_GITHUB_ERROR"
          );
        }
        truncationReason = isAbortOrTimeoutError(err)
          ? "TIME_BUDGET_REACHED"
          : "PARTIAL_PAGE_ERROR";
        break;
      }

      if (!Array.isArray(pageData)) {
        break;
      }

      repos.push(...(pageData as GitHubRepo[]));
      pagesFetched++;

      if (pageData.length < perPage) {
        break;
      }
    }
  }

  const fetchedRepoCount = repos.length;
  const effectiveTotal = Math.max(totalPublicRepos, fetchedRepoCount);
  const isComplete =
    truncationReason === null && fetchedRepoCount >= totalPublicRepos;
  const coveragePercentage =
    effectiveTotal === 0
      ? 100
      : Math.min(100, Math.round((fetchedRepoCount / effectiveTotal) * 100));

  const pagination: PaginationMeta = {
    totalPublicRepos: effectiveTotal,
    fetchedRepoCount,
    coveragePercentage,
    pagesFetched,
    maxPagesAllowed: maxPages,
    isComplete,
    truncationReason,
    coverageNotice: buildCoverageNotice(
      effectiveTotal,
      fetchedRepoCount,
      pagesFetched,
      isComplete,
      truncationReason
    ),
  };

  memoryCache.set(cacheKey, {
    timestamp: now(),
    user,
    repos,
    pagination,
    rateLimit: latestRateLimit,
  });

  return {
    user,
    repos,
    pagination,
    rateLimit: {
      ...latestRateLimit,
      cached: false,
      sourceLabel: isComplete
        ? "Live GitHub REST API"
        : `Live GitHub API (${coveragePercentage}% Sampled)`,
    },
  };
}
