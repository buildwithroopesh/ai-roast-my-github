export type ApiErrorCode =
  | "INVALID_USERNAME"
  | "USER_NOT_FOUND"
  | "RATE_LIMITED"
  | "CLIENT_RATE_LIMITED"
  | "RATE_LIMIT_BACKEND_UNAVAILABLE"
  | "NETWORK_ERROR"
  | "UPSTREAM_TIMEOUT"
  | "UPSTREAM_GITHUB_ERROR"
  | "MISSING_AI_API_KEY"
  | "AI_PROVIDER_TIMEOUT"
  | "AI_PROVIDER_ERROR"
  | "AI_EVIDENCE_VIOLATION"
  | "INTERNAL_ERROR";

export interface GitHubUser {
  login: string;
  id: number;
  avatar_url: string;
  html_url: string;
  name: string | null;
  company: string | null;
  blog: string | null;
  location: string | null;
  bio: string | null;
  twitter_username?: string | null;
  public_repos: number;
  public_gists: number;
  followers: number;
  following: number;
  created_at: string;
  updated_at: string;
  type: "User" | "Organization" | string;
}

export interface GitHubRepo {
  id?: number;
  name: string;
  full_name?: string;
  html_url: string;
  description: string | null;
  fork: boolean;
  created_at: string;
  updated_at: string;
  pushed_at: string | null;
  homepage: string | null;
  size: number; // in KB
  stargazers_count: number;
  watchers_count?: number;
  language: string | null;
  has_issues?: boolean;
  has_projects?: boolean;
  has_downloads?: boolean;
  has_wiki?: boolean;
  has_pages?: boolean;
  forks_count: number;
  archived?: boolean;
  disabled?: boolean;
  open_issues_count?: number;
  license: {
    key?: string;
    name: string;
    spdx_id?: string;
  } | null;
  topics?: string[];
  default_branch?: string;
}

export type TruncationReason =
  | null
  | "MAX_PAGES_REACHED"
  | "RATE_LIMIT_LOW"
  | "TIME_BUDGET_REACHED"
  | "PARTIAL_PAGE_ERROR";

export interface PaginationMeta {
  totalPublicRepos: number;
  fetchedRepoCount: number;
  coveragePercentage: number;
  pagesFetched: number;
  maxPagesAllowed: number;
  isComplete: boolean;
  truncationReason: TruncationReason;
  coverageNotice: string;
}

export interface RateLimitMeta {
  limit: number;
  remaining: number;
  resetAt: string | null;
  cached: boolean;
  sourceLabel: string;
}

export interface ScoreBreakdownItem {
  key:
    | "quality"
    | "consistency"
    | "documentation"
    | "ambition"
    | "activity"
    | "overall";
  label: string;
  score: number; // 0-10 (one decimal place)
  observedFact: string;
  methodologyNote: string;
}

export interface DeveloperScores {
  quality: number;
  consistency: number;
  documentation: number;
  ambition: number;
  activity: number;
  overall: number;
  breakdown: ScoreBreakdownItem[];
  disclaimer: string;
}

export interface DeveloperPersonality {
  id: string;
  title: string;
  tagline: string;
  observedSignal: string;
  interpretation: string;
  badgeColor: string;
}

export interface LanguageStat {
  language: string;
  repoCount: number;
  percentage: number;
  stars: number;
  sizeKb: number;
  color: string;
}

export interface RepoSummary {
  name: string;
  htmlUrl: string;
  description: string | null;
  language: string | null;
  stars: number;
  forks: number;
  isFork: boolean;
  isArchived: boolean;
  sizeKb: number;
  createdAt: string;
  pushedAt: string;
  daysSinceLastPush: number;
  activeLifespanDays: number;
  initialCommitOnly: boolean;
  isStableInactive: boolean;
  topics: string[];
  hasHomepage: boolean;
  hasLicense: boolean;
  hasPagesOrWiki: boolean;
}

export interface GitHubAnalysisMetrics {
  publicRepoCount: number;
  analyzedRepoCount: number;
  originalRepoCount: number;
  forkRepoCount: number;
  originalPercentage: number;
  totalStars: number;
  originalStars: number;
  totalForks: number;
  accountAgeYears: number;
  reposPerYear: number;
  daysSinceLastActive: number;
  activeLast30Days: number;
  activeLast90Days: number;
  activeLast365Days: number;
  inactiveOver1YearCount: number;
  stableCompletedCount: number;
  initialCommitOnlyCount: number;
  substantiveOriginalCount: number;
  missingDescriptionCount: number;
  missingDescriptionPercent: number;
  reposWithTopicsCount: number;
  reposWithHomepageCount: number;
  reposWithLicenseCount: number;
  reposWithDocsSignalCount: number;
  topLanguage: string;
  languageSpecialization:
    | "Polyglot"
    | "Focused Specialist"
    | "Dual-Stack"
    | "Unclassified";
  languages: LanguageStat[];
  mostActiveRepos: RepoSummary[];
  recentlyUpdatedRepos: RepoSummary[];
  allRepos: RepoSummary[];
  pagination: PaginationMeta;
}

export interface FactInterpretationReceipt {
  observedFact: string;
  interpretation: string;
}

export interface EvidencePoint {
  title: string;
  observedFact: string;
  interpretation: string;
  metricBadge: string;
}

export interface ProjectRecommendation {
  title: string;
  stack: string[];
  difficulty: "Weekend Build" | "Intermediate" | "Ambitious";
  description: string;
  observedBasis: string;
  whyItFits: string;
}

export interface RoastPerspective {
  headline: string;
  paragraphs: string[];
}

export interface RoastContent {
  shortCardRoast: string;
  lenses: {
    default: RoastPerspective;
    commits: RoastPerspective;
    docs: RoastPerspective;
  };
  receipts: FactInterpretationReceipt[];
  strengths: EvidencePoint[];
  redFlags: EvidencePoint[];
  recommendations: ProjectRecommendation[];
  generationSource: "ai-live" | "heuristic-fallback" | "demo-fixture";
  aiModelUsed: string;
}

export interface StructuredGitHubEvidence {
  username: string;
  displayName: string;
  accountType: string;
  accountAgeYears: number;
  bio: string | null;
  followers: number;
  following: number;
  pagination: PaginationMeta;
  counts: {
    totalPublicRepos: number;
    analyzedRepos: number;
    originalRepos: number;
    forkedRepos: number;
    originalPercentage: number;
    totalStars: number;
    originalStars: number;
    totalForks: number;
  };
  activity: {
    daysSinceLastPush: number;
    activeLast30Days: number;
    activeLast90Days: number;
    activeLast365Days: number;
    inactiveOver1YearCount: number;
    stableCompletedCount: number;
    initialCommitOnlyCount: number;
    substantiveOriginalCount: number;
  };
  metadataHygiene: {
    missingDescriptionCount: number;
    missingDescriptionPercent: number;
    reposWithTopicsCount: number;
    reposWithHomepageCount: number;
    reposWithLicenseCount: number;
    reposWithDocsSignalCount: number;
    note: string;
  };
  languages: {
    topLanguage: string;
    specializationPattern: string;
    breakdown: Array<{
      language: string;
      repoCount: number;
      percentage: number;
      stars: number;
      sizeKb: number;
    }>;
  };
  scores: {
    overall: number;
    quality: number;
    consistency: number;
    documentation: number;
    ambition: number;
    activity: number;
  };
  deterministicPersonality: {
    id: string;
    title: string;
    observedSignal: string;
  };
  notableRepositories: Array<{
    name: string;
    isFork: boolean;
    language: string | null;
    stars: number;
    forks: number;
    sizeKb: number;
    daysSinceLastPush: number;
    activeLifespanDays: number;
    initialCommitOnly: boolean;
    description: string | null;
    topics: string[];
    hasHomepage: boolean;
    hasLicense: boolean;
  }>;
}

export interface RoastReport {
  generatedAt: string;
  profile: {
    username: string;
    name: string;
    avatarUrl: string;
    htmlUrl: string;
    bio: string | null;
    location: string | null;
    company: string | null;
    blog: string | null;
    followers: number;
    following: number;
    publicRepos: number;
    publicGists: number;
    createdAt: string;
    accountType: string;
  };
  scores: DeveloperScores;
  personality: DeveloperPersonality;
  analysis: GitHubAnalysisMetrics;
  roast: RoastContent;
  rateLimit: RateLimitMeta;
}
