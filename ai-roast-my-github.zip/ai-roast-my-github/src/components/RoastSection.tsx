"use client";

import React, { useState } from "react";
import { RoastContent } from "@/types/roast";

interface RoastSectionProps {
  roast: RoastContent;
}

export function RoastSection({ roast }: RoastSectionProps) {
  const [activeLens, setActiveLens] = useState<"default" | "commits" | "docs">(
    "default"
  );

  const currentPerspective = roast.lenses[activeLens] || roast.lenses.default;

  const sourceLabelMap: Record<RoastContent["generationSource"], string> = {
    "ai-live": `Live AI (${roast.aiModelUsed})`,
    "heuristic-fallback": "Deterministic Evidence Engine",
    "demo-fixture": "Demo Fixture Engine",
  };

  return (
    <section className="rounded-2xl border border-orange-500/35 bg-gradient-to-b from-zinc-900/95 to-zinc-950 p-6 sm:p-8 shadow-2xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800/80 pb-4">
        <div className="flex items-center gap-2.5">
          <span
            className="flex h-7 w-7 items-center justify-center rounded-lg bg-orange-500/20 text-orange-400 text-sm"
            aria-hidden="true"
          >
            🔥
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white uppercase tracking-wider font-mono">
                AI Roast Assessment
              </h3>
              <span className="rounded bg-zinc-800 px-2 py-0.5 font-mono text-[10px] text-zinc-300">
                {sourceLabelMap[roast.generationSource]}
              </span>
            </div>
            <p className="text-xs text-zinc-400">
              Separates verified GitHub API facts from humorous interpretations
            </p>
          </div>
        </div>

        {/* Roast Angle Switcher */}
        <div
          className="flex flex-wrap items-center gap-1.5"
          role="tablist"
          aria-label="Roast perspective switcher"
        >
          {(
            [
              { id: "default", label: "Full Roast" },
              { id: "commits", label: "Commit Lifecycle" },
              { id: "docs", label: "Metadata & Clout" },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={activeLens === tab.id}
              onClick={() => setActiveLens(tab.id)}
              className={`rounded-lg px-3 py-1.5 text-xs font-mono transition ${
                activeLens === tab.id
                  ? "bg-orange-500 font-bold text-zinc-950"
                  : "border border-zinc-800 bg-zinc-900 text-zinc-300 hover:text-white"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <blockquote className="border-l-4 border-orange-500 pl-4 sm:pl-6 text-lg sm:text-2xl font-bold text-white leading-snug">
        &ldquo;{currentPerspective.headline}&rdquo;
      </blockquote>

      <div className="space-y-4 text-sm sm:text-base text-zinc-300 leading-relaxed">
        {currentPerspective.paragraphs.map((p, idx) => (
          <p key={idx}>{p}</p>
        ))}
      </div>

      <div className="pt-2">
        <div className="text-xs font-mono uppercase tracking-wider text-zinc-400 mb-3">
          Observed Facts vs. AI Interpretations
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {roast.receipts.map((item, idx) => (
            <div
              key={idx}
              className="rounded-xl border border-zinc-800/90 bg-zinc-950/80 p-3.5 space-y-1.5 text-xs"
            >
              <div className="font-mono text-zinc-200 flex items-start gap-2">
                <span className="text-orange-400 font-bold shrink-0">FACT:</span>
                <span>{item.observedFact}</span>
              </div>
              <div className="text-zinc-400 pl-11">
                <strong className="text-zinc-300 font-mono text-[11px]">
                  TAKE:
                </strong>{" "}
                {item.interpretation}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
