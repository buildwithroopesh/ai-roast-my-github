"use client";

import React from "react";

interface ArchitectureModalProps {
  open: boolean;
  onClose: () => void;
}

export function ArchitectureModal({ open, onClose }: ArchitectureModalProps) {
  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
    >
      <div className="w-full max-w-2xl rounded-2xl border border-zinc-800 bg-zinc-950 p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <h2 id="modal-title" className="text-base font-bold text-white font-mono">
            Server-Side AI, Pagination &amp; Scoring Methodology
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="rounded-lg p-1 text-zinc-400 hover:bg-zinc-900 hover:text-white"
          >
            ✕
          </button>
        </div>

        <div className="space-y-4 text-xs text-zinc-300 leading-relaxed">
          <div className="rounded-xl border border-zinc-800 bg-zinc-900/70 p-4 space-y-2">
            <div className="font-semibold text-white font-mono">
              1. Free-First Server-Side AI (<code className="text-orange-300">gemini-3.5-flash-lite</code>) &amp; Explicit Paid Providers
            </div>
            <p className="text-zinc-400">
              All AI and GitHub API keys are stored strictly on the server in{" "}
              <code className="text-orange-300 font-mono">src/app/api/roast/route.ts</code> and{" "}
              <code className="text-orange-300 font-mono">src/lib/ai-roast.ts</code>. The default configuration is{" "}
              <code className="text-zinc-200 font-mono">AI_PROVIDER=gemini</code> with{" "}
              <code className="text-zinc-200 font-mono">GEMINI_API_KEY</code> and default model{" "}
              <code className="text-orange-300 font-mono">gemini-3.5-flash-lite</code> (eligible for free-tier input/output tokens in Google AI Studio, subject to RPM/TPM/RPD rate limits and Unpaid Services data-use terms). Paid providers{" "}
              <code className="text-zinc-200 font-mono">OPENAI_API_KEY</code> (<code className="text-zinc-200 font-mono">gpt-5.4-mini</code>) and{" "}
              <code className="text-zinc-200 font-mono">ANTHROPIC_API_KEY</code> (<code className="text-zinc-200 font-mono">claude-haiku-5-5</code>) incur charges and are only used when{" "}
              <code className="text-zinc-200 font-mono">AI_PROVIDER=openai</code> or{" "}
              <code className="text-zinc-200 font-mono">AI_PROVIDER=anthropic</code> is explicitly configured.
            </p>
          </div>

          <div className="rounded-xl border border-zinc-800 bg-zinc-900/70 p-4 space-y-2">
            <div className="font-semibold text-white font-mono">
              2. Multi-Page Repository Pagination &amp; Completeness
            </div>
            <p className="text-zinc-400">
              Instead of stopping at 100 repositories,{" "}
              <code className="text-orange-300 font-mono">src/lib/github.ts</code> paginates across up to{" "}
              <code className="text-zinc-200 font-mono">GITHUB_MAX_PAGES</code> (default 500 repositories) while checking remaining rate-limit quota and execution time. When a profile has more repositories than the pagination cap, an explicit partial-coverage notice is displayed.
            </p>
          </div>

          <div className="rounded-xl border border-zinc-800 bg-zinc-900/70 p-4 space-y-2">
            <div className="font-semibold text-white font-mono">
              3. Trustworthy Heuristic Scoring Principles
            </div>
            <ul className="list-disc pl-5 space-y-1 text-zinc-400">
              <li>
                <strong className="text-zinc-200">Stars ≠ Code Quality:</strong>{" "}
                Code &amp; Project Structure evaluates codebase size, multi-day iteration, and licensing; stars are capped at ≤0.8 bonus points.
              </li>
              <li>
                <strong className="text-zinc-200">Fewer Repos ≠ Low Skill:</strong>{" "}
                Ambition evaluates per-repository depth and lifespan rather than sheer repository count.
              </li>
              <li>
                <strong className="text-zinc-200">Inactive ≠ Abandoned:</strong>{" "}
                Completed repositories that had multi-day development or substantive size are classified as Stable rather than penalized.
              </li>
              <li>
                <strong className="text-zinc-200">Single Language = Specialization:</strong>{" "}
                Focusing on one primary language is recognized as domain specialization, never a red flag.
              </li>
            </ul>
          </div>
        </div>

        <div className="flex items-center justify-end pt-2 border-t border-zinc-800">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg bg-orange-500 px-4 py-2 text-xs font-bold text-zinc-950 hover:bg-orange-400"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
