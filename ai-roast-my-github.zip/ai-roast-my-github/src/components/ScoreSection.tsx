"use client";

import React from "react";
import { DeveloperScores } from "@/types/roast";

interface ScoreSectionProps {
  scores: DeveloperScores;
}

export function ScoreSection({ scores }: ScoreSectionProps) {
  return (
    <section className="card-surface rounded-2xl p-6 sm:p-8 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-zinc-800/80 pb-4">
        <div>
          <h3 className="text-xl font-bold text-white">
            Developer Score (0–10 Heuristic)
          </h3>
          <p className="text-xs text-zinc-400 mt-1 max-w-3xl leading-relaxed">
            <strong className="text-amber-300 font-mono">
              Methodology Disclaimer:
            </strong>{" "}
            {scores.disclaimer}
          </p>
        </div>
        <div className="flex items-center gap-3 rounded-xl border border-zinc-800 bg-zinc-950 px-4 py-2.5 shrink-0">
          <span className="text-xs font-mono uppercase text-zinc-400">
            Overall Heuristic
          </span>
          <span className="font-mono text-2xl sm:text-3xl font-black text-orange-400">
            {scores.overall.toFixed(1)}/10
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {scores.breakdown.map((item) => {
          const pct = Math.min(100, Math.round(item.score * 10));
          const colorClass =
            item.score >= 7.5
              ? "from-emerald-500 to-teal-400"
              : item.score >= 5.0
              ? "from-orange-500 to-amber-400"
              : "from-rose-500 to-orange-500";

          return (
            <div
              key={item.key}
              className="rounded-xl border border-zinc-800/90 bg-zinc-950/70 p-4 flex flex-col justify-between gap-3"
            >
              <div className="space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-bold text-zinc-100">
                    {item.label}
                  </span>
                  <span className="font-mono text-lg font-extrabold text-orange-400">
                    {item.score.toFixed(1)}
                    <span className="text-xs text-zinc-500">/10</span>
                  </span>
                </div>
                <div className="h-2 w-full rounded-full bg-zinc-800 overflow-hidden">
                  <div
                    className={`h-full rounded-full bg-gradient-to-r ${colorClass}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <p className="text-[11px] font-mono text-zinc-300 leading-relaxed">
                  {item.observedFact}
                </p>
              </div>

              <p className="text-[11px] text-zinc-500 border-t border-zinc-800/70 pt-2 leading-snug">
                {item.methodologyNote}
              </p>
            </div>
          );
        })}
      </div>
    </section>
  );
}
