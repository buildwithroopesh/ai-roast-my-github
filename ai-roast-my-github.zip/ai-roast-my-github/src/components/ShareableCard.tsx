/* eslint-disable @next/next/no-img-element */
"use client";

import React, { useState } from "react";
import { RoastReport } from "@/types/roast";

interface ShareableCardProps {
  report: RoastReport;
  onToast: (msg: string) => void;
}

export function ShareableCard({ report, onToast }: ShareableCardProps) {
  const { profile, scores, personality, analysis, roast } = report;
  const [downloading, setDownloading] = useState(false);

  const handleDownloadPng = () => {
    setDownloading(true);
    try {
      const canvas = document.createElement("canvas");
      canvas.width = 1200;
      canvas.height = 630;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      const bg = ctx.createLinearGradient(0, 0, 1200, 630);
      bg.addColorStop(0, "#09090b");
      bg.addColorStop(0.55, "#121218");
      bg.addColorStop(1, "#23120b");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, 1200, 630);

      ctx.strokeStyle = "rgba(249, 115, 22, 0.45)";
      ctx.lineWidth = 4;
      ctx.strokeRect(28, 28, 1144, 574);

      ctx.fillStyle = "#f97316";
      ctx.font = 'bold 22px "JetBrains Mono", monospace';
      ctx.fillText(
        "🔥 AI ROAST MY GITHUB — DEVELOPER REALITY CHECK",
        68,
        88
      );

      ctx.fillStyle = "#ffffff";
      ctx.font = "800 56px Inter, sans-serif";
      ctx.fillText(`@${profile.username}`, 68, 168);

      ctx.fillStyle = "#fb923c";
      ctx.font = "bold 30px Inter, sans-serif";
      ctx.fillText(personality.title, 68, 216);

      ctx.fillStyle = "#18181b";
      ctx.fillRect(900, 68, 230, 150);
      ctx.strokeStyle = "#f97316";
      ctx.lineWidth = 2;
      ctx.strokeRect(900, 68, 230, 150);

      ctx.fillStyle = "#a1a1aa";
      ctx.font = 'bold 16px "JetBrains Mono", monospace';
      ctx.fillText("HEURISTIC SCORE", 936, 108);

      ctx.fillStyle = "#f97316";
      ctx.font = 'bold 60px "JetBrains Mono", monospace';
      ctx.fillText(`${scores.overall.toFixed(1)}/10`, 922, 178);

      ctx.fillStyle = "#e4e4e7";
      ctx.font = "italic 29px Inter, sans-serif";
      const words = `"${roast.shortCardRoast}"`.split(" ");
      let line = "";
      let y = 305;
      for (const word of words) {
        const test = line + word + " ";
        if (ctx.measureText(test).width > 1040) {
          ctx.fillText(line.trim(), 68, y);
          line = word + " ";
          y += 44;
        } else {
          line = test;
        }
      }
      if (line.trim()) {
        ctx.fillText(line.trim(), 68, y);
      }

      ctx.fillStyle = "#27272a";
      ctx.fillRect(68, 495, 1064, 2);

      ctx.fillStyle = "#f4f4f5";
      ctx.font = 'bold 22px "JetBrains Mono", monospace';
      ctx.fillText(
        `TOP LANG: ${analysis.topLanguage}   •   ANALYZED: ${analysis.analyzedRepoCount}/${analysis.publicRepoCount} REPOS   •   STARS: ${analysis.totalStars.toLocaleString()}   •   ORIGINAL: ${analysis.originalPercentage}%`,
        68,
        548
      );

      const dataUrl = canvas.toDataURL("image/png");
      const a = document.createElement("a");
      a.href = dataUrl;
      a.download = `ai-roast-${profile.username}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      onToast(`Downloaded ai-roast-${profile.username}.png`);
    } finally {
      setDownloading(false);
    }
  };

  const handleCopyShareText = async () => {
    const text = [
      `🔥 AI Roast My GitHub: @${profile.username}`,
      `Overall Score: ${scores.overall.toFixed(1)}/10 (Heuristic Public-Data Assessment)`,
      `Personality: ${personality.title}`,
      `Top Language: ${analysis.topLanguage} • Analyzed Repos: ${analysis.analyzedRepoCount}/${analysis.publicRepoCount} • Stars: ${analysis.totalStars.toLocaleString()}`,
      `"${roast.shortCardRoast}"`,
      `— AI Roast My GitHub`,
    ].join("\n");

    try {
      await navigator.clipboard.writeText(text);
      onToast("Roast summary copied to clipboard!");
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      onToast("Roast summary copied to clipboard!");
    }
  };

  return (
    <section className="card-surface rounded-2xl p-6 sm:p-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800/80 pb-4">
        <div>
          <h3 className="text-xl font-bold text-white">
            Shareable Result Card
          </h3>
          <p className="text-xs text-zinc-400 mt-0.5">
            Compact developer report card ready to download as a 1200×630 PNG or
            copy to share
          </p>
        </div>
        <div className="flex flex-wrap gap-2.5">
          <button
            type="button"
            onClick={handleDownloadPng}
            disabled={downloading}
            className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-4 py-2.5 text-xs font-bold text-zinc-950 shadow-lg shadow-orange-500/20 hover:bg-orange-400 transition disabled:opacity-50"
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M7 10l5 5m0 0l5-5m-5 5V4"
              />
            </svg>
            <span>
              {downloading ? "Rendering PNG..." : "Download PNG Card"}
            </span>
          </button>
          <button
            type="button"
            onClick={handleCopyShareText}
            className="inline-flex items-center gap-2 rounded-xl border border-zinc-700 bg-zinc-900 px-4 py-2.5 text-xs font-semibold text-zinc-200 hover:border-zinc-500 hover:text-white transition"
          >
            <svg
              className="w-4 h-4 text-orange-400"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
              />
            </svg>
            <span>Copy Share Text</span>
          </button>
        </div>
      </div>

      {/* Compact Visual Card Preview */}
      <div className="mx-auto max-w-3xl rounded-2xl border-2 border-orange-500/40 bg-gradient-to-br from-zinc-950 via-zinc-900 to-orange-950/25 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-6">
          <div className="space-y-4 flex-1">
            <div className="inline-flex items-center gap-2 rounded-full border border-orange-500/30 bg-orange-500/10 px-3 py-1 text-[11px] font-mono uppercase tracking-widest text-orange-300">
              <span>🔥 AI ROAST MY GITHUB</span>
            </div>

            <div className="flex items-center gap-3.5">
              <img
                src={profile.avatarUrl}
                alt={profile.username}
                className="h-14 w-14 rounded-xl border border-zinc-700 object-cover"
              />
              <div>
                <div className="text-2xl font-black text-white font-mono tracking-tight">
                  @{profile.username}
                </div>
                <div className="text-sm font-bold text-orange-400">
                  {personality.title}
                </div>
              </div>
            </div>

            <blockquote className="border-l-2 border-orange-500/70 pl-3.5 text-sm sm:text-base italic text-zinc-200 leading-relaxed">
              &ldquo;{roast.shortCardRoast}&rdquo;
            </blockquote>
          </div>

          <div className="sm:text-right flex sm:flex-col justify-between items-end border-t sm:border-t-0 sm:border-l border-zinc-800/90 pt-4 sm:pt-0 sm:pl-6 shrink-0">
            <div>
              <div className="text-[10px] font-mono uppercase tracking-widest text-zinc-400">
                Overall Heuristic
              </div>
              <div className="text-4xl sm:text-5xl font-black font-mono text-orange-400 mt-0.5">
                {scores.overall.toFixed(1)}
                <span className="text-lg text-zinc-500">/10</span>
              </div>
              <div className="text-[10px] font-mono text-zinc-500">
                Public GitHub Signal
              </div>
            </div>

            <div className="mt-4 space-y-1 text-right">
              <div className="text-[10px] font-mono uppercase text-zinc-400">
                Top Language
              </div>
              <div className="inline-block rounded-md bg-zinc-900 border border-zinc-700 px-2.5 py-1 font-mono text-xs font-bold text-white">
                {analysis.topLanguage}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-zinc-800/80 flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-zinc-400">
          <span>
            Repos: {analysis.analyzedRepoCount}/{analysis.publicRepoCount} •
            Stars: {analysis.totalStars.toLocaleString()} • Original:{" "}
            {analysis.originalPercentage}%
          </span>
          <span className="text-orange-300/90 font-semibold">
            AI Roast My GitHub
          </span>
        </div>
      </div>
    </section>
  );
}
