"use client";

import React from "react";
import { EvidencePoint } from "@/types/roast";

interface StrengthsAndFlagsProps {
  strengths: EvidencePoint[];
  redFlags: EvidencePoint[];
}

export function StrengthsAndFlags({
  strengths,
  redFlags,
}: StrengthsAndFlagsProps) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Strengths */}
      <section className="card-surface rounded-2xl p-6 sm:p-8 border-emerald-500/25 space-y-5">
        <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3">
          <div className="flex items-center gap-2.5">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400 font-mono text-sm font-bold">
              ✓
            </span>
            <div>
              <h3 className="text-lg font-bold text-white">
                What You&apos;re Actually Good At
              </h3>
              <p className="text-xs text-zinc-400">
                Strengths backed by observed repository signals
              </p>
            </div>
          </div>
          <span className="text-xs font-mono text-emerald-400">
            Verified Signals
          </span>
        </div>

        <div className="space-y-3.5">
          {strengths.map((s, idx) => (
            <div
              key={idx}
              className="rounded-xl border border-zinc-800/90 bg-zinc-950/70 p-4 space-y-2"
            >
              <div className="flex items-center justify-between gap-2">
                <h4 className="text-sm font-bold text-white">{s.title}</h4>
                <span className="rounded-md bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 font-mono text-[11px] text-emerald-300 shrink-0">
                  {s.metricBadge}
                </span>
              </div>
              <p className="text-[11px] font-mono text-emerald-200/90">
                <strong>Observed Fact:</strong> {s.observedFact}
              </p>
              <p className="text-xs text-zinc-400 leading-relaxed">
                <strong className="text-zinc-300">Interpretation:</strong>{" "}
                {s.interpretation}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Biggest Red Flags / Areas to Improve */}
      <section className="card-surface rounded-2xl p-6 sm:p-8 border-rose-500/25 space-y-5">
        <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3">
          <div className="flex items-center gap-2.5">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-rose-500/15 text-rose-400 font-mono text-sm font-bold">
              !
            </span>
            <div>
              <h3 className="text-lg font-bold text-white">
                Biggest Red Flags &amp; Blind Spots
              </h3>
              <p className="text-xs text-zinc-400">
                Explainable patterns grounded strictly in public metadata
              </p>
            </div>
          </div>
          <span className="text-xs font-mono text-rose-400">Evidence-Only</span>
        </div>

        <div className="space-y-3.5">
          {redFlags.map((r, idx) => (
            <div
              key={idx}
              className="rounded-xl border border-zinc-800/90 bg-zinc-950/70 p-4 space-y-2"
            >
              <div className="flex items-center justify-between gap-2">
                <h4 className="text-sm font-bold text-white">{r.title}</h4>
                <span className="rounded-md bg-rose-500/10 border border-rose-500/30 px-2 py-0.5 font-mono text-[11px] text-rose-300 shrink-0">
                  {r.metricBadge}
                </span>
              </div>
              <p className="text-[11px] font-mono text-rose-200/90">
                <strong>Observed Fact:</strong> {r.observedFact}
              </p>
              <p className="text-xs text-zinc-400 leading-relaxed">
                <strong className="text-zinc-300">Interpretation:</strong>{" "}
                {r.interpretation}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
