"use client";

import React from "react";
import { ProjectRecommendation } from "@/types/roast";

interface RecommendationsSectionProps {
  recommendations: ProjectRecommendation[];
}

export function RecommendationsSection({
  recommendations,
}: RecommendationsSectionProps) {
  return (
    <section className="card-surface rounded-2xl p-6 sm:p-8 space-y-6">
      <div className="border-b border-zinc-800/80 pb-4">
        <h3 className="text-xl font-bold text-white">
          What You Should Build Next
        </h3>
        <p className="text-xs text-zinc-400 mt-1">
          3 concrete project ideas tailored to your primary languages, existing
          repositories, and public metadata gaps
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {recommendations.map((rec, idx) => (
          <div
            key={idx}
            className="rounded-xl border border-zinc-800/90 bg-zinc-950/70 p-5 flex flex-col justify-between gap-4"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2">
                <span className="rounded-md bg-orange-500/15 border border-orange-500/30 px-2.5 py-0.5 font-mono text-[11px] text-orange-300 font-semibold">
                  {rec.difficulty}
                </span>
              </div>
              <h4 className="text-base font-bold text-white leading-snug">
                {rec.title}
              </h4>
              <p className="text-xs text-zinc-300 leading-relaxed">
                {rec.description}
              </p>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {rec.stack.map((tech) => (
                  <span
                    key={tech}
                    className="rounded bg-zinc-900 border border-zinc-800 px-2 py-0.5 font-mono text-[10px] text-zinc-300"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            <div className="border-t border-zinc-800/80 pt-3 space-y-1.5">
              <p className="text-[11px] font-mono text-zinc-400">
                <strong className="text-orange-400">Observed Basis:</strong>{" "}
                {rec.observedBasis}
              </p>
              <p className="text-xs text-zinc-300 leading-relaxed">
                <strong className="text-white">Why It Fits:</strong>{" "}
                {rec.whyItFits}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
