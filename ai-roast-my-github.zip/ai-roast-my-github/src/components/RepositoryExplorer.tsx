"use client";

import React, { useState } from "react";
import { GitHubAnalysisMetrics } from "@/types/roast";
import { LANGUAGE_COLORS } from "@/lib/scoring";

interface RepositoryExplorerProps {
  username: string;
  analysis: GitHubAnalysisMetrics;
}

type RepoTab = "active" | "recent" | "original" | "forks" | "undescribed";

export function RepositoryExplorer({
  username,
  analysis,
}: RepositoryExplorerProps) {
  const [activeTab, setActiveTab] = useState<RepoTab>("active");
  const [searchQuery, setSearchQuery] = useState("");

  let filtered = analysis.mostActiveRepos;
  if (activeTab === "recent") {
    filtered = analysis.recentlyUpdatedRepos;
  } else if (activeTab === "original") {
    filtered = analysis.allRepos.filter((r) => !r.isFork);
  } else if (activeTab === "forks") {
    filtered = analysis.allRepos.filter((r) => r.isFork);
  } else if (activeTab === "undescribed") {
    filtered = analysis.allRepos.filter((r) => !r.description);
  }

  if (searchQuery.trim()) {
    const q = searchQuery.trim().toLowerCase();
    filtered = analysis.allRepos.filter(
      (r) =>
        r.name.toLowerCase().includes(q) ||
        (r.description && r.description.toLowerCase().includes(q)) ||
        (r.language && r.language.toLowerCase().includes(q)) ||
        r.topics.some((t) => t.toLowerCase().includes(q))
    );
  }

  const displayed = filtered.slice(0, 9);

  const tabs: Array<{ id: RepoTab; label: string }> = [
    { id: "active", label: "Most Notable (Top 6)" },
    { id: "recent", label: "Recently Updated" },
    { id: "original", label: `Original (${analysis.originalRepoCount})` },
    { id: "forks", label: `Forks (${analysis.forkRepoCount})` },
    {
      id: "undescribed",
      label: `No 'About' Blurb (${analysis.missingDescriptionCount})`,
    },
  ];

  return (
    <div className="space-y-4 pt-2 border-t border-zinc-800/80">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div
          className="flex flex-wrap items-center gap-1.5"
          role="tablist"
          aria-label="Repository filter tabs"
        >
          {tabs.map((tab) => {
            const isSelected = activeTab === tab.id && !searchQuery.trim();
            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={isSelected}
                onClick={() => {
                  setActiveTab(tab.id);
                  setSearchQuery("");
                }}
                className={`rounded-lg px-3 py-1.5 text-xs font-mono transition ${
                  isSelected
                    ? "bg-orange-500 font-bold text-zinc-950"
                    : "border border-zinc-800 bg-zinc-900 text-zinc-300 hover:text-white"
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        <div className="relative w-full md:w-64">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filter repos by name or topic..."
            aria-label="Filter repositories by name, language, or topic"
            className="w-full rounded-lg border border-zinc-800 bg-zinc-950 px-3 py-1.5 text-xs font-mono text-zinc-200 placeholder-zinc-500 focus:border-orange-500 focus:outline-none"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {displayed.length === 0 ? (
          <div className="col-span-full rounded-xl border border-zinc-800/80 bg-zinc-950/50 p-8 text-center text-xs font-mono text-zinc-400">
            No repositories match this filter on @{username}&apos;s analyzed
            profile.
          </div>
        ) : (
          displayed.map((r) => {
            const langColor = r.language
              ? LANGUAGE_COLORS[r.language] || "#f97316"
              : "#52525b";
            const sizeLabel =
              r.sizeKb >= 1024
                ? `${(r.sizeKb / 1024).toFixed(1)} MB`
                : `${r.sizeKb} KB`;

            return (
              <a
                key={r.name}
                href={r.htmlUrl}
                target="_blank"
                rel="noreferrer"
                className="card-surface-interactive rounded-xl p-4 flex flex-col justify-between gap-3 group"
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-mono text-sm font-bold text-white group-hover:text-orange-400 transition break-all">
                      {r.name} ↗
                    </span>
                    <span
                      className={`rounded px-1.5 py-0.5 font-mono text-[10px] shrink-0 ${
                        r.isFork
                          ? "bg-zinc-800 text-zinc-400"
                          : "bg-orange-500/15 text-orange-300 border border-orange-500/30"
                      }`}
                    >
                      {r.isFork ? "Fork" : "Original"}
                    </span>
                  </div>

                  <p
                    className={`text-xs ${
                      r.description
                        ? "text-zinc-300"
                        : "text-zinc-500 italic"
                    } line-clamp-2 leading-relaxed`}
                  >
                    {r.description ||
                      "No summary description set (README may still exist in repo)."}
                  </p>

                  {r.topics.length > 0 && (
                    <div className="flex flex-wrap gap-1 pt-0.5">
                      {r.topics.slice(0, 4).map((t) => (
                        <span
                          key={t}
                          className="rounded bg-zinc-900 border border-zinc-800 px-1.5 py-0.5 font-mono text-[10px] text-zinc-400"
                        >
                          #{t}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <div className="pt-2 border-t border-zinc-800/80 flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-zinc-400">
                  <div className="flex items-center gap-2">
                    <span
                      className="h-2 w-2 rounded-full"
                      style={{ backgroundColor: langColor }}
                    />
                    <span>{r.language || "None"}</span>
                    <span>•</span>
                    <span>★ {r.stars.toLocaleString()}</span>
                    <span>•</span>
                    <span>⑂ {r.forks.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {r.initialCommitOnly ? (
                      <span
                        className="text-amber-400"
                        title="Final push within 24h of creation (<35 KB)"
                      >
                        ⚡Day-1 proto
                      </span>
                    ) : r.isStableInactive ? (
                      <span
                        className="text-emerald-400/80"
                        title="Substantive or multi-day repository inactive >1yr"
                      >
                        ✓ Stable ({r.daysSinceLastPush}d)
                      </span>
                    ) : (
                      <span>{r.daysSinceLastPush}d ago</span>
                    )}
                    <span className="text-zinc-600">({sizeLabel})</span>
                  </div>
                </div>
              </a>
            );
          })
        )}
      </div>
    </div>
  );
}
