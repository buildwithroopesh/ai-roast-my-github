"use client";

import React from "react";
import { GitHubAnalysisMetrics } from "@/types/roast";

interface TelemetrySectionProps {
  analysis: GitHubAnalysisMetrics;
  children?: React.ReactNode;
}

export function TelemetrySection({
  analysis,
  children,
}: TelemetrySectionProps) {
  const telemetryItems = [
    {
      label: "Analyzed / Total",
      value: `${analysis.analyzedRepoCount}/${analysis.publicRepoCount}`,
    },
    { label: "Total Stars", value: analysis.totalStars.toLocaleString() },
    { label: "Total Forks", value: analysis.totalForks.toLocaleString() },
    { label: "Original %", value: `${analysis.originalPercentage}%` },
    {
      label: "Substantive",
      value: `${analysis.substantiveOriginalCount}`,
    },
    { label: "Active (90d)", value: String(analysis.activeLast90Days) },
    {
      label: "Stable (>1y)",
      value: String(analysis.stableCompletedCount),
    },
    {
      label: "Day-1 Drops",
      value: String(analysis.initialCommitOnlyCount),
    },
  ];

  const signals = [
    {
      label: "Last Push Recency",
      val: `${analysis.daysSinceLastActive} day(s) ago`,
    },
    {
      label: "Updated <= 30d",
      val: `${analysis.activeLast30Days} repo(s)`,
    },
    {
      label: "Missing 'About' Blurb",
      val: `${analysis.missingDescriptionCount} (${analysis.missingDescriptionPercent}%)`,
    },
    {
      label: "Topic Tags Used",
      val: `${analysis.reposWithTopicsCount}/${analysis.analyzedRepoCount} repos`,
    },
    {
      label: "Live Homepage URL",
      val: `${analysis.reposWithHomepageCount}/${analysis.analyzedRepoCount} repos`,
    },
    {
      label: "SPDX Licensed",
      val: `${analysis.reposWithLicenseCount}/${analysis.analyzedRepoCount} repos`,
    },
  ];

  return (
    <section className="card-surface rounded-2xl p-6 sm:p-8 space-y-8">
      <div className="border-b border-zinc-800/80 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h3 className="text-xl font-bold text-white">
            GitHub Telemetry &amp; Repository Analysis
          </h3>
          <p className="text-xs text-zinc-400 mt-0.5">
            {analysis.pagination.coverageNotice} • Velocity:{" "}
            {analysis.reposPerYear} repos/yr
          </p>
        </div>
        <span className="text-xs font-mono text-zinc-400">
          Pages Fetched: {analysis.pagination.pagesFetched} (
          {analysis.pagination.coveragePercentage}% Coverage)
        </span>
      </div>

      {/* Top 8 Telemetry Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {telemetryItems.map((t) => (
          <div
            key={t.label}
            className="rounded-xl border border-zinc-800/80 bg-zinc-950/70 p-3 text-center"
          >
            <div className="text-lg sm:text-xl font-extrabold font-mono text-white">
              {t.value}
            </div>
            <div className="text-[10px] font-mono uppercase tracking-wider text-zinc-400 mt-0.5">
              {t.label}
            </div>
          </div>
        ))}
      </div>

      {/* Original vs Forks + Primary Languages Split */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-xl border border-zinc-800/90 bg-zinc-950/60 p-5 space-y-5">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-zinc-300 font-semibold uppercase">
                Original Repositories vs Forks
              </span>
              <span className="text-orange-300">
                {analysis.originalRepoCount} Original (
                {analysis.originalPercentage}%) / {analysis.forkRepoCount} Forks
              </span>
            </div>
            <div className="h-3 w-full rounded-full bg-zinc-800 overflow-hidden flex">
              <div
                className="h-full bg-gradient-to-r from-orange-500 to-amber-400 transition-all duration-500"
                style={{ width: `${analysis.originalPercentage}%` }}
              />
              <div
                className="h-full bg-zinc-600 transition-all duration-500"
                style={{ width: `${100 - analysis.originalPercentage}%` }}
              />
            </div>
            <div className="flex justify-between text-[11px] font-mono text-zinc-400">
              <span>
                Original Repos: {analysis.originalRepoCount} (
                {analysis.originalStars.toLocaleString()} ★)
              </span>
              <span>Forked Repos: {analysis.forkRepoCount}</span>
            </div>
          </div>

          <div className="space-y-2.5 pt-2 border-t border-zinc-800/80">
            <div className="text-xs font-mono text-zinc-300 font-semibold uppercase">
              Repository Activity &amp; Metadata Signals
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              {signals.map((s) => (
                <div
                  key={s.label}
                  className="rounded-lg border border-zinc-800/70 bg-zinc-900/60 px-3 py-2 flex items-center justify-between gap-2"
                >
                  <span className="text-zinc-400">{s.label}</span>
                  <span className="font-mono font-semibold text-zinc-200">
                    {s.val}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Primary Languages Distribution */}
        <div className="rounded-xl border border-zinc-800/90 bg-zinc-950/60 p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-mono text-zinc-300 font-semibold uppercase">
              Primary Languages ({analysis.languageSpecialization})
            </span>
            <span className="rounded bg-orange-500/15 border border-orange-500/30 px-2 py-0.5 font-mono text-xs text-orange-300">
              Top: {analysis.topLanguage}
            </span>
          </div>

          <div className="h-3 w-full rounded-full bg-zinc-800 overflow-hidden flex gap-0.5">
            {analysis.languages.length === 0 ? (
              <div className="h-full w-full bg-zinc-700" />
            ) : (
              analysis.languages.map((l) => (
                <div
                  key={l.language}
                  className="h-full"
                  style={{
                    width: `${Math.max(4, l.percentage)}%`,
                    backgroundColor: l.color,
                  }}
                  title={`${l.language}: ${l.percentage}%`}
                />
              ))
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
            {analysis.languages.length === 0 ? (
              <div className="text-xs font-mono text-zinc-500 col-span-2">
                No language-tagged repositories found in analyzed set.
              </div>
            ) : (
              analysis.languages.slice(0, 6).map((l) => (
                <div
                  key={l.language}
                  className="rounded-lg border border-zinc-800/70 bg-zinc-900/60 px-3 py-2 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2 truncate">
                    <span
                      className="h-2.5 w-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: l.color }}
                    />
                    <span className="font-medium text-zinc-200 truncate">
                      {l.language}
                    </span>
                  </div>
                  <span className="font-mono text-zinc-400">
                    {l.repoCount} ({l.percentage}%)
                  </span>
                </div>
              ))
            )}
          </div>

          <p className="text-[11px] text-zinc-500 pt-1">
            Note: Single-language dominance is recognized as focused domain
            specialization rather than a penalty.
          </p>
        </div>
      </div>

      {children}
    </section>
  );
}
