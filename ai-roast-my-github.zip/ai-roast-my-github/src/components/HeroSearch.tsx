"use client";

import React from "react";
import { ApiErrorCode } from "@/types/roast";

const LIVE_SAMPLE_USERS = [
  "torvalds",
  "gaearon",
  "sindresorhus",
  "yyx990803",
  "shadcn",
];

export interface ErrorState {
  title: string;
  message: string;
  code?: ApiErrorCode;
  configurationHint?: string;
}

interface HeroSearchProps {
  usernameInput: string;
  onUsernameChange: (val: string) => void;
  onSubmitLive: (username?: string, allowFallback?: boolean) => void;
  onSubmitDemo: (fixtureKey: string) => void;
  loading: boolean;
  error: ErrorState | null;
}

export function HeroSearch({
  usernameInput,
  onUsernameChange,
  onSubmitLive,
  onSubmitDemo,
  loading,
  error,
}: HeroSearchProps) {
  return (
    <section className="text-center space-y-6 max-w-3xl mx-auto">
      <div className="inline-flex items-center gap-2 rounded-full border border-orange-500/25 bg-orange-500/10 px-3.5 py-1 text-xs font-mono text-orange-300">
        <span>⚡ Multi-Page GitHub REST API</span>
        <span>•</span>
        <span>Fact vs. Interpretation AI</span>
      </div>

      <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white leading-[1.08]">
        Your GitHub deserves a{" "}
        <span className="bg-gradient-to-r from-orange-400 via-amber-300 to-rose-400 bg-clip-text text-transparent">
          reality check.
        </span>
      </h1>

      <p className="text-base sm:text-lg text-zinc-400 max-w-2xl mx-auto leading-relaxed">
        Let AI inspect your repositories, analyze your coding habits, and roast
        you for free.
      </p>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          onSubmitLive();
        }}
        className="mx-auto max-w-xl pt-2"
      >
        <div className="flex flex-col sm:flex-row gap-2.5 p-1.5 rounded-2xl border border-zinc-800 bg-zinc-900/90 shadow-2xl focus-within:border-orange-500/60 transition">
          <div className="flex items-center flex-1 pl-3.5 pr-2 py-2">
            <span className="font-mono text-zinc-500 text-sm select-none mr-1.5">
              github.com/
            </span>
            <input
              type="text"
              value={usernameInput}
              onChange={(e) => onUsernameChange(e.target.value)}
              autoComplete="off"
              spellCheck={false}
              placeholder="username (e.g. torvalds, gaearon)"
              aria-label="GitHub username"
              className="w-full bg-transparent text-sm sm:text-base font-mono text-white placeholder-zinc-500 focus:outline-none"
            />
            {usernameInput.trim().length > 0 && (
              <button
                type="button"
                onClick={() => onUsernameChange("")}
                title="Clear username"
                aria-label="Clear username"
                className="text-zinc-500 hover:text-zinc-300 px-1.5 text-xs font-mono"
              >
                ✕
              </button>
            )}
          </div>
          <button
            type="submit"
            disabled={loading}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 px-6 py-3.5 text-sm font-bold text-zinc-950 shadow-lg shadow-orange-500/20 hover:from-orange-400 hover:to-amber-400 active:scale-[0.99] transition disabled:opacity-50"
          >
            <span>{loading ? "Inspecting..." : "Roast My GitHub"}</span>
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M13 7l5 5m0 0l-5 5m5-5H6"
              />
            </svg>
          </button>
        </div>
      </form>

      {/* Live GitHub Profiles & Explicit Demo Fixtures */}
      <div className="space-y-2 pt-1 text-xs">
        <div className="flex flex-wrap items-center justify-center gap-2">
          <span className="text-zinc-500 font-mono mr-1">Live inspect:</span>
          {LIVE_SAMPLE_USERS.map((sample) => (
            <button
              key={sample}
              type="button"
              disabled={loading}
              onClick={() => onSubmitLive(sample)}
              className="rounded-lg border border-zinc-800 bg-zinc-900/70 px-2.5 py-1 font-mono text-zinc-300 hover:border-orange-500/40 hover:text-white transition disabled:opacity-50"
            >
              @{sample}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center justify-center gap-2">
          <span className="text-zinc-500 font-mono mr-1">
            Offline test fixtures:
          </span>
          <button
            type="button"
            disabled={loading}
            onClick={() => onSubmitDemo("torvalds")}
            className="rounded-lg border border-zinc-800/80 bg-zinc-900/40 px-2.5 py-1 font-mono text-zinc-400 hover:border-zinc-700 hover:text-zinc-200 transition"
          >
            Demo: @torvalds
          </button>
          <button
            type="button"
            disabled={loading}
            onClick={() => onSubmitDemo("stealth-zero-repos")}
            className="rounded-lg border border-zinc-800/80 bg-zinc-900/40 px-2.5 py-1 font-mono text-zinc-400 hover:border-zinc-700 hover:text-zinc-200 transition"
          >
            Demo: 0-Repo Edge Case
          </button>
        </div>
      </div>

      {/* Error Banner */}
      {error && (
        <div
          role="alert"
          className="mx-auto max-w-xl rounded-xl border border-rose-500/40 bg-rose-950/30 p-4 text-left space-y-3"
        >
          <div className="flex items-start gap-3">
            <div className="mt-0.5 rounded-lg bg-rose-500/20 p-1.5 text-rose-400">
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 9v2m0 4h.01M5.07 19h13.86c1.54 0 2.5-1.67 1.73-3L13.73 4c-.77-1.33-2.69-1.33-3.46 0L3.34 16c-.77 1.33.19 3 1.73 3z"
                />
              </svg>
            </div>
            <div className="flex-1 space-y-1">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-sm font-bold text-rose-200">
                  {error.title}
                </h2>
                {error.code && (
                  <span className="rounded bg-rose-500/20 px-2 py-0.5 font-mono text-[10px] text-rose-300">
                    {error.code}
                  </span>
                )}
              </div>
              <p className="text-xs text-rose-300/90 leading-relaxed">
                {error.message}
              </p>
              {error.configurationHint && (
                <p className="text-[11px] font-mono text-amber-300/90 pt-1">
                  Hint: {error.configurationHint}
                </p>
              )}
            </div>
          </div>

          {error.code === "MISSING_AI_API_KEY" && (
            <div className="flex justify-end border-t border-rose-500/20 pt-2.5">
              <button
                type="button"
                onClick={() => onSubmitLive(usernameInput, true)}
                className="rounded-lg border border-amber-500/40 bg-amber-500/15 px-3 py-1.5 font-mono text-xs font-semibold text-amber-200 hover:bg-amber-500/25 transition"
              >
                Run with Deterministic Heuristic Engine Instead →
              </button>
            </div>
          )}
        </div>
      )}
    </section>
  );
}
