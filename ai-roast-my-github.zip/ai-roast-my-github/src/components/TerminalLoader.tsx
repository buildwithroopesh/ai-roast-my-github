"use client";

import React from "react";

interface TerminalLoaderProps {
  logs: string[];
}

export function TerminalLoader({ logs }: TerminalLoaderProps) {
  return (
    <section
      aria-live="polite"
      aria-busy="true"
      className="max-w-2xl mx-auto"
    >
      <div className="rounded-2xl border border-zinc-800 bg-zinc-950/95 p-6 shadow-2xl font-mono space-y-4">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2">
            <span className="h-3 w-3 rounded-full bg-rose-500/80" />
            <span className="h-3 w-3 rounded-full bg-amber-500/80" />
            <span className="h-3 w-3 rounded-full bg-emerald-500/80" />
            <span className="text-xs text-zinc-400 ml-2">
              github-inspector — server pipeline
            </span>
          </div>
          <span className="text-[11px] text-orange-400 animate-pulse-subtle">
            RUNNING ANALYSIS
          </span>
        </div>
        <div className="space-y-2.5 text-xs sm:text-sm text-zinc-300">
          {logs.map((log, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="text-orange-400">❯</span>
              <span>{log}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
