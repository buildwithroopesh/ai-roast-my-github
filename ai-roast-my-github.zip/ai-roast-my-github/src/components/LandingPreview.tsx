"use client";

import React from "react";

export function LandingPreview() {
  return (
    <section className="grid grid-cols-1 md:grid-cols-3 gap-5 pt-2">
      <div className="card-surface rounded-2xl p-6 space-y-3">
        <div className="h-9 w-9 rounded-lg bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400 font-mono text-sm font-bold">
          01
        </div>
        <h2 className="text-base font-bold text-white">
          Multi-Page Repository Forensics
        </h2>
        <p className="text-xs text-zinc-400 leading-relaxed">
          Paginates through public repositories while respecting rate limits and
          explicitly reporting sample coverage—distinguishing completed stable
          projects from single-day <code className="text-zinc-200 font-mono">git init</code> drops.
        </p>
      </div>
      <div className="card-surface rounded-2xl p-6 space-y-3">
        <div className="h-9 w-9 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-mono text-sm font-bold">
          02
        </div>
        <h2 className="text-base font-bold text-white">
          Trustworthy 6-Axis Heuristics
        </h2>
        <p className="text-xs text-zinc-400 leading-relaxed">
          Evaluates codebase substance and follow-through without assuming stars
          equal code quality, fewer repos mean lower skill, or single-language
          focus means lack of versatility.
        </p>
      </div>
      <div className="card-surface rounded-2xl p-6 space-y-3">
        <div className="h-9 w-9 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 font-mono text-sm font-bold">
          03
        </div>
        <h2 className="text-base font-bold text-white">
          Server-Side AI Roast + Result Card
        </h2>
        <p className="text-xs text-zinc-400 leading-relaxed">
          Feeds structured GitHub evidence to a server-side AI model that
          separates observed facts from interpretations, complete with a
          downloadable 1200×630 PNG Result Card.
        </p>
      </div>
    </section>
  );
}
