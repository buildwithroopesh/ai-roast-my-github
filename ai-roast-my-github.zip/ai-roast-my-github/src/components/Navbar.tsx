"use client";

import React from "react";
import { RateLimitMeta } from "@/types/roast";

interface NavbarProps {
  rateLimit: RateLimitMeta | null;
  aiModelUsed: string | null;
  onReset: () => void;
  onOpenModal: () => void;
}

export function Navbar({
  rateLimit,
  aiModelUsed,
  onReset,
  onOpenModal,
}: NavbarProps) {
  const remaining = rateLimit?.remaining ?? 60;
  const limit = rateLimit?.limit ?? 60;
  const dotColor =
    remaining <= 5
      ? "bg-rose-500"
      : remaining <= 15
      ? "bg-amber-400"
      : "bg-emerald-400";

  return (
    <header className="sticky top-0 z-30 border-b border-zinc-800/80 bg-zinc-950/85 backdrop-blur-md">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onReset}
            className="flex items-center gap-2.5 text-left group focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-500 rounded-xl"
          >
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center shadow-lg shadow-orange-500/20 group-hover:scale-105 transition">
              <svg
                className="w-5 h-5 text-zinc-950"
                viewBox="0 0 24 24"
                fill="currentColor"
                aria-hidden="true"
              >
                <path d="M12 2C9.5 5.5 7 8.5 7 12.5C7 16.09 9.91 19 13.5 19C13.1 17.5 13.5 15.8 14.8 14.5C15.6 16.2 15.5 18.2 14.2 19.8C17.5 18.9 20 15.9 20 12.2C20 8.2 17.2 4.8 14.2 2.8C14.4 4.5 13.8 6.1 12.5 7.2C12.8 5.2 12.6 3.5 12 2ZM5 14C4.4 15.5 4.5 17.4 5.5 19C4.2 18.2 3.5 16.8 3.5 15.2C3.5 14.7 3.6 14.2 3.8 13.8L5 14Z" />
              </svg>
            </div>
            <div>
              <span className="font-bold text-base tracking-tight text-white block leading-none">
                AI Roast My GitHub
              </span>
              <span className="font-mono text-[11px] text-zinc-400 block mt-1">
                Evidence-Grounded Profile Analyzer
              </span>
            </div>
          </button>
        </div>

        <div className="flex items-center gap-2.5">
          {aiModelUsed && (
            <div
              className="hidden md:flex items-center gap-1.5 rounded-lg border border-orange-500/30 bg-orange-500/10 px-2.5 py-1.5 text-[11px] font-mono text-orange-300"
              title="Generation Engine"
            >
              <span>Engine: {aiModelUsed}</span>
            </div>
          )}

          <div
            className="hidden sm:flex items-center gap-2 rounded-lg border border-zinc-800 bg-zinc-900/90 px-3 py-1.5 text-xs font-mono text-zinc-400"
            title="GitHub REST API rate limit status"
          >
            <span className={`h-2 w-2 rounded-full ${dotColor}`} />
            <span>
              {rateLimit
                ? `GitHub API: ${remaining}/${limit}`
                : "GitHub API: Ready"}
            </span>
          </div>

          <button
            type="button"
            onClick={onOpenModal}
            className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-800 bg-zinc-900/90 px-3 py-1.5 text-xs font-medium text-zinc-300 hover:border-zinc-700 hover:text-white transition focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-500"
          >
            <svg
              className="w-3.5 h-3.5 text-orange-400"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
              />
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
              />
            </svg>
            <span>API &amp; Methodology</span>
          </button>
        </div>
      </div>
    </header>
  );
}
