/* eslint-disable @next/next/no-img-element */
"use client";

import React from "react";
import { RoastReport } from "@/types/roast";

interface ProfileBannerProps {
  report: RoastReport;
}

export function ProfileBanner({ report }: ProfileBannerProps) {
  const { profile, personality, analysis, rateLimit } = report;
  const { pagination } = analysis;

  return (
    <section className="card-surface rounded-2xl p-6 sm:p-8 space-y-6">
      {/* Incomplete Pagination Warning Banner if truncated */}
      {!pagination.isComplete && (
        <div
          role="status"
          className="rounded-xl border border-amber-500/40 bg-amber-950/25 px-4 py-3 text-xs text-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
        >
          <div className="flex items-start sm:items-center gap-2.5">
            <span className="font-mono font-bold text-amber-400 shrink-0">
              [PARTIAL PROFILE COVERAGE: {pagination.coveragePercentage}%]
            </span>
            <span>{pagination.coverageNotice}</span>
          </div>
          <span className="font-mono text-[11px] text-amber-300/80 shrink-0">
            {pagination.fetchedRepoCount} / {pagination.totalPublicRepos} repos
          </span>
        </div>
      )}

      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
          <img
            src={profile.avatarUrl}
            alt={`${profile.username} avatar`}
            className="h-20 w-20 rounded-2xl border-2 border-zinc-700/80 object-cover shadow-xl"
          />
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2.5">
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                {profile.name}
              </h2>
              <a
                href={profile.htmlUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 rounded-lg border border-zinc-700/80 bg-zinc-900 px-2.5 py-1 font-mono text-xs text-orange-300 hover:border-orange-500/50 transition"
              >
                <span>@{profile.username}</span>
                <span aria-hidden="true">↗</span>
              </a>
              <span className="rounded-md bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 font-mono text-[11px] text-emerald-300">
                {rateLimit.sourceLabel}
              </span>
            </div>

            <p className="text-sm text-zinc-300 max-w-2xl leading-relaxed">
              {profile.bio || "No public profile bio provided."}
            </p>

            <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs font-mono text-zinc-400">
              <span>
                👥{" "}
                <strong className="text-zinc-200">
                  {profile.followers.toLocaleString()}
                </strong>{" "}
                followers
              </span>
              <span>•</span>
              <span>
                ⏳{" "}
                <strong className="text-zinc-200">
                  {analysis.accountAgeYears} yrs
                </strong>{" "}
                on GitHub
              </span>
              {profile.location && (
                <>
                  <span>•</span>
                  <span>📍 {profile.location}</span>
                </>
              )}
              {profile.company && (
                <>
                  <span>•</span>
                  <span>🏢 {profile.company}</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Developer Personality Box */}
        <div className="lg:max-w-md w-full rounded-xl border border-orange-500/35 bg-gradient-to-br from-orange-500/10 via-zinc-900/90 to-zinc-950 p-5 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono uppercase tracking-widest text-orange-400 font-semibold">
              Developer Personality
            </span>
            <span className="text-[11px] font-mono text-zinc-400">
              Explainable Signal
            </span>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
            {personality.title}
          </div>
          <p className="text-xs text-zinc-200 italic">
            &ldquo;{personality.tagline}&rdquo;
          </p>
          <div className="pt-2 border-t border-zinc-800/80 space-y-1.5 text-[11px]">
            <p className="font-mono text-orange-200/90 leading-relaxed">
              <strong className="text-orange-400 uppercase">Observed:</strong>{" "}
              {personality.observedSignal}
            </p>
            <p className="text-zinc-400 leading-relaxed">
              <strong className="text-zinc-300 font-mono uppercase">
                Interpretation:
              </strong>{" "}
              {personality.interpretation}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
